

<?php
  error_reporting(E_ALL); 
  //ini_set('display_errors', '1');
  ini_set('display_errors',0);

  include_once 'includes/header.inc.php';
  require_once 'includes/functions.inc.php';
  require_once 'includes/dbh.inc.php';
  
  werl($_SERVER['PHP_SELF'] . "\t------ Page load ------");     // Log message
?>




<style>
.boxed {
  border: 1px solid green;
  padding-left:20px;
  margin-left: 20px;
  padding-top: 20px;
  padding-bottom: 30px;
  width: 0300px;
} 
</style>

<link rel="stylesheet" href="css/index_css.css">

<section>

  <h1><?php echo $jobs_systemname; ?> - Log In Page</h1>
  
    <div class="boxed">
    <form action="includes/login.inc.php" method="post">

      <p style="text-align:left; font-size:1.2em; color:brown">Please use the following form to Log In.</p>
      <br>
        <label style="display:table-cell" for="uname">Enter Username</label>
        <input style="display:table-cell" type="text" id="uname" name="uid" autofocus>
        <br><br>
        <label style="display:table-cell" for="pwd">Enter Password</label>
        <input style="display:table-cell" type="password" id="pwd"name="pwd" >
        <br><br>

        <button class="link_button" type="submit" name="submit">Log In</button>
    
  
    </form>
    </div>

    
    <br>
    If you do not have a login to this system please <a href="register.php">register here</a>.
    <br><br>
    <?php
    // Handle all the error conditions returned via the URL from the login process
    if(isset($_GET["error"])){
      switch($_GET["error"]){
        case "emptyinput":
          echo"<p> Please complete all the required fields on your login form. <p>";
          break;
        case "badusername":
          echo"<p> Username not found. If you have not registered, please do so now.<p>";
          break;
        case "badpassword":
          echo"<p> Password is incorrect. <p>";
          break;
        case "inactive":
          echo "<p> Your credentials are recognised but your account is not presently active. <p>";
          break;
      }
    }
    ?>
</section>


  
<?php 
  include_once 'includes/footer.inc.php'; 
?>
  
</html>
