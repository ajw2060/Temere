






<?php
  /*
    This page provides a simple dump of the sequence table.    
      
    Change History
    2023-08-10  Initial build
    
  
  
  */
?>




<?php
  error_reporting(E_ALL); 
  ini_set('display_errors', '0');
  include_once 'includes/header.inc.php';
  require_once 'includes/functions.inc.php';
  require_once 'includes/dbh.inc.php';
  werl($_SERVER['PHP_SELF'] . "\tPage load");     // Log message
  
?>



<?php
//var_dump($_SESSION);
  // This bit is magic - it ensures users cannot get to the page without being logged in.
  if (isset($_SESSION["useruid"])){
    //echo "here";
    echo "<p style='color:purple; text-align:left'>You are logged in as " . $_SESSION["userfullname"] .  "</p>";
  }
  else {
    //echo "xxx";
    header("location: login.php");
    exit();
  }
  //var_dump($_SESSION);
  ?>

<style>
  tr:nth-of-type(even) {
  background-color:#ccc;
}

.link_button {
    background-color: #1c87c9;
    border: none;
    color: white;
    padding: 5px 20px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 1.0em;
    margin: 4px 2px;
    cursor: pointer;
    border-radius: 2px;
  }

.link_button1:hover {
      background-color:lightgreen;
      transition: 0.1s;
  }

  button:active {
    transform: scale(0.99);
  }

  th{
    text-align: left;
  }
</style>



  <body>
    <div class="container">
    
      <?php
        // Dump of the Sequence table.
        $sql_sequence = "SELECT 
              sequence_id
            , schedule_id
            , device_id
            , cycle_id
            , event_datetime
            , event_dayname
            , event_function
            , event_completed_date
            , event_ontime
            , batch_id
            FROM sequence
            ORDER BY sequence_id ASC; ";

        $result = mysqli_query($conn, $sql_sequence) or die(mysqli_error($conn));
        $num_rows = mysqli_num_rows($result);
        $my_table_number = 0;     // Increment before use
        //echo "<p>There were {$num_rows} records returned from the SQL query.</p>";
      ?>
      <br>
      <h1>Sequence Table</h1>
      This is a simple dump of the current Sequence table.
      <br><br>
      <table class="box-1" width="100%" >
      <caption>Table <?php echo $my_table_number +=1;?> - Sequence table</caption>
        <tr >
          <th> Sequence           </th>  
          <th> Schedule           </th>  
          <th> Device             </th>  
          <th> Cycle              </th>  
          <th> DateTime           </th>
          <th> Day                </th> 
          <th> Function           </th>  
          <th> Completed          </th>  
          <th> Duration           </th>  
          <th> Batch              </th>
        </tr>
        
        <?php
        while($row = mysqli_fetch_assoc($result)){

          // Prepare the event completed date field
          if (!is_null($row['event_completed_date'])){
            $my_eventcompleteddate = date_format(date_create($row['event_completed_date']), 'Y-m-d H:i');
          }
          else{
            $my_eventcompleteddate = "";
          }
         
          // Prepare the event DateTime field.  This field is mandatory in the database so should never be null.
          if (!is_null($row['event_datetime'])){
            $my_eventdatetime = date_format(date_create($row['event_datetime']), 'Y-m-d H:i');
          }
          else{
            $my_eventdatetime = "";
          }


        ?>
          <tr> 
            <td><?php echo $row['sequence_id'] ?>           </td>
            <td><?php echo $row['schedule_id'] ?>           </td>
            <td><?php echo $row['device_id'] ?>             </td>
            <td><?php echo $row['cycle_id'] ?>              </td>
            <td><?php echo $my_eventdatetime ?>             </td>
            <td><?php echo $row['event_dayname'] ?>         </td>
            <td><?php echo $row['event_function'] ?>        </td>
            <td><?php echo $my_eventcompleteddate?>         </td>
            <td><?php echo $row['event_ontime'] ?>          </td>
            <td><?php echo $row['batch_id'] ?>              </td>
          </tr>
        <?php
          }
        ?>
      </table>
      <?php echo "There are {$num_rows} sequence records."  ?>
          <br><br>




  <form>
    <button class="link_button"   type="submit" formaction= "index.php" > 
      Home
    </button>

  </form>
  </div>  
</body>
  <?php include_once 'includes/footer.inc.php'; ?>
</html>



