#!/bin/bash

echo "Starting the 'Temere Planner' script"
source /var/www/html/temere/venv/bin/activate

#python3.8 /var/www/html/temere/scripts/planner.py /var/www/html/temere/scripts/planner.yaml /var/log/temere/planner.log

python3.8 /var/www/html/temere/scripts/planner.py /var/www/html/temere/scripts/planner.yaml /home/awoods/Logs/Temere/planner.log




