#!/bin/bash

echo "Starting the 'Tuya Cloud Control' script"
source /var/www/html/temere/venv/bin/activate

python3.8 /var/www/html/temere/scripts/tuyacloud_lightcontrol.py $@


