#!/bin/bash

source /var/www/html/temere/venv/bin/activate

python3.8 /var/www/html/temere/scripts/mqtt_generic_publisher.py /var/www/html/temere/scripts/mqtt_generic_publisher.yaml /home/awoods/Logs/Temere/mqtt_generic_publisher.log $@


