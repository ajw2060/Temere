
# Temere Planner

# This script is part of the Temere Random Scheduler tool.  This script does the following
# - connects to the SQL database 
# - reads the Schedule table.
# - processes each Schedule record to create the required Sequence records.
# - writes a new Sequence into the Seqiuence table.
#
# 
# Change History
#   2023-07-29  Initial version.
#   2023-08-08  Change to support new Sequence table structure
#   2023-08-19  Added the judicious purge holdover capability to retain half completed cycles in Sequence
#   2023-08-20  Added a batch number to Sequence records
#   2023--8-23  Added a purge following creation, to remove expired events
#   2023-09-07  Increased the complexity of the Cycle Hash to avoid duplicates.
#   2023-11-01  Made the date timezone aware so it detects a month cahnge correctly rather than some 10 hours after the change.
#   


#import time
from datetime import date, datetime, timedelta, timezone
import time
import pytz                            # Used to get local time based on timezone
import os
import logging
import logging.handlers
import platform
import sys
import yaml
import warnings
import calendar
import random



# import mysql.connector
import pymysql

# ---------- Configuration load from YAML -----------------------------------------------------------------------------
def yaml_loader(filepath):
    try:
        with open(filepath, "r") as file_descriptor:
            config_data = yaml.load(file_descriptor, Loader=yaml.FullLoader)    # Should avoid the unsafe warning
        return config_data
    except:
        print(f"ERROR 5.  YAML loader unable to load configuration file [{filepath}].")
        exit(5)


# Add the 2 lines below to ignore unverified certificate warnings
#warnings.filterwarnings("ignore")

# ---- Send a message using the MiFe service
def send_mife(arg_subject, arg_message_plain, arg_message_tel, arg_message_html):
    # Prepare the base dictionary to build the JSON object used in the body of MiFe.
    logger.debug("Calling MiFe to deliver this message.")
    
    mife_message_body = dict()          # Use this form to create the empty dict
    mife_message_body['client_name'] = mife_client_name            # Use in prod
    mife_message_body['delivery_services'] = ['telegram','email']
    mife_message_body['subject'] = arg_subject
    mife_message_body.update({'body': {'message_txt': arg_message_plain}})      # May be a better way to add a new dict to the current dict, but this works.
    mife_message_body['body']['message_tel'] = arg_message_tel
    mife_message_body['body']['message_html'] = arg_message_html
    
    
    # ---- Prepare the MiFe URL
    mife_url = f'http://{mife_host}:{mife_port}/{mife_path}'
    #print("MiFe URL ==>" + mife_url)
    #print(mife_message_body)

    # Convert the dict to a JSON object
    json_message_body = json.dumps(mife_message_body)

    r = requests.post(mife_url, headers={"content-type":"application/json"}, data=json_message_body)
    #print(str(r.status_code))
    if ((r.status_code) == 200):
        logger.debug("MiFe success. Status=[" + str(r.status_code) + "].")
        logger.debug(f"Response ==> {r.text}")
    else:
        logger.error("ERROR 601.  MiFe failed.  Status [" + str(r.status_code) + "].  Message [" + str(r.content) + "].")

    

# ---- Get a new batch number to use elsewhere
def getBatchNumber(conn, arg_requester):
    # This function simply cretes a new batch record for the requester and returns the corresponding batch ID
    # The batch number is used as a tracking or audit ID in other tables so we can follow when things such as a 
    # Sequence record were created.
    try:
        with conn.cursor() as cursor:   
            logger.debug(f"Creating new batch number for client called [{arg_requester}].")
            sql_timezone = 'SET @@session.time_zone = "+10:00";'
            cursor.execute(sql_timezone)    
            conn.commit()
            now = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            sql_newbatch = "INSERT INTO batch (batch_date, batch_requester) VALUES (%s, %s)"
            cursor.execute(sql_newbatch, (now, arg_requester))
            conn.commit()
            my_batchid = cursor.lastrowid
            logger.debug(f"..Batch number [{my_batchid}] created.")
    finally:
        cursor.close()
    return my_batchid

        




# ---- Judicious purge of Sequence
def judicious_purge_sequence():
    logger.debug("---- Starting the Judicious Purge of Sequence records.")
    # This happens in two phases.
    # Phase 1 deletes all the 'never run' Cycles
    # Phase 2 deletes all the 'fully run' cycles
    # This means the 'half run' cycles will remain (half run are those where switch on has happened but switch off is yet to happen)

    # Phase 0 - Before starting count how many Cycles exist in the Sequence
    try:
        with conn.cursor() as cursor:
            logger.debug(f"Phase 0.  Retrieving all Cycles regardless of state.")

            # This SQL selects all Sequence records
            sql_fullcyclecount = "SELECT \
                A1.sequence_id              AS on_sequenceid, \
                A1.cycle_id                 AS master_cycleid, \
                A1.event_function, \
                A1.event_completed_date, \
                A2.sequence_id              AS off_sequenceid, \
                A2.cycle_id, \
                A2.event_function, \
                A2.event_completed_date \
                FROM sequence A1 \
                INNER JOIN sequence A2 \
                ON A1.cycle_id = A2.cycle_id \
                WHERE A1.event_function = 1 \
                AND A2.event_function = 0 ;"
                

            cursor.execute(sql_fullcyclecount)

            # Fetch all rows
            rows = cursor.fetchall()
            sql_rowcount = cursor.rowcount
            logger.debug(f"  Query returned [{sql_rowcount}] Cycles.")

    except pymysql.Error as e:
        logger.debug(f"ERROR in SQL Phase 0.    [{e.args[0]}] [{e.args[1]}]")


    # Phase 1 - delete the 'never run' cycles
    try:
        with conn.cursor() as cursor:
            logger.debug(f"Phase 1.  Retrieving all old 'never run' Cycles.")

            # This SQL selects all Sequence records where neither half of the event is complete.  
            sql_judicious_notrun = "SELECT \
                A1.sequence_id              AS on_sequenceid, \
                A1.cycle_id                 AS master_cycleid, \
                A1.event_function, \
                A1.event_completed_date, \
                A2.sequence_id              AS off_sequenceid, \
                A2.cycle_id, \
                A2.event_function, \
                A2.event_completed_date \
                FROM sequence A1 \
                INNER JOIN sequence A2 \
                ON A1.cycle_id = A2.cycle_id \
                WHERE A1.event_function = 1 \
                AND A2.event_function = 0 \
                AND A1.event_completed_date IS NULL \
                AND A2.event_completed_date IS NULL;"

            cursor.execute(sql_judicious_notrun)

            # Fetch all rows
            rows = cursor.fetchall()
            sql_rowcount = cursor.rowcount
            logger.debug(f"  Query returned [{sql_rowcount}] 'never run' Cycles.")

            delete_counter = 0
            for count, value in enumerate(rows):
                # We could delete these records by sequence_id, for both halves of the cycle, but we can do it in one SQL delete
                # by deleting based on cycle_id
                with conn.cursor() as cursor:
                    sql_delete_neverrun = f"DELETE FROM sequence WHERE cycle_id = {value['master_cycleid']}"
                    cursor.execute(sql_delete_neverrun)
                    delete_counter +=1
                    conn.commit()
            logger.debug(f"  Deleted [{delete_counter}] 'never run' Cycles.")
    except pymysql.Error as e:
        logger.debug(f"ERROR in SQL Phase 1.    [{e.args[0]}] [{e.args[1]}]")

    
    # Phase 2 - delete the 'fully run' cycles
    try:
        with conn.cursor() as cursor:
            logger.debug(f"Phase 2.  Retrieving all old 'fully run' Cycles.")

            # This SQL selects all Sequence records where both halves of the event are complete.  
            sql_judicious_fullyrun = "SELECT \
                A1.sequence_id              AS on_sequenceid, \
                A1.cycle_id                 AS master_cycleid, \
                A1.event_function, \
                A1.event_completed_date, \
                A2.sequence_id              AS off_sequenceid, \
                A2.cycle_id, \
                A2.event_function, \
                A2.event_completed_date \
                FROM sequence A1 \
                INNER JOIN sequence A2 \
                ON A1.cycle_id = A2.cycle_id \
                WHERE A1.event_function = 1 \
                AND A2.event_function = 0 \
                AND A1.event_completed_date IS NOT NULL \
                AND A2.event_completed_date IS NOT NULL;"

            cursor.execute(sql_judicious_fullyrun)

            # Fetch all rows
            rows = cursor.fetchall()
            sql_rowcount = cursor.rowcount
            logger.debug(f"  Query returned [{sql_rowcount}] 'fully run' Cycles.")

            delete_counter = 0
            for count, value in enumerate(rows):
                # We could delete these records by sequence_id, for both halves of the cycle, but we can do it in one SQL delete
                # by deleting based on cycle_id
                with conn.cursor() as cursor:
                    sql_delete_fullyrun = f"DELETE FROM sequence WHERE cycle_id = {value['master_cycleid']}"
                    cursor.execute(sql_delete_fullyrun)
                    delete_counter +=1
                    conn.commit()
            logger.debug(f"  Deleted [{delete_counter}] 'fully run' Cycles.")
    except pymysql.Error as e:
        logger.debug(f"ERROR in SQL Phase 2.    [{e.args[0]}] [{e.args[1]}]")



    # Phase 3 - just because we can, lets find out how many 'in progress' cycles we have left.
    # Nothing happens with these - just the number of them gets logged.
    try:
        with conn.cursor() as cursor:
            logger.debug(f"Phase 3.  Retrieving all 'in progress' Cycles.")

            # This SQL selects all Sequence records where the turn on is complete, but the turn off remains incomplete
            sql_judicious_halfrun = "SELECT \
                A1.sequence_id              AS on_sequenceid, \
                A1.cycle_id                 AS master_cycleid, \
                A1.event_function, \
                A1.event_completed_date, \
                A2.sequence_id              AS off_sequenceid, \
                A2.cycle_id, \
                A2.event_function, \
                A2.event_completed_date \
                FROM sequence A1 \
                INNER JOIN sequence A2 \
                ON A1.cycle_id = A2.cycle_id \
                WHERE A1.event_function = 1 \
                AND A2.event_function = 0 \
                AND A1.event_completed_date IS NOT NULL \
                AND A2.event_completed_date IS NULL;"

            cursor.execute(sql_judicious_halfrun)

            # Fetch all rows
            rows = cursor.fetchall()
            sql_rowcount = cursor.rowcount
            logger.debug(f"  Query returned [{sql_rowcount}] 'in progress' Cycles. ")
            logger.debug(f"  All 'in progress' Cycles are retained for normal completion.")
    except pymysql.Error as e:
        logger.debug(f"ERROR in SQL Phase 3.    [{e.args[0]}] [{e.args[1]}]")

    logger.debug("---- Judicious Purge complete.")





# ---- Get the day name given a date
def getDayNameFromDate(argDate):
    # This is useful for translating the day number to a day name
    days = ["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"]
    local_weekdaynumber = argDate.weekday()
    dayName = days[local_weekdaynumber]
    return dayName





def processScheduleRecord(arg_rownumber, arg_rowdata, arg_batchid):
    logger.debug(f"Now processing Schedule ID [{arg_rowdata['schedule_id']}].  This is row [{arg_rownumber + 1}] from Schedule.")
    # logger.debug(arg_rowdata)
    
    # These counters are used for statistics only
    count_weekday = 0
    count_weekend = 0
    tally_weekday = 0
    tally_weekend = 0

    # So we have a Schedule record, which will generate one or more Cycles 
    # (where each Cycle is a turn on event followed by a turn off event.)
    
    # This is useful for translating the day number to a day name
    days = ["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"]
    # Step 1 - Find out whether we have a weekday (type 5) or weekend (type 2) schedule
    if arg_rowdata['schedule_type'] == 2:
        my_scheduletype = "weekend"
    elif arg_rowdata['schedule_type'] == 5:
        my_scheduletype = "weekday"
    logger.debug(f"Schedule type is [{my_scheduletype}]")

    # Step 2 - Find out how many days we have to process in the current month.
    my_datenow = datetime.now().astimezone(AEST)                # Specify the timezone
    my_currentMonth = my_datenow.month
    my_currentYear = my_datenow.year


    my_daysinmonth = calendar.monthrange(my_currentYear, my_currentMonth)[1]
    logger.debug(f"  Current Month is [{my_currentMonth}].")  
    logger.debug(f"  We have [{my_daysinmonth}] days to process in this month.")

    # Loop through the days in the month and when we come to a day that matches the schedule type (weekday or weekend) do the maths.
    for x in range(my_daysinmonth):
        # Create the datetime object for this date 
        my_dotm = datetime(my_currentYear, my_currentMonth, x+1)
        logger.debug(f'Examine date [{my_dotm.strftime("%d/%m/%y")}].')

        # Now determine the weekday number for this date so we know if the day is a week day or a weekend day
        my_thisweekdaynumber = my_dotm.weekday()
        logger.debug(f"  Day Number is [{my_thisweekdaynumber}].")
        if my_thisweekdaynumber == 0 or my_thisweekdaynumber == 1 or my_thisweekdaynumber == 2 or my_thisweekdaynumber == 3 or my_thisweekdaynumber == 4:
            my_daytype = "weekday"
            count_weekday += 1
        else: 
            my_daytype = "weekend"
            count_weekend += 1
        logger.debug(f"  Day type is [{my_daytype}].  It is a [{days[my_thisweekdaynumber]}].")

        
        # Now see if the day type matches the schedule type
        if my_scheduletype == "weekday" and my_daytype == "weekday":
            logger.debug("  Candidate for weekday schedule here.")
            # do stuff here
            result_weekday = createSequenceCycle(arg_batchid, my_dotm, arg_rowdata['schedule_id'], arg_rowdata['device_id'], arg_rowdata['trigger_weighting'], arg_rowdata['turn_on_time'], arg_rowdata['turn_on_flex'], arg_rowdata['active_duration'], arg_rowdata['active_duration_flex'])
            tally_weekday += result_weekday

        if my_scheduletype == "weekend" and my_daytype == "weekend":
            logger.debug("  Candidate for weekend schedule here.")
            # do stuff here
            result_weekend = createSequenceCycle(arg_batchid, my_dotm, arg_rowdata['schedule_id'], arg_rowdata['device_id'], arg_rowdata['trigger_weighting'], arg_rowdata['turn_on_time'], arg_rowdata['turn_on_flex'], arg_rowdata['active_duration'], arg_rowdata['active_duration_flex'])
            tally_weekend += result_weekend

    
    # Clear the 'is_dirty' flag on this Schedule record.
    setScheduleDirtyFlag(arg_rowdata['schedule_id'], 0)
    
    
    
    # Calculate the statistical result for this Schedule record
    percent_weekday = int(tally_weekday / count_weekday * 100)
    percent_weekend = int(tally_weekend / count_weekend * 100)

    logger.debug("-------------------------------------------------------------------")
    logger.debug(f"Statistics from the processing of Schedule record [{arg_rownumber + 1}] follow ...")
    logger.debug(f" Total weekdays  = [{count_weekday}]    \tTotal weekend days  = [{count_weekend}]")
    logger.debug(f" Weekday cycles  = [{tally_weekday}]    \tWeekend cycles      = [{tally_weekend}]")
    logger.debug(f" Weekday percent = [{percent_weekday}]  \tWeekend percent     = [{percent_weekend}]")
    logger.debug("-------------------------------------------------------------------")
    


# ---- Create Sequence Data ready for SQL insertion
def createSequenceCycle(arg_batchid, arg_date, arg_schedulid, arg_deviceid, arg_triggerweighting, arg_turnontime, arg_turnonflex, arg_durationtime, arg_durationflex):
    # This function builds the data fields ready to insert into the SQL database.  It performs the maths surrounding the randomness
    # and ends up with the turn on and turn off records for SQL.  These records are always created in pairs.
    # This function expects all the broken out parameters from the previous function.  We do not just pass the whole schedule record
    # as some of it is not needed here.  
    # This same function handles weekday sequence and weekend sequence as the logic is identical.
    # All variables to use in SQL start with "seqon_" or "seqoff_".  

    logger.debug(f'  Function.  Potential to build sequence record for date [{arg_date}] using Batch [{arg_batchid}].')
    # The date field here is the nominal date for the turn on event, however if the actual turn on is near the end of day and the lag 
    # pushes it over midnight, then the resulting date in the DB will be the next day.
    '''
    print("--- Dump of received arguments -------------------------")
    print(f"  1  arg_date ................ {arg_date}")
    print(f"  2  arg_schedulid ........... {arg_schedulid}")
    print(f"  3  arg_deviceid ............ {arg_deviceid}")
    print(f"  4  arg_triggerweighting .... {arg_triggerweighting}")
    print(f"  5  arg_turnontime .......... {arg_turnontime}")
    print(f"  6  arg_turnonflex .......... {arg_turnonflex}")
    print(f"  7  arg_durationtime ........ {arg_durationtime}")
    print(f"  8  arg_durationflex ........ {arg_durationflex}")
    print("--------------------------------------------------------")
    '''

    # The first step is to determine if we will even create a sequence event for this day.  That is based on the Trigger Weighting
    # This works as follows.
    # Generate a random number from 1 - 100
    # See hos it compares withthe supplied Trigger Weighting
    # If the generated number <= supplied parameter, then proceed with the effort to create a sequence record.


    my_decider = random.randint(1, 100)
    logger.debug(f"  Random 'Decider Value' for this day is [{my_decider}].  Trigger value set at [{arg_triggerweighting}].")

    if my_decider <= arg_triggerweighting:
        logger.debug("  Decider is <= Trigger so a Cycle will be created for this date.")

        # Now copy the parameters which do not change striaght from input to output.  Prepare both ON oand OFF data sets.  
        # If the ON and OFF parameters are the same, just prepare one of them and omit the on or off in the name.
        seq_schedulid = arg_schedulid
        seq_deviceid = arg_deviceid
        
        

        # The Cycle ID in the Sequence table has to be identical for the associated Turn ON and Turn OFF events; after all this is what associates them.
        # Because we have no state, we need to generate the Cycle ID in this function, with resonable guarantee it will be unique.
        # The Cycle ID is calculated from some maths as follows.
        # Multiply ScheduleID * 100 (This should be big enough as it unlikely we will ever have > 100 schedules in the same day)
        # Add the product of day and month
        # Add the hash of turnon time
        # Add the hash of duration
        # Add the hash of the entity name "abs(hash(s)) % (10 ** 8)"
        # Add the hash of the current time.  This ensures the repeated run of the same processing will generate a unique Cycle on subsequent runs.

        
        # Hopefully this creates a sufficiently unique result
        epoch_time = int(time.time())
        seq_cycleid = arg_schedulid * 100
        seq_cycleid += (arg_date.day * arg_date.month)
        seq_cycleid += abs(hash(arg_turnontime)) % (10 ** 8)
        seq_cycleid += abs(hash(arg_durationtime)) % (10 ** 8)
        seq_cycleid += abs(hash(arg_deviceid)) % (10 ** 8)
        seq_cycleid += abs(hash(epoch_time)) % (10 ** 8)
        seq_cycleid += seq_schedulid * 100 + seq_deviceid          # Added this to increase complexity
        seq_cycleid = abs(hash(seq_cycleid)) % (7 ** 6)
        
        
        logger.debug(f"  Cycle ID determined as [{seq_cycleid}] from epoch [{epoch_time}].")
        
        # ------ Turn ON stuff
        # The event turn on time needs the date + the Schedule TurnOn Time + the ramdomisation Flex value
        # Firstly convert the supplied "turn on time" in HH:MM to minutes so it can be used in the timedelta 
        t=str(arg_turnontime).split(':')
        turnontime_minutes= int(t[0])*60 + int(t[1])*1     # Ignore any seconds if they exist
        # logger.debug(f"  Turn on time in minutes is [{turnontime_minutes}].")

        # Now create a proper datetime object using the supplied date and calculated number of minutes
        fq_eventdt = arg_date + timedelta(minutes=turnontime_minutes)
        # logger.debug(f"  Determined event datetime as [{fq_eventdt}]")
        
        # Now add the Flex random value to the event date
        # Calculate the actual flex value for turn on
        value_turnonflex = random.randint(0, arg_turnonflex)
        # logger.debug(f"  Turn on Flex Delay determined as [{value_turnonflex}].")
        real_turnoneventtime = fq_eventdt + timedelta(minutes=value_turnonflex)
        # logger.debug(f"  Determined event datetime with Flex Random as [{real_turnoneventtime}]")
        seqon_eventtime = real_turnoneventtime
        # Get the day name which is used for decoration only in the table.
        seqon_dayname = getDayNameFromDate(seqon_eventtime)
        seqon_eventfunction = 1
        logger.debug(f"    arg_turnon [{arg_turnontime}].  arg_turnonflex [{arg_turnonflex}].  value_turnonflex [{value_turnonflex}]. Real Turnon [{seqon_eventtime}]")
        
        # ------ Turn OFF stuff
        # The Event turn off time is the real turn on time plus the duration plus the flex randomisation duration
        # As above, calculate the actual flex value for duration
        value_durationflex = random.randint(0, arg_durationflex)
        # logger.debug(f"  Duration Flex determined as [{value_durationflex}].")

        real_duration = arg_durationtime + value_durationflex
        seqoff_eventtime = real_turnoneventtime + timedelta(minutes=real_duration)
        # Get the day name which is used for decoration only in the table.
        seqoff_dayname = getDayNameFromDate(seqoff_eventtime)

        seqoff_eventfunction = 0
        logger.debug(f"    arg_duration [{arg_durationtime}].  arg_durationflex [{arg_durationflex}].  value_durationflex [{value_durationflex}]. Real Duration [{real_duration}]. Real Turnoff [{seqoff_eventtime}].")

        # The only remaining values are 
        # - the completion date, which remains NULL until the Conductor executes this event
        # - the device specific commands which come from the Schedule, so now write the two SQL records

        # Before writing the sequence records, confirm the following
        # 1. Confirm turn off is later than turn on.   
        # 2. Check that there are no overlaps in turn on or turn off.  This is hard to do and is not currently done.

        # Sanity Check #1 - check the turn off is not earlier than the turn on for this cycle.  They can be the same (which is silly) but not earlier.
        duration_delta = seqoff_eventtime - seqon_eventtime
        time_on_seconds = int(duration_delta.total_seconds())
        time_on_minutes = int(duration_delta.total_seconds() / 60)
        logger.debug(f"    On time calculated as [{time_on_minutes}] minutes.")
        if time_on_seconds <= 0:
            logger.debug(f"WARNING.  The on time [{time_on_seconds}] for this cycle appears to be zero or negative (turn OFF precedes turn ON).") 


        # Connect to the SQL database ready to write the records.
        conn =pymysql.connect(
            host=sql_host,
            user=sql_username,
            password=sql_password,
            db=sql_database,
            charset='utf8mb4',
            cursorclass=pymysql.cursors.DictCursor
        )

        # Run the insert for the switch ON events
        try:
            with conn.cursor() as cursor:
                sql_insert = "INSERT INTO `sequence` (`schedule_id`, `cycle_id`, `device_id`, `event_datetime`, `event_dayname`, `event_function`, `event_ontime`, `batch_id`) VALUES (%s, %s, %s, %s, %s, %s, %s, %s)"
                cursor.execute(sql_insert, (seq_schedulid, seq_cycleid, seq_deviceid, seqon_eventtime, seqon_dayname, seqon_eventfunction, time_on_minutes, arg_batchid))
                conn.commit()
                
                sql_rowcount = cursor.rowcount
                logger.debug(f"  Inserted [{sql_rowcount}] new Switch ON record.")
        
        except pymysql.Error as e:
            logger.error(f"ERROR in SQL during Switch ON write.    [{e.args[0]}] [{e.args[1]}]")
 
        finally:
            pass
            # logger.debug("  Insert completed for ON record.")

        # Run the insert for the switch OFF events
        try:
            with conn.cursor() as cursor:
                sql_insert = "INSERT INTO `sequence` (`schedule_id`, `cycle_id`, `device_id`, `event_datetime`, `event_dayname`, `event_function`, `batch_id`) VALUES (%s, %s, %s, %s, %s, %s, %s)"
                cursor.execute(sql_insert, (seq_schedulid, seq_cycleid, seq_deviceid, seqoff_eventtime, seqoff_dayname, seqoff_eventfunction, arg_batchid))
                conn.commit()
                
                sql_rowcount = cursor.rowcount
                logger.debug(f"  Inserted [{sql_rowcount}] new Switch OFF record.")
        
        except pymysql.Error as e:
            logger.error(f"ERROR in SQL during Switch OFF write.    [{e.args[0]}] [{e.args[1]}]")
 
        finally:
            conn.close()
            logger.debug("  MySQL connection is closed.")




        return 1
    else:
        logger.debug("  Cycle will not be created for this day.")
        return 0



# ---- Set the vlue of the 'is_dirty' flag on a given Schedule record
def setScheduleDirtyFlag(arg_scheduleid, arg_flagvalue):
    # This function will set the 'is_dirty' flag whichever way it needs to be set.  
    # Mostly it needs to be cleared (by setting the value to zero).

    try:
        with conn.cursor() as cursor:
            logger.debug(f"Setting the 'is_dirty' flag on Schedule ID [{arg_scheduleid}] to [{arg_flagvalue}].")
    
            sql_clearisdirty = f"UPDATE schedule SET is_dirty={arg_flagvalue} WHERE schedule_id={arg_scheduleid};"
            cursor.execute(sql_clearisdirty)
            conn.commit()

    except pymysql.Error as e:
        logger.debug(f"ERROR in SQL Phase 0.    [{e.args[0]}] [{e.args[1]}]")




# ---- Purge Expired Sequence events
def purgeExpiredEvents():
    '''
    Expired events are where both Turn on and Turn off are in the past.
        (event_completed_date remains as NULL)
    As long as both the ON eventtime and to OFF eventtime are in the past, these events are stale
    and need to be deleted before they are seen by any process.  These events will have just been generated.
    These expired events have to be purged before the Conductor gets to process due events
    as we never want these old expired events to be processed.
    If a Cycle has the ON time in the past and the OFF time in the future, it will be treated just like any
    'due' event when the Conductor grabs it.  
    This purge is intended to run after the Sequence has been rgenerated to purge the events which were created
    for days erlier in the month than today.

    '''
    # try:
    #     with conn.cursor() as cursor:
    # Select expired events
    logger.debug(f"Selecting expired Cycles to purge.")
    sql_purge1 = "SELECT \
        sequence.sequence_id              AS on_sequenceid \
        , sequence.schedule_id \
        , sequence.cycle_id                 AS on_cycleid \
        , sequence.device_id \
        , sequence.event_datetime           AS on_time \
        , sequence.event_function \
        , sequence.event_completed_date     AS on_completeddate \
        , sequence_1.sequence_id            AS off_sequenceid \
        , sequence_1.schedule_id \
        , sequence_1.cycle_id               AS off_cycleid \
        , sequence_1.device_id \
        , sequence_1.event_datetime         AS off_time \
        , sequence_1.event_function \
        , sequence_1.event_completed_date   AS off_completeddate \
        FROM sequence \
        INNER JOIN sequence AS sequence_1 ON sequence.cycle_id = sequence_1.cycle_id \
        WHERE sequence.event_function=1 \
        AND sequence_1.event_function=0 \
        AND sequence.event_datetime <= NOW() \
        AND sequence_1.event_datetime <= NOW() \
        ;"

    cursor.execute(sql_purge1)

    # Fetch all rows
    rows = cursor.fetchall()
    sql_rowcount = cursor.rowcount
    
    logger.debug(f"  Query returned [{sql_rowcount}] expired Cycles eligible for purge.")

    for rowdata in rows:
        # Now they really need to be deleted
        logger.debug(f"  Deleting Cycle ID [{rowdata['on_cycleid']}].")
        sql_delete = f"DELETE FROM sequence WHERE cycle_id = {rowdata['on_cycleid']};" 
        cursor.execute(sql_delete)
        conn.commit()
    
    
    logger.debug("  Purge complete for expired Sequence records")

    # except pymysql.Error as e:
    #     logger.debug(f"ERROR in SQL Phase 0.    [{e.args[0]}] [{e.args[1]}]")



# ==== MAIN CODE ======================================================================================================
print("\n\n\n\n\n================================================================================================")
print("Startup ...")


# ----- Confirm the necessary CLI parameters
if len(sys.argv) < 3:
    print("ERROR.  Found " + str(len(sys.argv) - 1) +
          " CLI parameters.  \n\tSpecify the following two command line parameters in order.  " +
          "\n\t  1) The fully qualified name of the local YAML config file, and " +
          "\n\t  2) The fully qualified name of the local (OS dependant) message log file. ")
    exit(2)
else:
    yaml_configuration_file = sys.argv[1]
    print("  YAML configuration will be retrieved from \t\t[" + yaml_configuration_file + "]")
    log_location = sys.argv[2]
    print("  Python logging system messages will be stored at \t[" + log_location + "]")



# ---- Use the python logging system to write log messages (advanced method).
try:
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    handler3 = logging.handlers.TimedRotatingFileHandler(log_location, when='midnight', backupCount=30)
    handler3.setLevel(logging.DEBUG)
    formatter = logging.Formatter('%(asctime)s %(name)s %(levelname)s \t%(message)s')
    handler3.setFormatter(formatter)
    logger.addHandler(handler3)

except:
    logger.error("\nERROR 10.  Something broke in the logging setup.\nQuitting now.\n\n\n")
    exit(2)



logger.debug("---------------------------------------------------------------------------- ")  # Readability only
logger.debug("Script name is .... [" + str(sys.argv[0]) + "]")
logger.debug("Config file YAML .. [" + yaml_configuration_file + "]")
logger.debug("OS detected as .... [" + platform.system() + "]")

AEST = pytz.timezone("Australia/Brisbane")
print("Local time   {}".format(datetime.now().astimezone(AEST)))
logger.debug("Local time ........ [{}]".format(datetime.now().astimezone(AEST)))
logger.debug(f"Timezone  ......... [{AEST.zone}]")
logger.debug("---------------------------------------------------------------------------- ")  # Readability only


# ---------- Get the YAML configuration
yaml_config_data = yaml_loader(yaml_configuration_file)       # Load the YAML configuration data based on command line arg.

# ---------- Set operating parameters from the retrieved YAML configuration data
logger.debug("Getting configuration parameters from YAML configuration file.")
try:
    # Get the parameters from YAML
    sql_host        = yaml_config_data['sql_connection']['sql_host']
    sql_username    = yaml_config_data['sql_connection']['sql_username']
    sql_password    = yaml_config_data['sql_connection']['sql_password']
    sql_database    = yaml_config_data['sql_connection']['sql_database']

    create_sdd = yaml_config_data['planner_rules']['create_sequence_for_disabled_devices']

    mife_host          = yaml_config_data['mife_connection']['mife_host']
    mife_port          = yaml_config_data['mife_connection']['mife_port']
    mife_path          = yaml_config_data['mife_connection']['mife_path']
    mife_client_name   = yaml_config_data['mife_connection']['mife_client_name']

    alert_subject      = yaml_config_data['mife_boilerplate']['message_subject']

except:
    logger.error("ERROR 20.  Unable to parse YAML configuration data.  Check the config file for errors.")
    exit(2)


my_alert_counter = 0        # Increment this only if an alert needs to be sent

logger.debug("  ----- General parameters used for these queries ------") 
logger.debug(f'  SQL Server used  ........ [{sql_host}].')
logger.debug(f'  SQL Database used  ...... [{sql_database}].')
# logger.debug(f'  SQL Username  ........... [{sql_username}].')
# logger.debug(f'  SQL Password  ........... [{sql_password}].')

logger.debug("  ------------------------------------------------------")



# Connect to the SQL database
conn =pymysql.connect(
  host=sql_host,
  user=sql_username,
  password=sql_password,
  db=sql_database,
  charset='utf8mb4',
  cursorclass=pymysql.cursors.DictCursor
)

# For testing purposes, delete all the test data in the sequence table
testing = 0
if testing:
    logger.debug("WARNING.  Testing mode enabled so all existing sequence data will be deleted before new records are inserted.")
    with conn.cursor() as cursor:
        sql_delete = "DELETE FROM sequence"
        cursor.execute(sql_delete)
        conn.commit()
        logger.debug(f"  Deleted [{cursor.rowcount}] sequence records.")
else:
    logger.debug("Existing records have not been bulk purged from Sequence.")


'''
    Under normal (production) conditions, the sequence table could be rebuilt at any time.  Two possibly bad things can arise as follwos.
    1.  If the old sequence data is retained, we will end up with lots of turn on and turn off records for each device as a new set of cycles
        will be added each time we run.  This is bad.
    2.  If we delete all the sequence records firts, then we risk splitting a cycle.  This is where the 'turn on' event has happened but
        the corresponding 'turn off' has yet to fire.  If we purge all the records, then this device could be left in a 'turned on' state
        with no matching 'turn off'.  This is also bad.

    To avoid this, we need a more considered purge of sequence records.  Essentially we want to keep only the 'in progress' cycles and delete
    all the completed cycles and all the not-yet-started cycles, so this is what happens here.

    The Conductor does manage some of this purge of old records, but managing the tidy up here is a more elegant approach.
    This clean up happens before the new data gets generated and dumped into the table.  This is not ot be confused with the 
    post generation purge which purges expired Cycles as discussed below.

'''
# Do a preliminary tidy up of the Sequence table before starting
judicious_purge_sequence()


# This is the beginning of the Sequence generation.  
# Select devices to include.
logger.debug(f"=== Start actual sequence rebuild.")

logger.debug(f"..The setting for 'create_sequence_for_disabled_devices' is [{create_sdd}].")
# Set up the additional SQL clause depending on the above option
# This will determine if the sequence is built for disabled devices
# This parameter is set in the YAML file.  Recommended setting is 'False'.
if create_sdd == False:
    sql_extensionclause = "AND devices.device_active = 1"
else:
    sql_extensionclause = ""

try:
    with conn.cursor() as cursor:
        logger.debug(f"..Retrieving active Schedule records.")
        sql = f"SELECT \
              schedule.schedule_id \
            , schedule.device_id \
            , schedule.schedule_enable \
            , schedule.schedule_type \
            , schedule.trigger_weighting \
            , schedule.turn_on_time \
            , schedule.turn_on_flex \
            , schedule.active_duration \
            , schedule.active_duration_flex \
            , schedule.comment \
            FROM `schedule` \
            INNER JOIN devices ON schedule.device_id = devices.device_id \
            WHERE schedule_enable = 1 \
            {sql_extensionclause};"

        cursor.execute(sql)
        rows = cursor.fetchall()
        sql_rowcount = cursor.rowcount
        logger.debug(f"..Found [{sql_rowcount}] available Schedule records (based on device availability).")

        # Get a batch number to tag all the Sequence records created in this run
        my_batchid = getBatchNumber(conn, "ProcessScheduleRecoords")

        for count, value in enumerate(rows):
            #print(value)
            processScheduleRecord(count, value, my_batchid)

        # Now that we have a working Sequence, we need to delete events created for dates in the past.
        logger.debug("Sequence rebuild completed.  Expired events will now be purged.")
        purgeExpiredEvents()



finally:
    conn.close()

logger.debug("=== Planner is complete ===")