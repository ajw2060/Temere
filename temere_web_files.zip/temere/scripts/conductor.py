
# Temere Conductor

# This script is part of the Temere Random Scheduler tool.  This script does the following
#
# - connects to the SQL database 
# - reads the Sequence table.
# - processes each Sequence record and turn something on or off as per the sequence.
# - Updates the Sequence record as pricessed
#
# 
# Change History
#   2023-08-03  Initial version.
#   2023-08-06  Added support for CLI parameters
#   2023-10-31  Fixed case error in SQL in new_purge
#   2023-10-31  Added feature to check month of existing sequence file.  If it is no longer current, then run the planner to regenerate it.

#

from datetime import date, datetime, timedelta, timezone
import pytz                 # Used to get local time based on timezone
import os
import logging
import logging.handlers
import platform
import sys
import yaml
import warnings
import calendar
import random
import subprocess
import math
import pymysql              # import mysql.connector


# ---------- Configuration load from YAML -----------------------------------------------------------------------------
def yaml_loader(filepath):
    try:
        with open(filepath, "r") as file_descriptor:
            config_data = yaml.load(file_descriptor, Loader=yaml.FullLoader)    # Should avoid the unsafe warning
        return config_data
    except:
        print(f"ERROR 5.  YAML loader unable to load configuration file [{filepath}].")
        exit(5)


# Add the 2 lines below to ignore unverified certificate warnings
#warnings.filterwarnings("ignore")

# ---- Send a message using the MiFe service
def send_mife(arg_subject, arg_message_plain, arg_message_tel, arg_message_html):
    # Prepare the base dictionary to build the JSON object used in the body of MiFe.
    logger.debug("Calling MiFe to deliver this message.")
    
    mife_message_body = dict()          # Use this form to create the empty dict
    mife_message_body['client_name'] = mife_client_name            # Use in prod
    #mife_message_body['client_name'] = 'TestClient'                 # Use in dev
    mife_message_body['delivery_services'] = ['telegram','email']
    #mife_message_body['delivery_services'] = ['email']
    mife_message_body['subject'] = arg_subject
    mife_message_body.update({'body': {'message_txt': arg_message_plain}})      # May be a better way to add a new dict to the current dict, but this works.
    mife_message_body['body']['message_tel'] = arg_message_tel
    mife_message_body['body']['message_html'] = arg_message_html
    
    
    # ---- Prepare the MiFe URL
    mife_url = f'http://{mife_host}:{mife_port}/{mife_path}'
    #print("MiFe URL ==>" + mife_url)
    #print(mife_message_body)

    # Convert the dict to a JSON object
    json_message_body = json.dumps(mife_message_body)

    r = requests.post(mife_url, headers={"content-type":"application/json"}, data=json_message_body)
    #print(str(r.status_code))
    if ((r.status_code) == 200):
        logger.debug("MiFe success. Status=[" + str(r.status_code) + "].")
        logger.debug(f"Response ==> {r.text}")
    else:
        logger.error("ERROR 601.  MiFe failed.  Status [" + str(r.status_code) + "].  Message [" + str(r.content) + "].")

    
# ---- Process a row from the Sequence    
'''
    These are the rules for processing Sequence events
    
    - The Conductor runs periodically under cron schedule.  It is intended to run every five minutes, but the frequency may be increased or 
      reduced as desired.

    - The Conductor is responsible for purging old events from the Sequence so as each event fires, the flag is set to say it is complete.  
      When event pairs complete the pair of events (known as a cycle) will be deleted (but at a later date).

    - Not every event will be a Cycle.  In the future the Sequence may also be used to kick off things like backup, so these do not have
      a turn on followed by a turn off, so not every event will have a partner event.

    - Each time the Conductor runs, it needs to do a preliminary tidy up of the Sequence to purge old Cycles.  Where both halves of the Cycle
      are in the past the records get purged - regardless of whether or not the event has been run.  In any case, it is too late.

    - Sequence events with no partner (other half of the cycle) and which are due could be a freestanding trigger (for backup etc) and need to be handled 
      with more care.  As these event types do not yet exist, this handling remains undefined.

    - Remaining Sequence events are then queried to find those which are "not run" and are "due".  Due is considered when there is an event where the 
      event time is in the past, but it has not been run.  There is no intention to check for the presence of a partner event in the future.
      The assumption is that some other pass of the Conductor will manage the associated turn off (assuming it exists).
      
    - These "due" events will be run by executing the instructions in the record and flagging the entry as run.  The record is not deleted at this time
      as it is held for historical purposes and only deleted when both halves of the Cycle are complete.
    
    - The usual logging is maintained.

'''


# ---- Get the day name given a date
def getDayNameFromDate(argDate):
    # This is useful for translating the day number to a day name
    days = ["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"]
    local_weekdaynumber = argDate.weekday()
    dayName = days[local_weekdaynumber]
    return dayName



# ---- Get a new batch number to use elsewhere
def getBatchNumber(conn, arg_requester):
    # This function simply cretes a new batch record for the requester and returns the corresponding batch ID
    # The batch number is used as a tracking or audit ID in other tables so we can follow when things such as a 
    # Sequence record were created.
    try:
        with conn.cursor() as cursor:   
            logger.debug(f"Creating new batch number for client called [{arg_requester}].")
            sql_timezone = 'SET @@session.time_zone = "+10:00";'
            cursor.execute(sql_timezone)    
            conn.commit()
            now = datetime.now().astimezone(AEST).strftime('%Y-%m-%d %H:%M:%S')
            sql_newbatch = "INSERT INTO batch (batch_date, batch_requester) VALUES (%s, %s)"
            cursor.execute(sql_newbatch, (now, arg_requester))
            conn.commit()
            my_batchid = cursor.lastrowid
            logger.debug(f"..Batch number [{my_batchid}] created.")
    finally:
        cursor.close()
    return my_batchid







# ---- Purge completed Cycles
def newPurge(cursor, arg_timetokeep):
    '''
    This function joins the Sequence table to itself on the Cycle ID so we see both halves of the cycle in
    one select.

    This old event purge considers two sets of old records as follows.
    Phase 1 - Expired events.
        These are where BOTH Turn on and Turn off are in the past and neither has been completed 
        (event_completed_date remains as NULL)
        As long as both the ON eventtime and to OFF eventtime are in the past, these events are stale
        and need to be deleted.  This does not care that the events were never processed as it now too late.
        This could happen if conductor has not run for some time and a bunch f events have expired.
        These expired events have to be purged before due events are processed as we never want these 
        old expired events to be processed.  This is rather redundant as this is handled in Planner.
    
    Phase 2 - Completed events kept for posterity.
        These events are marked as complete on both halves, but are retained for decoration in the Sequence table
        because it is interesting to see when they were due to run and when they actually ran.  This is visible
        in the Cycles report.  However not all old Cycles are retained.  The configuration value indicates how far 
        back these completed Cycles are retained.  In any case the data is purged when the Sequence gets rebuilt.
        The 'event_timetokeep' setting controls how long old cycles are retained.  
    
    If just the ON event is in the past and the OFF remains in the future, then 
    is is considered a 'due' event and needs to be processed (and will therefore not get purged here).
    '''

    # Phase 1 - delete expired events
    logger.debug(f"Phase 1 - Selecting expired Cycles to purge.")
    sql_purge1 = "SELECT \
          sequence.sequence_id              AS on_sequenceid \
        , sequence.schedule_id \
        , sequence.cycle_id                 AS on_cycleid \
        , sequence.device_id \
        , sequence.event_datetime           AS on_time \
        , sequence.event_function \
        , sequence.event_completed_date     AS on_completeddate \
        , sequence_1.sequence_id            AS off_sequenceid \
        , sequence_1.schedule_id \
        , sequence_1.cycle_id               AS off_cycleid \
        , sequence_1.device_id \
        , sequence_1.event_datetime         AS off_time \
        , sequence_1.event_function \
        , sequence_1.event_completed_date   AS off_completeddate \
        FROM sequence \
        INNER JOIN sequence AS sequence_1 ON sequence.cycle_id = sequence_1.cycle_id \
        WHERE sequence.event_function=1 \
        AND sequence_1.event_function=0 \
        AND sequence.event_datetime <= NOW() \
        AND sequence_1.event_datetime <= NOW() \
        AND sequence.event_completed_date IS NULL \
        AND sequence_1.event_completed_date IS NULL \
        ;"

    cursor.execute(sql_purge1)

    # Fetch all rows
    rows = cursor.fetchall()
    sql_rowcount = cursor.rowcount
    
    logger.debug(f"  Query returned [{sql_rowcount}] expired Cycles eligible for purge.")

    for rowdata in rows:
        # Now they really need to be deleted
        logger.debug(f"  Deleting ON sequence_id [{rowdata['on_sequenceid']}] for date [{rowdata['on_time']}].")
        sql_delete = f"DELETE FROM sequence WHERE sequence_id = {rowdata['on_sequenceid']};" 
        cursor.execute(sql_delete)
        conn.commit()
       
        logger.debug(f"  Deleting OFF sequence_id [{rowdata['off_sequenceid']}] for date [{rowdata['off_time']}].")
        sql_delete = f"DELETE FROM sequence WHERE sequence_id = {rowdata['off_sequenceid']};" 
        cursor.execute(sql_delete)
        conn.commit()
    
    # Phase 2     
    logger.debug(f"Phase 2 - Selecting old completed Cycles to purge.")
    
    # Sanitise the retention period
    if isinstance(arg_timetokeep, int):
        logger.debug(f"  Retention period from YAML is valid at [{arg_timetokeep}] days.")
    else:
        logger.debug(f"  Retention period taken from YAML is invalid [{arg_timetokeep}] and will be set to [30] days.")
        arg_timetokeep = 30

    logger.debug(f"  Completed Cycles older than [{arg_timetokeep}] days will be purged.")

    sql_purge2 = f"SELECT \
          sequence.sequence_id              AS on_sequenceid\
        , sequence.schedule_id \
        , sequence.cycle_id                 AS on_cycleid\
        , sequence.device_id \
        , sequence.event_datetime           AS on_time\
        , sequence.event_function \
        , sequence.event_completed_date     AS on_completeddate \
        , sequence_1.sequence_id            AS off_sequenceid\
        , sequence_1.schedule_id \
        , sequence_1.cycle_id               AS off_cycleid\
        , sequence_1.device_id \
        , sequence_1.event_datetime         AS off_time\
        , sequence_1.event_function \
        , sequence_1.event_completed_date   AS off_completeddate \
        FROM sequence \
        INNER JOIN sequence AS sequence_1 ON sequence.cycle_id = sequence_1.cycle_id \
        WHERE sequence.event_function=1 \
        AND sequence_1.event_function=0 \
        AND sequence.event_completed_date IS NOT NULL \
        AND sequence_1.event_completed_date IS NOT NULL \
        AND sequence_1.event_datetime <= DATE_ADD(now(), INTERVAL -{arg_timetokeep} DAY) \
        ;"

    cursor.execute(sql_purge2)

    # Fetch all rows
    rows = cursor.fetchall()
    sql_rowcount = cursor.rowcount
    
    logger.debug(f"  Query returned [{sql_rowcount}] past completed Cycles eligible for purge.")

    for rowdata in rows:
        # Now they really need to be deleted
        logger.debug(f"  Deleting ON sequence_id [{rowdata['on_sequenceid']}] for date [{rowdata['on_time']}].")
        sql_delete = f"DELETE FROM sequence WHERE sequence_id = {rowdata['on_sequenceid']};" 
        cursor.execute(sql_delete)
        conn.commit()
       
        logger.debug(f"  Deleting OFF sequence_id [{rowdata['off_sequenceid']}] for date [{rowdata['off_time']}].")
        sql_delete = f"DELETE FROM sequence WHERE sequence_id = {rowdata['off_sequenceid']};" 
        cursor.execute(sql_delete)
        conn.commit()
    
        
    
    logger.debug("--- Purge complete for old Sequence records ---")




# ---- Find and process events now due
def processDueEvents(cursor):
    # This function selects events which are due but not yet processed, and runs them.    
    # For an event to qualify the following must apply
    # Date is in the past
    # Event must not be complete (event_completed remains as NULL).  This field is populated once
    # the event is fired.
    logger.debug(f"==> Selecting events which are due but not yet completed.")

    sql_due = "SELECT\
    sequence.sequence_id              AS sequence_id,\
    sequence.schedule_id              AS schedule_id,\
    sequence.cycle_id                 AS cycle_id,\
    sequence.device_id                AS device_id,\
    sequence.event_datetime           AS event_datetime,\
    sequence.event_function           AS event_function,\
    sequence.event_completed_date     AS event_completeddate,\
    devices.device_name               AS device_name,\
    devices.device_description        AS device_description,\
    devices.device_vendor             AS device_vendor,\
    devices.device_active             AS device_active\
    FROM sequence\
    INNER JOIN devices ON sequence.device_id = devices.device_id\
    WHERE sequence.event_datetime <= NOW()\
    AND sequence.event_completed_date IS NULL\
    AND devices.device_active = TRUE;"

    cursor.execute(sql_due)

    # Fetch all rows
    rows = cursor.fetchall()
    sql_rowcount = cursor.rowcount
    
    logger.debug(f"  Query returned [{sql_rowcount}] events which are now due.")

    event_counter = 0                   # It needs to be incremented before use
    for rowdata_sequence in rows:
        event_counter += 1
        logger.debug(f"  Processing event [{event_counter} of {sql_rowcount}].")

        # Assign some friendly variable names
        my_deviceid = rowdata_sequence['device_id']
        my_devicename = rowdata_sequence['device_name']
        my_devicefunction = rowdata_sequence['event_function']
        my_sequenceid = rowdata_sequence['sequence_id']
        my_scheduleid = rowdata_sequence['schedule_id']
        
        logger.debug("    ---- Information -------------------------------------------")
        logger.debug(f"    Device ID ................ [{my_deviceid}]")
        logger.debug(f"    Device Name .............. [{my_devicename}]")
        logger.debug(f"    Device Function .......... [{my_devicefunction}]")
        logger.debug(f"    Sequence ID .............. [{my_sequenceid}]")
        logger.debug(f"    Schedule ID .............. [{my_scheduleid}]")
        logger.debug("    ------------------------------------------------------------")

        # Look up the Control Spec for this device
        my_controlspec = getControlSpec(conn, my_deviceid)
        logger.debug(f"Control spec GUID [{my_controlspec['device_guid']}]")

        # Confirm we received a Device GUID, as without this critical piece of information, nothing can be done.
        if (my_controlspec['device_guid'] is None):
            logger.debug(f"ERROR. The Control Spec GUID for [{my_devicename}] returned [None]. Nothing can happen.")
            logger.debug(f"Control spec [{my_controlspec['device_guid']}]")
        else:
            # Prepare some simple CLI parameters to pass to the script
            if my_devicefunction == 1:
                script_argfunction = "on"
            else:
                script_argfunction = "off"
            

            # Prepare the script itself
            control_script = my_controlspec['control_script']
            device_guid = my_controlspec['device_guid']


            script_path = "/var/www/html/temere/scripts/"
            my_script = f"{script_path}{control_script} {device_guid} {script_argfunction}"
            logger.debug(f"Script ==> [{my_script}]")
             
            result = subprocess.run([my_script], shell=True, capture_output=True, text=True)
            logger.debug(result)

        # Mark the event as complete
        markEventComplete(conn, my_sequenceid)

    logger.debug("--- Processing complete for all due events ---")





# ---- This just sets a evemt complete marker in the Sequence table.
def markEventComplete(conn, arg_sequenceid):
    # This function simply writes the current time into the 'event_completed_date' field in the
    # sequence table, thereby flagging it as complete.
    # Probably needs an error handler here.  TODO
    logger.debug(f"    ..Marking sequence_id [{arg_sequenceid}] as complete.")

    try:
        with conn.cursor() as cursor: 
            now = datetime.now().astimezone(AEST).strftime('%Y-%m-%d %H:%M:%S')
            sql_markcomplete = "UPDATE sequence SET event_completed_date = %s WHERE sequence_id = %s"
            cursor.execute(sql_markcomplete, (now, arg_sequenceid))
            conn.commit()
            my_rowcount = cursor.rowcount
            # logger.debug(f"  ..Update done.  Affected [{my_rowcount}] row()s).")
    finally:
        cursor.close()
    return 0


        
# ---- This returns the control spec needed to control this device.
def getControlSpec(conn, arg_deviceid):
    # This function retrieves the control spec for the specific device.
    logger.debug(f"    Retrieving the device Control Spec for Device ID [{arg_deviceid}].")
    cursor = conn.cursor()

    sql_spec = f"SELECT \
        devices.device_id, \
        devices.device_name, \
        devices.device_controlid, \
        devices.device_description, \
        controls.device_guid, \
        controls.control_name, \
        controls.control_description, \
        controls.control_script \
        FROM devices \
        LEFT JOIN controls ON devices.device_controlid = controls.control_id \
        WHERE devices.device_id = {arg_deviceid};"

    cursor.execute(sql_spec)
    row = cursor.fetchone()
    print(row)
    return(row)


# ---- This queries the freshness of the sequence table.
def checkSequenceTableFreshness(conn):
    # This function retrieves all 'switch on' records from the sequence table and counts how many are for the 
    # current month.  If none exist, then we assume the sequence table is for last month and 
    # get it rebuilt.
    # Only the 'switch on' events a re considered as the 'switch off' could have spilled over to the following month.

    logger.debug("Checking freshness of the sequence table.")
    cursor = conn.cursor()

    sql_freshness = "SELECT\
    sequence.sequence_id              AS sequence_id,\
    sequence.schedule_id              AS schedule_id,\
    sequence.cycle_id                 AS cycle_id,\
    sequence.device_id                AS device_id,\
    sequence.event_datetime           AS event_datetime,\
    sequence.event_function           AS event_function,\
    sequence.event_completed_date     AS event_completeddate\
    FROM sequence\
    WHERE sequence.event_function = 1;"
    
    cursor.execute(sql_freshness)

    # Fetch all rows
    rows = cursor.fetchall()
    sql_rowcount = cursor.rowcount
    logger.debug(f"  Query returned [{sql_rowcount}] 'switch on' sequence events.")
    if (sql_rowcount == 0):
        logger.debug("As zero records were returned, the sequence table must be broken and a rebuild is needed.")
        return False

    # Now get the value of the current month and compare the returned records with it.
    current_month = datetime.now().astimezone(AEST).month

    count_matchingmonths = 0        # Increment this each time the event month  equals current month
    for rowdata in rows:
        # Iterate through each sequence record to check the event date
        event_month = rowdata['event_datetime'].month
        if (event_month == current_month):
            count_matchingmonths += 1

    logger.debug(f"  Found [{count_matchingmonths}] events matching month [{current_month}].")
    if (count_matchingmonths > 0):
        logger.debug("  This confirms the sequence is still current.")
        return True
    else:
        logger.debug("The sequence appears to be out of date and needs a rebuild.")
        return False





# ==== MAIN CODE ======================================================================================================
print("\n\n\n\n\n================================================================================================")
print("Startup ...")


# ----- Confirm the necessary CLI parameters
if len(sys.argv) < 3:
    print("ERROR.  Found " + str(len(sys.argv) - 1) +
          " CLI parameters.  \n\tSpecify the following two command line parameters in order.  " +
          "\n\t  1) The fully qualified name of the local YAML config file, and " +
          "\n\t  2) The fully qualified name of the local (OS dependant) message log file. ")
    exit(2)
else:
    yaml_configuration_file = sys.argv[1]
    print("  YAML configuration will be retrieved from \t\t[" + yaml_configuration_file + "]")
    log_location = sys.argv[2]
    print("  Python logging system messages will be stored at \t[" + log_location + "]")



# ---- Use the python logging system to write log messages (advanced method).
try:
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    handler3 = logging.handlers.TimedRotatingFileHandler(log_location, when='midnight', backupCount=30)
    handler3.setLevel(logging.DEBUG)
    formatter = logging.Formatter('%(asctime)s %(name)s %(levelname)s \t%(message)s')
    handler3.setFormatter(formatter)
    logger.addHandler(handler3)

except:
    logger.error("\nERROR 10.  Something broke in the logging setup.\nQuitting now.\n\n\n")
    exit(2)


# os.environ['TZ'] = 'Australia/Brisbane' # set new timezone
# time.tzset()



logger.debug("---------------------------------------------------------------------------- ")  # Readability only
logger.debug("Script name is .... [" + str(sys.argv[0]) + "]")
logger.debug("Config file YAML .. [" + yaml_configuration_file + "]")
logger.debug("OS detected as .... [" + platform.system() + "]")

AEST = pytz.timezone("Australia/Brisbane")
print("Local time   {}".format(datetime.now().astimezone(AEST)))
logger.debug("Local time ........ [{}]".format(datetime.now().astimezone(AEST)))
logger.debug(f"Timezone  ......... [{AEST.zone}]")
logger.debug("---------------------------------------------------------------------------- ")  # Readability only




# ---------- Get the YAML configuration
yaml_config_data = yaml_loader(yaml_configuration_file)       # Load the YAML configuration data based on command line arg.

# ---------- Set operating parameters from the retrieved YAML configuration data
logger.debug("Getting configuration parameters from YAML configuration file.")
try:
    # Get the parameters from YAML
    sql_host           = yaml_config_data['sql_connection']['sql_host']
    sql_username       = yaml_config_data['sql_connection']['sql_username']
    sql_password       = yaml_config_data['sql_connection']['sql_password']
    sql_database       = yaml_config_data['sql_connection']['sql_database']

    event_timetokeep   = yaml_config_data['tuning']['cycle_retention']
    regenerate_flag    = yaml_config_data['tuning']['regenerate_sequence_on_month_change']

    mife_host          = yaml_config_data['mife_connection']['mife_host']
    mife_port          = yaml_config_data['mife_connection']['mife_port']
    mife_path          = yaml_config_data['mife_connection']['mife_path']
    mife_client_name   = yaml_config_data['mife_connection']['mife_client_name']

    alert_subject      = yaml_config_data['mife_boilerplate']['message_subject']

except:
    logger.error("ERROR 20.  Unable to parse YAML configuration data.  Check the config file for errors.")
    exit(2)


my_alert_counter = 0        # Increment this only if an alert needs to be sent

logger.debug("  ----- General parameters used for these queries ---------") 
logger.debug(f'  SQL Server used  ....................... [{sql_host}].')
logger.debug(f'  SQL Database used  ..................... [{sql_database}].')
logger.debug(f'  Retention period for completed Cycles  . [{event_timetokeep}].')
logger.debug(f'  Rebuild sequence on month change ....... [{regenerate_flag}].')
logger.debug("  ---------------------------------------------------------")



# Connect to the SQL database
conn =pymysql.connect(
  host=sql_host,
  user=sql_username,
  password=sql_password,
  db=sql_database,
  charset='utf8mb4',
  cursorclass=pymysql.cursors.DictCursor
)


# Step 1 - Set the timezone.
try:
    with conn.cursor() as cursor:   
        # The following sets the timezone for SQL for this session only
        logger.debug("Setting MySQL session_time_zone.")
        sql_timezone = 'SET @@session.time_zone = "+10:00";'
        cursor.execute(sql_timezone)

finally:
    cursor.close()
    


# Step 2 - Check if the current sequence table is still valid
if (regenerate_flag == True):
    logger.debug('The Sequence table will be checked to determine if a rebuild is needed.')
    # do stuff
    if (checkSequenceTableFreshness(conn) == False):
        logger.debug("About to rebuild sequence table.")
        
        # Prepare the script itself
        script_name = "planner.sh"

        script_path = "/var/www/html/temere/scripts/"
        my_script = f"{script_path}{script_name}"
        logger.debug(f"Script ==> [{my_script}]")
            
        result = subprocess.run([my_script], shell=True, capture_output=True, text=True)
        logger.debug(result)
        logger.debug("Sequence rebuild complete.")



else:
    logger.debug('The Sequence table will not be checked to determine if a rebuild is needed.')



# Step 3 - Purge all the old records from the sequence table.
try:
    with conn.cursor() as cursor:   
        # Now purge to old records.  Comment this out to preserve data during testing
        logger.debug("About to purge old Cycle records from the Sequence table.")
        newPurge(cursor, event_timetokeep)              

finally:
    cursor.close()


# Step 4 - Find the due events.
try:
    with conn.cursor() as cursor:   
        # Now process all due events
        logger.debug("Select and process all the 'due' events.")
        processDueEvents(cursor)      

finally:
    cursor.close()



logger.debug("--- Conductor has completed this run ---")
print("end")
