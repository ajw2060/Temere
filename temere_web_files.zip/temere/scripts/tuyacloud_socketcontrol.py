# This is the TinyTuya test code 


'''
    This script is intended to be a generic Tuya control script.
    The credentials are hard coded.
    The ID of the controlled device and the desired action are
    passed as CLI arguments.

    IMPORTANT NOTES
    ===============
    1)  Do not change the number of print() statements in this code as the output is parsed by PHP and the 
        useful result stuff is expected to be at position [4].



'''


import tinytuya
import argparse
import sys

print("Starting ...")

parser = argparse.ArgumentParser(description="Tuya Device Switcher", formatter_class=argparse.ArgumentDefaultsHelpFormatter)
parser.add_argument("device_id", help="Device ID of the Tuya device")
parser.add_argument("state", help="State can be 'on' or 'off'")
args = parser.parse_args()
config = vars(args)         # The args provided on the CLI are stashed in the config dict.


# Extract the arguments from the config dict
device_id = config['device_id']
device_function = config['state']

# Validate the presented state
if device_function == "on":
    command_value = True
elif device_function =="off":
    command_value = False
else:
    sys.exit("ERROR.  The supplied 'state' parameter must be 'on' or off' only.")


# Connect to Tuya Cloud
# c = tinytuya.Cloud()  # uses tinytuya.json 



c = tinytuya.Cloud(
        apiRegion="eu", 
        apiKey="xxx", 
        apiSecret="xxx",)       # Without the Device ID



# Send Command - Turn on switch
print("Setting up command structure")
commands = {
    "commands": [
        {"code": "switch_1", "value": command_value},           # Make this "switch_led" for a light
        {"code": "countdown_1", "value": 0},
    ]
}
print(f"Now sending command [{command_value}] to Device ID [{device_id}].")
result = c.sendcommand(device_id,commands)
print(result)


