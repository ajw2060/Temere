

# This script will do the following
# - publish a single message on the given topic.
# This script is intended to run as part of the Temere Scheduler to send a MQTT message destined for (typically) a Home Assistant instance.
# It does not subscribe to anything, but simply does a fire and forget publish using 'publish single'.


# Changes
# 2023-09-10    Initial build.


import time

import os
import logging
import platform
import sys

import yaml
import json
import paho.mqtt.client as mqtt
import paho.mqtt.publish as publish
import pprint

import argparse

#import datetime
#import threading



# ---------- Configuration load from YAML -----------------------------------------------------------------------------
def yaml_loader(filepath):
    try:
        with open(filepath, "r") as file_descriptor:
            config_data = yaml.load(file_descriptor, Loader=yaml.FullLoader)    # Should avoid the unsafe warning
        return config_data
    except:
        print(f"ERROR 5.  Unable to open the YAML configuration file at [{filepath}].")
        exit(5)


# --01-------- The connection acknowledgement callback ----------------------------------------------------------------
def on_connect(client, userdata, flags, rc):
    logger.debug("..ON-CONNECT callback processing.")
    if rc == 0:
        logger.debug("..Connected to broker = [" + str(rc) + "] and UserData = [" + str(userdata) + "]")
       
    else:
        logger.debug("ERROR.  Client ON-CONNECT has failed.")


# --02-------- The disconnect callback --------------------------------------------------------------------------------
def on_disconnect(client, userdata, rc):
    logger.debug("Disconnected from broker")
    if rc != 0:
        logger.debug(
            "ERROR.  Unexpected disconnection from broker.  RC [" + str(rc) + "].  Userdata [" + str(userdata) + "]")


# --03-------- The callback when the broker has acknowledged the subscription -----------------------------------------
def on_subscribe(mqttc, obj, mid, granted_qos):
    logger.debug("...Subscription confirmed.  Mid= " + str(mid) + "  Granted QoS= " + str(granted_qos))



# --04-------- The callback when a message has been published PRIVATE BROKER -------------------------------------
def on_publish(client, userdata, mid):
    logger.debug("Callback ==> ON-PUBLISH.  Broker publish completed.   MID[" + str(mid) +"]")




# ==== MAIN CODE =======================================================================================================
print("\n\n\n\n\n===============================================================")
print("Startup ...")

parser = argparse.ArgumentParser(description="Tuya Device Switcher", formatter_class=argparse.ArgumentDefaultsHelpFormatter)
parser.add_argument("yaml_configuration_file", help="Name of the YAML configuration file")
parser.add_argument("log_location", help="Path to logging directory")
parser.add_argument("mqtt_topic", help="The MQTT topic used to publish the message")
parser.add_argument("mqtt_payload", help="The MQTT payload to oublish")
args = parser.parse_args()
config = vars(args)         # The args provided on the CLI are stashed in the config dict.


# Extract the arguments from the config dict
yaml_configuration_file = config['yaml_configuration_file']
log_location = config['log_location']
mqtt_topic = config['mqtt_topic']
mqtt_payload = config['mqtt_payload']

print("  YAML configuration will be retrieved from \t\t[" + yaml_configuration_file + "]")
print("  Python logging system messages will be stored at \t[" + log_location + "]")



# ---- Use the python logging system to write log messages (advanced method).
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)

# Create the various handlers
ch = logging.StreamHandler()
handler2 = logging.NullHandler
handler3 = logging.FileHandler(log_location)

# Create a generic formatter
formatter = logging.Formatter('%(asctime)s %(name)s %(levelname)s \t%(message)s')

# Set the logging level for handlers
ch.setLevel(logging.DEBUG)
handler3.setLevel(logging.DEBUG)

# Set the formatters for each handler
ch.setFormatter(formatter)
handler3.setFormatter(formatter)

# Finally apply the desired handler to the logger.
logger.addHandler(handler3)






# ---------- These values come from the command line
filepath = yaml_configuration_file          # Where to find the YAML configuration file
data = yaml_loader(filepath)                # Where to write script errors before logging starts





logger.debug("---------------------------------------------------------------------------- ")  # Readability only
logger.debug("---------- Script Startup ---------- " + "[" + os.path.basename(__file__) + "] -----")
logger.debug("Config was retrieved from YAML [" + filepath + "]")

logger.debug("Script name is  [" + str(sys.argv[0]) + "]")
logger.debug("OS detected as  [" + platform.system() + "]")






# ---------- Set operating parameters from the retrieved YAML configuration data
logger.debug("Loading system variables from YAML")
try:
    mqtt_broker_name =    data['broker_configuration']['broker_name']
    mqtt_broker_port =    data['broker_configuration']['broker_port']
    mqtt_broker_timeout = data['broker_configuration']['broker_timeout']
    mqtt_station_name =   data['station_configuration']['mqtt_station_name']
    mqtt_user_name =      data['station_configuration']['mqtt_user_name']
    mqtt_user_password =  data['station_configuration']['mqtt_user_password']

except:
    logger.debug("ERROR 20.  Unable to parse YAML configuration data.  Check the config file for errors.")
    exit(2)


# Normalise the payload from on/off to 0/1 as needed by MQTT
if (mqtt_payload == 'on'):
    mqtt_payload = '1'

if (mqtt_payload == 'off'):    
    mqtt_payload = '0'

logger.debug(f"MQTT Topic ... [{mqtt_topic}]")
logger.debug(f"MQTT Payload . [{mqtt_payload}]")

publish.single(mqtt_topic, payload=mqtt_payload, qos=0, retain=False, hostname=mqtt_broker_name,
        port=mqtt_broker_port, client_id="", keepalive=mqtt_broker_timeout, will=None, 
        auth={"username":mqtt_user_name, "password":mqtt_user_password}, tls=None,
        protocol=mqtt.MQTTv311, transport="tcp")



logger.debug("=== end===")

