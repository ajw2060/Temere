#!/bin/bash

echo "Starting the 'Temere Conductor' script"
source /home/awoods/temere/bin/activate

python3.8 /var/www/html/temere/scripts/conductor.py /var/www/html/temere/scripts/conductor.yaml /home/awoods/Logs/Temere/conductor.log

# Logs still get written to home directory as user does not have write permission of /var/log



