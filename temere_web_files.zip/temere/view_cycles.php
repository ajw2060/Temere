






<?php
  /*
    This page provides a more complex dump of the sequence table.    
    It shows events paired in their respective Cycles
      
    Change History
    2023-08-19  Initial build
    
  
  
  */
?>




<?php
  error_reporting(E_ALL); 
  ini_set('display_errors', '0');
  include_once 'includes/header.inc.php';
  require_once 'includes/functions.inc.php';
  require_once 'includes/dbh.inc.php';
  werl($_SERVER['PHP_SELF'] . "\tPage load");     // Log message
  
?>



<?php
//var_dump($_SESSION);
  // This bit is magic - it ensures users cannot get to the page without being logged in.
  if (isset($_SESSION["useruid"])){
    //echo "here";
    echo "<p style='color:purple; text-align:left'>You are logged in as " . $_SESSION["userfullname"] .  "</p>";
  }
  else {
    //echo "xxx";
    header("location: login.php");
    exit();
  }
  //var_dump($_SESSION);
  ?>

<style>
  tr:nth-of-type(even) {
  background-color:#ccc;
}

.link_button {
    background-color: #1c87c9;
    border: none;
    color: white;
    padding: 5px 20px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 1.0em;
    margin: 4px 2px;
    cursor: pointer;
    border-radius: 2px;
  }

.link_button1:hover {
      background-color:lightgreen;
      transition: 0.1s;
  }

  button:active {
    transform: scale(0.99);
  }

  th{
    text-align: left;
  }
</style>





  <body>
    <div class="container">
    
      <?php
        // Dump of the Sequence table.
        $sql_cycles = "SELECT 
        A1.sequence_id              AS on_sequenceid, 
        A1.schedule_id              AS schedule_id,
        A1.cycle_id                 AS on_cycleid, 
        A1.event_function           AS on_function, 
        A1.event_datetime           AS on_datetime, 
        A1.event_completed_date     AS on_completeddatetime, 
        A1.batch_id                 AS batch_id,
        A2.sequence_id              AS off_sequenceid, 
        A2.cycle_id                 AS off_cycleid, 
        A2.event_function           AS off_function, 
        A2.event_datetime           AS off_datetime, 
        A2.event_completed_date     AS off_completeddatetime, 
        A1.device_id, 
        A2.device_id, 
        devices.device_name         AS device_name 
      FROM sequence A1 
      INNER JOIN sequence A2 
      ON A1.cycle_id = A2.cycle_id 
      INNER JOIN devices 
      ON A1.device_id = devices.device_id 
      WHERE A1.event_function = 1 
      AND A2.event_function = 0 
      ORDER BY device_name ASC, 
      on_datetime ASC;" ;
      


        $result = mysqli_query($conn, $sql_cycles) or die(mysqli_error($conn));
        $num_rows = mysqli_num_rows($result);
        $my_table_number = 0;     // Increment before use
        //echo "<p>There were {$num_rows} records returned from the SQL query.</p>";
      ?>
      <br>
      <h1>Device Cycles</h1>
      This is a processed view of the Sequence Table showing Cycles for each device.
      <br><br>
      
      <table class="box-1" width="100%" >
      <caption>Table <?php echo $my_table_number +=1;?> - Device Cycles</caption>
        <tr >
          <th> Device Name                  </th>  
          <th> Schedule                 </th>  
          <th> Cycle                     </th>  
          <th> Sequence On   </th>  
          <th> Actual On      </th>  
          <th> Sequence Off  </th>  
          <th> Actual Off     </th>  
          <th> Batch          </th>  
          
        </tr>
        
        <?php
        while($row = mysqli_fetch_assoc($result)){
          // Preprocess some of the variables to improve formatting




          // Prepare the ON event DateTime field.  This field is mandatory in the database so should never be null.
          if (!is_null($row['on_datetime'])){
            $my_ondatetime = date_format(date_create($row['on_datetime']), 'D d M H:i');
          }
          else{
            $my_ondatetime = "";
          }

          // Prepare the OFF event DateTime field.  This field is also mandatory in the database so should never be null.
          if (!is_null($row['off_datetime'])){
            $my_offdatetime = date_format(date_create($row['off_datetime']), 'D d M H:i');
          }
          else{
            $my_offdatetime = "";
          }

          // Prepare the ON event completed DateTime field.  This field is optional and will be NULL if the event is not yet completed.
          if (!is_null($row['on_completeddatetime'])){
            $my_oncompleteddatetime = date_format(date_create($row['on_completeddatetime']), 'd M H:i');
          }
          else{
            $my_oncompleteddatetime = "";
          }
         
          // Prepare the OFF event completed DateTime field.  This field is also optional and will be NULL if the event is not yet completed.
          if (!is_null($row['off_completeddatetime'])){
            $my_offcompleteddatetime = date_format(date_create($row['off_completeddatetime']), 'd M H:i');
          }
          else{
            $my_offcompleteddatetime = "";
          }
 
        ?>
 
          <tr> 
            <td><?php echo $row['device_name'] ?>          </td>
            <td><?php echo $row['schedule_id'] ?>          </td>
            <td><?php echo $row['on_cycleid'] ?>           </td>
            <td><?php echo $my_ondatetime ?>               </td>
            <td><?php echo $my_oncompleteddatetime ?>      </td>
            <td><?php echo $my_offdatetime ?>              </td>
            <td><?php echo $my_offcompleteddatetime ?>     </td>
            <td><?php echo $row['batch_id'] ?>          </td>
          </tr>
        <?php
          }
        ?>
      </table>
      <?php echo "There are {$num_rows} Cycles shown here."  ?>
      <hr>


  <form>
    <button class="link_button"   type="submit" formaction= "index.php" > 
      Home
    </button>

  </form>
  </div>  
</body>
  <?php include_once 'includes/footer.inc.php'; ?>
</html>



