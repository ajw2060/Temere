
<?php

  // This is the page to update an exiting control.  It does the following
  // - allows edit of the selected device

  //  Change History
  //  2023-08-31  Initial build
  
?>

<?php
  include 'includes/header.inc.php';
  require_once 'includes/dbh.inc.php';
  require_once 'includes/functions.inc.php';
  werl($_SERVER['PHP_SELF'] . "\t------ Page load ------");
?>



<link rel="stylesheet" href="css/index_css.css">

<?php
  if (isset($_SESSION["useruid"])){
    echo "Welcome " . $_SESSION["userfullname"] ;
  }
  else {
    header("location: login.php");
  }
?>

<?php
  // Get the name of the referring page in case we want to return there
  $my_referrer = basename($_SERVER['HTTP_REFERER']);
?>


<body >
  <div >
    <h1><?php echo $jobs_systemname; ?> - Update Control Details</h1>
    This page allows the selected control to be edited.
    <br><br>



<?php
  error_reporting(E_ALL); 
  ini_set('display_errors', '1');
  //var_dump ($_POST);

  # If we receive the control_id from POST, the grab all the details of that control
  if (isset($_POST['control_id'])){
    $sql_control = "SELECT 
        controls.control_id
      , controls.control_name
      , controls.control_description
      , controls.device_id
      , controls.device_guid
      , controls.control_active
      , controls.control_script
      , devices.device_name
    FROM controls
    LEFT JOIN devices ON controls.device_id = devices.device_id
    WHERE control_id = {$_POST['control_id']}
    ;";

  
    $result = mysqli_query($conn, $sql_control) or die(mysqli_error($conn));
    //var_dump($result);
    
    if (mysqli_num_rows($result) > 0) {
      // Output the single result
      $row_control = mysqli_fetch_assoc($result);


  
  // Get the list of Devices so we can select the one that this Control actually supports.
  // This is used to use as options in the dropdown below.
  $sql_devicelist = "SELECT
      device_id
    , device_name
    , device_description
    , device_vendor
    FROM devices
    ;";
    
    $result_devicelist = mysqli_query($conn, $sql_devicelist) or die(mysqli_error($conn));
    $num_rows = mysqli_num_rows($result_devicelist);
    werl($_SERVER['PHP_SELF'] . "\tFound [{$num_rows}] defined Devices.");


  ?> 
 

  <?php
    // Modify the required fields before display
    if ($row_control['control_active'] == 1 ){
      $my_checkbox_enable_state = "checked";
    } else {
      $my_checkbox_enable_state = "unchecked";
    }
  ?>

  
  <form method="POST" >
    <label class="label_1" >
      Control ID 
      <input  class="input_1_readonly" type="text" readonly size="4" name="control_id"
      value="<?php echo $row_control['control_id']; ?>"> 
    </label>

    <label class="label_1">
      Control Name 
      <input class="input_1" type="text" size="20" name="control_name"
      value="<?php echo $row_control['control_name']; ?>">
    </label>

    <label class="label_1">
      Control Description       
      <input class="input_1" type="text" name="control_description" size="50"
      value="<?php echo $row_control['control_description']; ?>">
    </label>

    <label class="label_1">
      Device Unique ID (or GUID)      
      <input style="font-family:courier" class="input_1" type="text" name="device_guid" size="30"
      value="<?php echo $row_control['device_guid']; ?>">
    </label>

    <p>

    <label for="controls" class="label_1"> Select Device which this Control will support</label>
    <select id="controls" name="device_id">
      <?php 
        # Iterate through the result set (of devices) and set the option values and option text
        $my_default="";
        werl($_SERVER['PHP_SELF'] . "\tCurrently selected Device is [{$row_control['device_id']}] [{$row_control['device_name']}]");
        while($row_devicelist = mysqli_fetch_assoc($result_devicelist)){
          # While iterating here, check each option to see if it is the currently selected Control Method, and if so flag it as the default.
          werl($_SERVER['PHP_SELF'] . "\tFound Device with ID [{$row_devicelist['device_id']}]");
          if ($row_devicelist['device_id'] == $row_control['device_id']){
            $my_default = 'selected';
            werl($_SERVER['PHP_SELF'] . "\tBazinga.  Found the selected device.");
          } else {
            $my_default = "";
          }
          # Assign a more friendly variable to the 'value' so it is easier to use later when updating the SQL
          $my_selecteddevice = $row_devicelist['device_id'];
          echo "<option {$my_default} value={$my_selecteddevice}> Device ID {$row_devicelist['device_id']}. {$row_devicelist['device_name']} ({$row_devicelist['device_description']}) </option>";
        }
      ?>  
    </select>
    </P>
    <br>
    <label class="label_1">
      Name of Control Script      
      <input class="input_1" type="text" name="control_script" size="30"
      value="<?php echo $row_control['control_script']; ?>">
    </label>



    <span > 
    <label class="label_1">
      <input type='hidden' name='control_enable' value='0' />
      <input style="display:inline; margin-top:5px"  type="checkbox" name="control_enable"  value="1"
        <?php echo $my_checkbox_enable_state ?>>
      Enable this Control
    </label>
    </span> 
    <br>

    <button class="link_button" type="submit" formaction=<?php echo $my_referrer; ?>> 
      Cancel
    </button>

    <button class="link_button" type="submit" formaction="index.php"> 
      Home
    </button>

    <button class="link_button" type="submit" <?php if ($_SESSION["userrights"] != 1){ echo "disabled" ;}?> formaction="includes/update_existing_control.inc.php"> 
      Update Control
    </button>

    <button class="link_button" type="submit" <?php if ($_SESSION["userrights"] != 1){ echo "disabled" ;}?> formaction="includes/delete_existing_control.inc.php"> 
      Delete This Control
    </button>

    

  


<?php
      } else {
        echo "No results returned from database query.";
      }

} else{
    echo "Something broke passing the device_id to this page.";
}


?>
</div>
<?php include_once 'includes/footer.inc.php'; ?>

</body>



</html>