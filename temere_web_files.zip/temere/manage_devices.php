

<?php
  // This is the page to manage all devices.
  // It does the following
  // - allows addition or deletion of devices
  
  // Change History
  //  2023-08-26 Initial build
  
  
  
?>


<?php
  error_reporting(E_ALL); 
  ini_set('display_errors', '1');
  include_once 'includes/header.inc.php';
  require_once 'includes/dbh.inc.php';
  require_once 'includes/functions.inc.php';
  werl($_SERVER['PHP_SELF'] . "\t------ Page load ------");
?>





<link rel="stylesheet" href="css/index_css.css">

<?php
//var_dump($_SESSION);
  // This bit is magic - it ensures users cannot get to the page without being logged in.
  if (isset($_SESSION["useruid"])){
    //echo "here";
    echo "<p style='color:purple; text-align:left'> Welcome {$_SESSION['userfullname']} </p>";
  }
  else {
    //echo "xxx";
    header("location: login.php");
    exit();
  }
  //var_dump($_SESSION);
  ?>

<?php     // Handle all the conditions returned via the URL from some referring page
  if(isset($_GET["code"])){
    switch($_GET["code"]){
      case "0":
        echo"<p class='goodnews'> Success. <br> {$_GET["msg"]} <p>";
        break;

      case "3":
        echo"<p class='goodnews'> Test complete. <br> {$_GET["msg"]} <p>";
        break;
      
      case "10":
        echo"<p class='goodnews'> Success. <br> {$_GET["msg"]} <p>";
        break;
  
      case "11":
        echo"<p class='errorbox'> ERROR {$_GET["code"]}. <br>Device update failed. <br> {$_GET["msg"]} <p>";
        break;

      case "23":
        echo"<p class='errorbox'> ERROR {$_GET["code"]}. <br>Device creation failed. <br> {$_GET["msg"]} <p>";
        break;
    }
  }
?>



  <body>
      <div class="container">
      <h1><?php echo $jobs_systemname; ?> - Manage Devices </h1>
        This page allows Add Change Delete of Devices. 


      <form  method='POST'>
        <button class="link_button" type='submit' formaction='add_new_device.php' <?php if ($_SESSION["userrights"] != 1){ echo "disabled" ;}?> name='add_schedule'> 
          Add New Device
        </button>
        <br><br>
      </form>


      <?php
        $sql = "SELECT devices.device_id   
          , devices.device_name
          , devices.device_description
          , devices.device_vendor
          , devices.device_controlid
          , devices.device_active
          , controls.control_name
          , controls.control_id
        FROM devices 
        LEFT JOIN controls
          ON devices.device_controlid = controls.control_id
        ORDER BY device_id ASC; ";

        $result = mysqli_query($conn, $sql) or die(mysqli_error($conn));
        $num_rows = mysqli_num_rows($result);
        echo "<p>There were {$num_rows} records returned from the SQL query.</p>";

      ?>
  <br>Devices are sorted by ID.

      <br>
      
      <table class="box-1" width="98%" style="text-align:left" >
      <caption>List of all devices</caption>
        <tr >
          <th> Device ID             </th>  
          <th> Device Name           </th>  
          <th> Device Description    </th>  
          <th> Vendor         </th>  
          <th> Control        </th>  
          <th> State          </th>  
          <th> Testing        </th>
        </tr>

        <?php
          while($row = mysqli_fetch_assoc($result)){
            // Build the test for the Active column
            // While we are at it, 
            // Determine the 'disabled' or not state for the test buttons based on the state of the device.
            // If the device itself is disabled (presumably due to a missing control definition)
            // then we should not be able to test the device.
            if ($row['device_active'] == 1) {
              $active_text = "Active";
              $button_disablesetting = "";
            } else {
              $active_text = "Inactive";
              $button_disablesetting = "disabled";
            }
              
            

        ?>
          <tr>
            <td width=auto  class="table-cell-1">
              <form method="POST">  
                <button class="link_button-1" type='submit' name='device_id' formaction="update_existing_device.php" value = <?php echo $row['device_id'];?>>  
                  <?php echo $row['device_id']; ?>
                </button>
              </form>
            </td>
           
            <td class="table-cell-1" > <?php echo $row["device_name"]; ?>         </td>
            <td class="table-cell-1" > <?php echo $row["device_description"]; ?>  </td>
            <td class="table-cell-1" > <?php echo $row["device_vendor"];  ?>      </td>
            <td class="table-cell-1" > 
            <?php 
              // If no control exists for this device, then render an empty TD element, but if a control does exist, then populate it.
              if (empty($row['control_id'])) {
                echo "";
              } else {
              ?>  
                <form method="POST">  
                <button class="link_button-1" type='submit' name='control_id' formaction="update_existing_control.php" value = <?php echo $row['control_id'];?>>  
                  <?php echo $row['control_id']; ?>
                </button>
            </form>
              <?php echo $row["control_name"] ?>   



            <?php
              }




            ?>

            </td>
            <td class="table-cell-1" > <?php echo $active_text;  ?>               </td>

            <td class="table-cell-1" > 
              <form method = "POST">
                <button  class="link_button-1" type='submit' name='device_id' <?php echo $button_disablesetting; ?> formaction="includes/device_function_test.inc.php" value = <?php echo $row['device_id'];?>>  
                <input type="hidden" name="function" value="1">
                  ON   
                </button>
              </form>
              <form method="POST">
                <button  for="bill" class="link_button-1" type='submit' name='device_id' <?php echo $button_disablesetting; ?> formaction="includes/device_function_test.inc.php" value = <?php echo $row['device_id'];?>>  
                <input type="hidden" name="function" value="0">  
                  OFF   
              </button>
              </form>
            </td>

          </tr>
        <?php 
          }
        ?>
      </table>
      <br>



  <form method="POST">
    <button class="link_button"   type="submit" formaction= "index.php" > 
    Home
    </button>

    
  </form>
  </div>  
</body>
  <?php include_once 'includes/footer.inc.php'; ?>
</html>


<style>
  tr:nth-of-type(even) {
  background-color:#ccc;
}


.goodnews{
  color:green;
  font-size: 1.5em;
  }

</style>
