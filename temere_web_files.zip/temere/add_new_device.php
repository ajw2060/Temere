
<?php
  // This is the add new device page for the Temere System.  It does the following
  // - validates user input
  // - runs the SQL add function
  
  //  Change History
  //  2023-08-30  Initial build
  
?>

<?php
  error_reporting(E_ALL); 
  ini_set('display_errors',1);

  if(session_status() !== PHP_SESSION_ACTIVE) session_start();

  include_once 'includes/header.inc.php';
  require_once 'includes/functions.inc.php';
  require_once 'includes/dbh.inc.php';
  
  werl($_SERVER['PHP_SELF'] . "\t----- Page load ------");     // Log message

 
?>

<link rel="stylesheet" href="css/index_css.css">


<?php     // Handle all the conditions returned via the URL from some referring page
  if(isset($_GET["code"])){
    switch($_GET["code"]){
      case "0":
        echo"<p class='goodnews'> New Schedule created successfully. <br> {$_GET["msg"]} <p>";
        break;

      

      case "31":
        echo"<p class='errorbox'> ERROR {$_GET["code"]}. <br>Device not created. <br> {$_GET["msg"]} <p>";
        break;

      case "41":
        echo"<p class='errorbox'> ERROR {$_GET["code"]}. <br>Timing overlap detected with existing Schedule. <br> {$_GET["msg"]} <p>";
        break;
  
      case "42":
        echo"<p class='errorbox'> ERROR {$_GET["code"]}. <br>Schedule will remain Denied until overlap is resolved. <br> {$_GET["msg"]} <p>";
        break;
  

    }
  }
?>





  <h1><?php echo $jobs_systemname; ?> - Add New Device</h1>

  Please complete the following details for the new Device.


<body>
  <div>



 
    
<br>



<style>
form   { display: table;      }
p      { display: table-row;  }
label  { display: table-cell; }
input  { display: table-cell; }
select { display: table-cell; }
checkbox { display: table-cell; }
hidden  { display: table-cell; }
</style>




<form method="POST" >
    
  <p>
    <label for="c"  class="label_1"> Device Name  </label>
    <input id="c"  type="text"  name="device_name" size="15">
  </p>

  <p>
    <label for="d" class="label_1">   Description    </label>   
    <input id="d" xxclass="input_1" type="text" size="25" name="device_description" >
  </p>
  
  <p>
    <label for="v" class="label_1">   Vendor    </label>   
    <input id="v" xxclass="input_1" type="text" size="15" name="device_vendor" >
  </p>
  

  <button class="link_button" type="submit" formaction="manage_devices.php"> 
    Cancel
  </button>

  <button class="link_button" type="submit" <?php if ($_SESSION["userrights"] != 1){ echo "disabled" ;}?> formaction="includes/add_new_device.inc.php"> 
    Submit
  </button>

</form>

<br>

This will set up the base device parameters only.  
<br><br>
Once a Control ID has been created for this device, 
the newly created device must be edited to assign the correct Control ID to the new device and to activate the device before a Schedule can be built for the device.

<br>

</div> 
</body>
<br>
  
<?php 
  include_once 'includes/footer.inc.php'; 
?>
  
</html>
