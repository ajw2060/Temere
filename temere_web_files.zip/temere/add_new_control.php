
<?php
  // This is the add new control page for the Temere System.  It does the following
  // - validates user input
  // - runs the SQL add function
  
  //  Change History
  //  2023-08-31  Initial build
  
?>

<?php
  error_reporting(E_ALL); 
  ini_set('display_errors',1);

  if(session_status() !== PHP_SESSION_ACTIVE) session_start();

  include_once 'includes/header.inc.php';
  require_once 'includes/functions.inc.php';
  require_once 'includes/dbh.inc.php';
  
  werl($_SERVER['PHP_SELF'] . "\t----- Page load ------");     // Log message

 
?>

<link rel="stylesheet" href="css/index_css.css">


<?php     // Handle all the conditions returned via the URL from some referring page
  if(isset($_GET["code"])){
    switch($_GET["code"]){
      case "0":
        echo"<p class='goodnews'> New Schedule created successfully. <br> {$_GET["msg"]} <p>";
        break;

      

      case "31":
        echo"<p class='errorbox'> ERROR {$_GET["code"]}. <br>Control not created. <br> {$_GET["msg"]} <p>";
        break;

  

    }
  }
?>





  <h1><?php echo $jobs_systemname; ?> - Add New Control</h1>

  Please complete the following details for the new Control.


<body>
  <div>



 
    
<br>



<style>
form   { display: table;      }
p      { display: table-row;  }
label  { display: table-cell; }
input  { display: table-cell; }
select { display: table-cell; }
checkbox { display: table-cell; }
hidden  { display: table-cell; }
</style>




<form method="POST" >
    
  <p>
    <label for="c"  class="label_1"> Control Name  </label>
    <input id="c"  type="text"  name="control_name" size="15">
  </p>

  <p>
    <label for="d" class="label_1">   Control Description    </label>   
    <input id="d" xxclass="input_1" type="text" size="25" name="control_description" >
  </p>
  
  

  <button class="link_button" type="submit" formaction="manage_controls.php"> 
    Cancel
  </button>

  <button class="link_button" type="submit" <?php if ($_SESSION["userrights"] != 1){ echo "disabled" ;}?> formaction="includes/add_new_control.inc.php"> 
    Submit
  </button>

</form>

<br>

This will set up only the basic information for the new Control.  
<br><br>
Once a Control has been created, 
the newly created Control must be edited to assign the remaining parmeters and to activate the new Control before it can be assigned to a Device.

<br>

</div> 
</body>
<br>
  
<?php 
  include_once 'includes/footer.inc.php'; 
?>
  
</html>
