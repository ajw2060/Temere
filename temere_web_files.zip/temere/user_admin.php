

<?php
  // This is the user admin page for the Jobs System.  It does the following
  // - allows registered users to be activated.
  
  // Change History
  // 2023-06-19 Initial port from cattle system.
  // 2023-07-02 Restructured to use a edit form and checkboxes for each attribute
  
  
?>


<?php
  error_reporting(E_ALL); 
  ini_set('display_errors', '1');
  include_once 'includes/header.inc.php';

  require_once 'includes/functions.inc.php';
  werl($_SERVER['PHP_SELF'] . "\t------ Page load ------");
?>

<link rel="stylesheet" href="css/index_css.css">

<?php
//var_dump($_SESSION);
  // This bit is magic - it ensures users cannot get to the page without being logged in.
  if (isset($_SESSION["useruid"])){
    //echo "here";
    echo "<p style='color:purple; text-align:left'>Welcome " . $_SESSION["userfullname"] .  "</p>";
  }
  else {
    //echo "xxx";
    header("location: login.php");
    exit();
  }
  //var_dump($_SESSION);
  ?>



  <?php     // Handle all the conditions returned via the URL from some referring page
    if(isset($_GET["code"])){
      switch($_GET["code"]){
        case "41":
          echo"<p class='goodnews'> The user was already inactive so no action was taken. <p>";
          break;
        case "42":
          echo"<p class='goodnews'> The user was already active so no action was taken. <p>";
          break;

        case "43":
          echo"<p class='goodnews'> The user was promoted from inactive to active. <p>";
          break;
        case "44":
          echo"<p class='goodnews'> The user was demoted from active to inactive. <p>";
          break;
      }
    }
  ?>


  <body>
    <div class="container">
    <h1><?php echo $jobs_systemname; ?> - User Admin </h1>
      This page allows a super user to manage user accounts. 
      <?php
        require_once 'includes/dbh.inc.php';
        $sql = "SELECT users_id
          , users_fullname
          , users_uid
          , users_email
          , users_role
          , users_active
          , users_added
          , users_super
        FROM users 
        ORDER BY users_id ASC; ";

        $result = mysqli_query($conn, $sql) or die(mysqli_error($conn));
        $num_rows = mysqli_num_rows($result);
        echo "<p>There were {$num_rows} records returned from the SQL query.</p>";
      ?>

      <hr>
      <br>
      <h3>List of all user accounts</h3>
      <table class="box-1" width="100%" style="text-align:left" >
      <caption>List of all users</caption>
        <tr >
          <th>
            ID
          </th>  
          <th>
            Full Name
          </th>  
          <th>
            UUID
          </th>  
          <th>
            Email
          </th>  
          <th>
            Active
          </th>  
          <th>
            R/W
          </th>  
          <th>
            Super
          </th>  
          <th>
            Registered
          </th>  
        </tr>

        <?php
          while($row = mysqli_fetch_assoc($result)){
        ?>
          <tr>
            <td width=auto  class="table-cell-1">
              <form method="POST">  
                <button class="link_button-1" type='submit' name='users_id' formaction="update_existing_user.php" value = <?php echo $row['users_id'];?>>  
                  <?php echo $row['users_id']; ?>
                  
                </button>
              </form>
            </td>
            <td class="table-cell-1" > <?php echo $row["users_fullname"];   ?></td>
            <td class="table-cell-1" > <?php echo $row["users_uid"];   ?></td>
            <td class="table-cell-1" > <?php echo $row["users_email"];   ?></td>
            <td class="table-cell-1" > <?php echo $row["users_active"];   ?></td>
            <td class="table-cell-1" > <?php echo $row["users_role"];   ?></td>
            <td class="table-cell-1" > <?php echo $row["users_super"];   ?></td>
            <td class="table-cell-1" > <?php echo $row["users_added"];   ?></td>
          </tr>
        <?php 
          }
        ?>
      </table>
      <br>



  <form method="POST">
    <button class="link_button"   type="submit" formaction= "index.php" > 
    Home
    </button>

    
  </form>
  </div>  
</body>
  <?php include_once 'includes/footer.inc.php'; ?>
</html>


<style>
  tr:nth-of-type(even) {
  background-color:#ccc;
}


.goodnews{
  color:green;
  font-size: 1.5em;
  }


.link_button {
    background-color: #1c87c9;
    border: none;
    color: white;
    padding: 5px 20px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 1.0em;
    margin: 4px 2px;
    cursor: pointer;
    border-radius: 2px;
  }



.link_button1:hover {
      background-color:lightgreen;
      transition: 0.1s;
  }

  button:active {
    transform: scale(0.99);
  }

</style>
