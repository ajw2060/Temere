<?php
@session_start();      // Needed so the log functions have access to the userid.  @ = ingore errors)

ini_set('display_errors', '1');



// Formatted dump for variables
function dumper($arg_var){
  echo "<br> <span style=color:magenta> VAR_DUMP follows...";
  echo "<pre>";
  var_dump($arg_var);
  echo "</pre> </span>";
}



// Check 1 - confirm all the boxes are completed
function emptyInputRegister($name, $email, $username, $pwd, $pwd_repeat) {
  //$result;
  if (empty($name) || empty($email) || empty($username) || empty($pwd) || empty($pwd_repeat)){
    $result = true;
  }
  else {
    $result = false;
  }
  return $result;
}

// Check 2 - Username is valid characters
function invalidUid($username) {
  //$result;
  if (!preg_match("/^[a-zA-Z0-9]*$/", $username)){
    $result = true;
  }
  else {
    $result = false;
  }
  return $result;
}

// Check 3 - email correctly formatted
function invalidEmail($email) {
  //$result;
  if (!filter_var($email, FILTER_VALIDATE_EMAIL)){
    $result = true;
  }
  else {
    $result = false;
  }
  return $result;
}

// Check 4 - passwords match
function pwdMatch($pwd, $pwd_repeat) {
  //$result;
  if ($pwd !== $pwd_repeat){
    $result = true;
  }
  else {
    $result = false;
  }
  return $result;
}

// ---- Check 5 - confirm user does not already exist
function uidExists($conn, $username, $email) {
  $sql = "SELECT * FROM users WHERE users_uid = ? OR users_email = ?;";
  $stmt = mysqli_stmt_init($conn);
  if (!mysqli_stmt_prepare($stmt, $sql)){
    werl($_SERVER['PHP_SELF'] . "\tERROR.  Stmt failed during [uuidExists] function.");
    header("location: ../register.php?error=stmtfailed");
    exit();  
  }
  mysqli_stmt_bind_param($stmt, "ss", $username, $email);
  mysqli_stmt_execute($stmt);

  $resultData = mysqli_stmt_get_result($stmt);
  if ($row = mysqli_fetch_assoc($resultData)){
    return $row;
  }
  else {
    $result = false;
    return $result;
  }
  mysqli_stmt_close($stmt);
}

// And create the user
function createUser($conn, $name, $email, $username, $pwd) {
  werl($_SERVER['PHP_SELF'] . "\tFUNCTION.  createuser for [{$name}].");     // Log message
  $user_added_date = date('Y-m-d H:i:s');         // Adds a timestamp into the database showing user registration date
  $sql = "INSERT INTO users (users_fullname
    , users_uid
    , users_email
    , users_password 
    , users_added) VALUES (?, ?, ?, ?, ?);";
  $stmt = mysqli_stmt_init($conn);
  if (!mysqli_stmt_prepare($stmt, $sql)){
    werl($_SERVER['PHP_SELF'] . "\tFUNCTION.  stmt failed during [createUser] function.");     // Log message
    header("location: ../register.php?error=stmtfailed");
    exit();  
  }
  $hashedPwd = password_hash($pwd, PASSWORD_DEFAULT);

  mysqli_stmt_bind_param($stmt, "sssss", $name, $username, $email, $hashedPwd, $user_added_date);
  mysqli_stmt_execute($stmt);
  mysqli_stmt_close($stmt);
  header("location: ../register.php?error=none");
  exit();  
}


// ---- Check for empty input during login
function emptyInputLogin($username, $pwd){
  if (empty($username) || empty($pwd)){
    $result = true;
  }
  else {
    $result = false;
  }
  return $result;
}




// ---- Actually login the user (assuming username and password are OK and the account is active)
function loginUser($conn, $username, $pwd) {
  $uidExists = uidExists($conn, $username, $username);
  if ($uidExists === false) {
    header("location:  ../login.php?error=badusername");
    werl("Login failed for user [" . $username ."]");
    exit();  // Username does not exist in the database
  }
  $pwdHashed = $uidExists["users_password"];
  $checkPwd = password_verify($pwd, $pwdHashed);
  if ($checkPwd === false) {
    header("location: ../login.php?error=badpassword");
    exit();
  }
  else if ($checkPwd === true) {
    // Password is correct so check the account activation status //
    $accountActive = $uidExists["users_active"];
    echo $accountActive;

    if ($accountActive != 1){
      header("location: ../login.php?error=inactive");
      exit();
    }
    else{
      // All checks have passed so create the super global for session
      session_start();
      $_SESSION["userid"] = $uidExists["users_id"];
      $_SESSION["useruid"] = $uidExists["users_uid"];
      $_SESSION["userfullname"] = $uidExists["users_fullname"];
      $_SESSION["userrights"] = $uidExists["users_role"];
      $_SESSION["usersuper"] = $uidExists["users_super"];
      $_SESSION["userpreferredname"] = $uidExists["users_preferredname"]; 
      //var_dump($_SESSION);
      
      $my_message_a = "A new login has been processed for the following user\n";
      $my_message_b = "User full name [{$_SESSION['userfullname']}]\n";
      $my_message_c = "User ID [{$_SESSION['useruid']}]\n" ;
      
      $msg_txt = $my_message_a . $my_message_b .  $my_message_c ;
      $msg_tel = $my_message_a  . $my_message_b  . $my_message_c;
      $msg_html = $my_message_a .  $my_message_b . $my_message_c ;

      callMife("User Login Alert", $msg_txt, $msg_tel, $msg_html);
      

      $my_useragent = $_SERVER['HTTP_USER_AGENT'];

      werl("Login succeeded. Details of user agent follow.");
      werl($my_useragent);
      
      header("location: ../index.php");
      exit();
    }
  }
}


// ---- Change a user status between active and inactive
function setUserStatus($conn, $arg_userid, $arg_desiredStatus){
  // This function will change a user status between active and inactive.
  // It does not consider the current user status.  It just makes the SQL update.
  werl($_SERVER['PHP_SELF'] . "\tFUNCTION. setUserStatus [{$arg_userid}] [{$arg_desiredStatus}].");
  // Sanitise the desired status in case a dodgey value is presented.  It should be 0 or 1.
  if ($arg_desiredStatus == "1"){
    $sql_desiredstatus = "True";
  } else {
    $sql_desiredstatus = "False";
  }

    // Set up the SQL for the status update
    $sql_userstatusupdate = "UPDATE users 
      SET users_active = {$sql_desiredstatus} 
      , users_role = 1 
      WHERE users_id = {$arg_userid}
      ;";
    
    echo "<br> SQL ==> " . $sql_userstatusupdate;
    werl($_SERVER['PHP_SELF'] . "\tFUNCTION. User ID [{$arg_userid}] will be set to status [{$sql_desiredstatus}].");
//exit();
    if (mysqli_query($conn, $sql_userstatusupdate)) {
      werl($_SERVER['PHP_SELF'] . "\tFUNCTION. SQL update successful.");
      $result = 0;
    } else {
      werl($_SERVER['PHP_SELF'] . "\tFUNCTION. SQL update failed");
      $result = 1;
    }
    return $result;
}



// ---- MiFe interface
// This function calls the MiFe service to deliver a message.  Messages my be sent (for example)
// when a new user registers, when a user logs on, or when some other activity occurs.  This is not
// intended to replace any journaling; it is just to warn the administrator about important events 
// in real (or close to real) time.

/* 
    The MiFe service expects a JSON payload as per the following.
    The 'delivery_services' is a list of delivery services.  At least one of the supported 
    types should be configured.  Multiple versions of the message bidy are offered as some
    support rich formatting.  The txt version is mandatory.  If telegram or email delivery are 
    requested and the corresponding body type is not provided, the txt version is used.
    
    {
	    "client_name": "TestClient",
	    "delivery_services": [
		    "dummy",
        "email",
        "xcamel",
		    "sms",
		    "telegram",
        "xcarrier_pigeon"
	      ],
        "subject": "Postman test message",
        "body":{
            "message_txt": "This is a text type test message sent via Thursday night Postman.",
            "message_tel": "This is a Telegram test message sent via Thursday night Postman.",
            "message_html": "This is a HTML paragraph sent via Thursday night Postman."
        }
    }
    The MiFe service port is configurable but presently runs on TCP 50112

*/
function callMife($message_subject, $message_txt, $message_tel, $message_html){
  echo "Calling MiFe <br>";

  $url = 'http://kelvh.com.au:50112/mife';
  
  $data = '
  {
    "client_name": "HerdManager",
    "delivery_services": [
      "email",
      "telegram"
      ],
    "subject": "' . $message_subject . '",
    "body": {
      "message_txt": "' . $message_txt . '",
      "message_tel": "' . $message_tel . '",
      "message_html": "' . $message_html . '"
     }
  }
  ';

  
  

  var_dump($data);
  echo "<hr>";
  //exit();


  $additional_headers = array(                                                                          
     'Accept: application/json',
     'Content-Type: application/json'
  );
  
  $ch = curl_init($url);                                                                      
  curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");                                                                     
  curl_setopt($ch, CURLOPT_POSTFIELDS, $data);                                                                  
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);                                                                      
  curl_setopt($ch, CURLOPT_HTTPHEADER, $additional_headers); 
  

  $max_exe_time = 500; // time in milliseconds
  curl_setopt($ch, CURLOPT_TIMEOUT_MS, $max_exe_time);

  $server_output = curl_exec ($ch);
  
  var_dump($server_output);
//exit();
}

// ---- This just writes a log message to the log file
function werl($log_message)
{
  $log_file = '/var/log/aw-apache/temere.log';
  $my_timestamp = date("Y-m-d H:i:s");    
  $my_ipsource = $_SERVER['REMOTE_ADDR'];
  
  if(isset($_SESSION['useruid'])){
    $uuid = $_SESSION['useruid']; 
  } else {
    $uuid = "undefined";
  }

  $log_message = $my_timestamp . "\t" . $my_ipsource . "\t" . $uuid . "\t" . $log_message . "\n";
  error_log($log_message, 3, $log_file);

}


function check_for_overlaps($conn, $arg_scheduleid)
{
  werl($_SERVER['PHP_SELF'] . "\tFUNCTION.  Performing schedule overlap checks for Schedule ID [{$arg_scheduleid}].");
  /*
    This function is intended to check if the presented Schedule has conflicts with any timing overlaps
    with already exiting Schedules.

    The arg_scheduleid is the index to the 'just written' schedule.  Once we look it up we get the device, schedule type and 
    flex values needed to determine the interval start and end.
    The algorithm for detecting overlspping rnages is as follows.
      overlap detected if max(L1, L2) <= min(R1, R2)
    In our case, the rnages are 'newschedule' and each of the 'existingschedule' records.
    The switchon and switchoff values used in these calculations are worst case and are achieved as follows.
    - earliest switchon = switchon.  The switchon_flex remains at zero.
    - latest switchoff = swithconflex(maximum) + duration + durationflex(maximum).
    - determine the earliest switch on and the longest duration (by using worst case values for both flex values)
    - calculations are done in minutes rather than messing with date/time calculations.

  */

  // Step 1 - Look up the given schedule to get the device name, etc.
  $sql_newschedule = "SELECT
      schedule_id
    , device_id
    , schedule_enable
    , schedule_type
    , trigger_weighting
    , turn_on_time
    , turn_on_flex
    , active_duration
    , active_duration_flex
    , comment
    FROM schedule
    WHERE schedule_id = {$arg_scheduleid}
    ;";
      
  $result_newschedule = mysqli_query($conn, $sql_newschedule) or die(mysqli_error($conn));
  $num_rows = mysqli_num_rows($result_newschedule);
  echo "<p>There is {$num_rows} schedule defined.</p>";  
  $row_newschedule = mysqli_fetch_assoc($result_newschedule);

  // Prepare the worst case time values for the new schedule record. Worst case are the earliest switchon and the latest switchoff.
  $pieces = explode(":", $row_newschedule['turn_on_time']);
  $my_switchonnew = $pieces[0] * 60 + $pieces[1];
  $my_switchoffnew = $my_switchonnew + $row_newschedule['turn_on_flex'] + $row_newschedule['active_duration'] + $row_newschedule['active_duration_flex'];
  
  werl($_SERVER['PHP_SELF'] . "\t  This Schedule Range [" . $my_switchonnew . "]-[" . $my_switchoffnew . "]." );
  
  # Now select all the previous active schedules of this type (weekday or weekend) for this device 
  # We can ignore inactive schedules as this same test gets performed when a schedule is activated.
  $sql_existingschedule = "SELECT
      schedule_id
    , device_id
    , schedule_enable
    , schedule_type
    , trigger_weighting
    , turn_on_time
    , turn_on_flex
    , active_duration
    , active_duration_flex
    , comment
    FROM schedule
    WHERE schedule_id <> {$arg_scheduleid}
    AND device_id = {$row_newschedule['device_id']}
    AND schedule_type = {$row_newschedule['schedule_type']}
    AND schedule_enable = 1
    ;";

  $result_existingschedule = mysqli_query($conn, $sql_existingschedule) or die(mysqli_error($conn));
  $result_newschedule->close();     // Finished with that new schedule result.
  
  $num_rows = mysqli_num_rows($result_existingschedule);
  werl($_SERVER['PHP_SELF'] . "\t  Found [" . $num_rows . "] similar schedules to test against." );
  
  $item_count=0;
  $collision_list = array();   // This tracks which existing schedules this new Schedule collides with

  while($row_existingschedule = mysqli_fetch_assoc($result_existingschedule)){
    $item_count +=1;

    // Prepare the worst case time values for the new schedule record.
    $pieces = explode(":", $row_existingschedule['turn_on_time']);
    $my_switchonexisting = $pieces[0] * 60 + $pieces[1];
    $my_switchoffexisting = $my_switchonexisting + $row_existingschedule['turn_on_flex'] + $row_existingschedule['active_duration'] + $row_existingschedule['active_duration_flex'];
    
    werl($_SERVER['PHP_SELF'] . "\t  Item[{$item_count}] Existing Schedule [{$row_existingschedule['schedule_id']}] Range [" . $my_switchonexisting . "]-[" . $my_switchoffexisting . "]." );
    // Now all the values are in hand, do the maths.
    // The algorithm states that an overlap is detected if max(L1, L2) <= min(R1, R2)
    if (max($my_switchonnew, $my_switchonexisting) <= min($my_switchoffnew, $my_switchoffexisting)){
      werl($_SERVER['PHP_SELF'] . "\t  .NOTE  Overlap detected with Schedule ID [{$row_existingschedule['schedule_id']}] " );
      array_push($collision_list, $row_existingschedule['schedule_id']);   // Push the schedule_id on to the list
    } else {
      werl($_SERVER['PHP_SELF'] . "\t  .No overlap detected here." );
    }
  
  }
  return $collision_list;
}


