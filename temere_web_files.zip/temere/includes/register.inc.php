<?php
    require_once 'dbh.inc.php';
    require_once 'functions.inc.php';
    werl($_SERVER['PHP_SELF'] . "\t------ Page load (register.inc.php) ------");

    echo "Dump follows <br><pre>", var_dump($_POST), "</pre>";
    //exit();

  
  if(isset($_POST['submit'])){
    $name = $_POST['name'];
    $email = $_POST['email'];
    $username = $_POST['username'];
    $pwd = $_POST['pwd'];
    $pwd_repeat = $_POST['pwd_repeat'];

    
    // Confirm all inputs are populated
    if (emptyInputRegister($name, $email, $username, $pwd, $pwd_repeat) !== false){
      werl($_SERVER['PHP_SELF'] . "\tOne or more of the fields was blank Name:[{$name}] Email:[{$email}] Username:[{$username}].");
      header("location: ../register.php?error=emptyinput");
      exit();  
    }

    if (invalidUid($username) !== false){
      werl($_SERVER['PHP_SELF'] . "\tInvalid username [{$name}].");
      header("location: ../register.php?error=invaliduid");
      exit();  
    }

    if (invalidEmail($email) !== false){
      werl($_SERVER['PHP_SELF'] . "\tInvalid email [{$email}].");
      header("location: ../register.php?error=invalidemail");
      exit();  
    }

    if (pwdMatch($pwd, $pwd_repeat) !== false){
      werl($_SERVER['PHP_SELF'] . "\tMismatched password and password repeat.");
      header("location: ../register.php?error=passwordmismatch");
      exit();  
    }

    if (uidExists($conn, $username, $email) !== false){
      werl($_SERVER['PHP_SELF'] . "\tUsername [{$name}] or email [{$email}] already exists .");
      header("location: ../register.php?error=usernametaken");
      exit();  
    }
  
    createUser($conn, $name, $email, $username, $pwd);
    werl($_SERVER['PHP_SELF'] . "\tNew registration from [{$name}] at [{$email}].");
  }
  else{
    werl($_SERVER['PHP_SELF'] . "\tError during register of [{$name}] at [{$email}].");
    header("location: ../register.php?code=E1");
    exit();
  }

