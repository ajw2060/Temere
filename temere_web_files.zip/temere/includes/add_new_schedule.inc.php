<?php
  session_start();
  echo "<pre>", var_dump($_POST), "</pre>";
  //exit();

  require_once 'dbh.inc.php';
  require_once 'functions.inc.php';
  werl($_SERVER['PHP_SELF'] . "\t------ Page load ------");

  if(isset($_POST['device_id'])){
    // Got the variable so proceed
    // Assign local variables to simplify handling
    $my_deviceid = $_POST['device_id'];
    $my_scheduletype = $_POST['schedule_type'];
    $my_triggerweighting = $_POST['trigger_weighting'];
    $my_turnontime = $_POST['turn_on_time'];
    $my_turnonflex = $_POST['turn_on_flex'];
    $my_activeduration = $_POST['active_duration'];
    $my_activedurationflex = $_POST['active_duration_flex'];
    $my_comment = $_POST['comment'];
    $my_desiredscheduleenable = $_POST['schedule_enable'];

    // Validity checks on posted data
    werl($_SERVER['PHP_SELF'] . "\tSanity checking presented inputs.");

    werl($_SERVER['PHP_SELF'] . "\t  Selected Device ID [" . $my_deviceid . "].");
    werl($_SERVER['PHP_SELF'] . "\t  Selected Schedule Type [" . $my_scheduletype . "].");

    // The PHP empty() function cannoth be used to validate these inputs as a value of 0 evaluates to True (ie empty)
    // and zero is permitted in some fields (such as flex)
    // The numeric range validation is done on the input screen, but it does not check for the input being left blank
    // which is a bummer, so we use the strlen() to confirmm we have at least one character.
    
    // Trigger weighting cannot be empty    
    if (strlen($my_triggerweighting) == 0){
        werl($_SERVER['PHP_SELF'] . "\tERROR 31.  Trigger Weighting [" . $my_triggerweighting . "] is empty.");
        header("location: ../index.php?code=31&msg=Trigger Weighting is Empty");
        exit();
    } else {
        werl($_SERVER['PHP_SELF'] . "\t  Trigger weighting [" . $my_triggerweighting . "] is acceptable.");
    }

    // Switch On time cannot be empty.  The empty() works here as we cannot enter 00:00
    if(empty($my_turnontime)) {
        werl($_SERVER['PHP_SELF'] . "\tERROR 31.  Switch on time is not defined.");
        header("location: ../index.php?code=31&msg=Switch on time is not defined");
        exit();
    } else {
        werl($_SERVER['PHP_SELF'] . "\t  Switch on time [" . $my_turnontime . "] is acceptable.");
    }

    // Switch On Flex cannot be empty
    //werl($_SERVER['PHP_SELF'] . "\t  Switch on Flex value is [" . $my_turnonflex . "]");
    if(strlen($my_turnonflex) == 0) {
        werl($_SERVER['PHP_SELF'] . "\t  ERROR 31.  Switch on Flex value is not defined.");
        header("location: ../index.php?code=31&msg=Switch on Flex value is not defined");
        exit();
    } else {
        werl($_SERVER['PHP_SELF'] . "\t  Switch on flex value [" . $my_turnonflex . "] is acceptable.");
    }

    // Duration cannot be empty
    if(strlen($my_activeduration) == 0) {
        werl($_SERVER['PHP_SELF'] . "\t  ERROR 31.  Duration is not defined.");
        header("location: ../index.php?code=31&msg=Duration is not defined");
        exit();
    } else {
      werl($_SERVER['PHP_SELF'] . "\t  Duration [" . $my_activeduration . "] is acceptable.");
    }  
    
    // Duration Flex cannot be empty
    if(strlen($my_activedurationflex) == 0) {
        werl($_SERVER['PHP_SELF'] . "\t  ERROR 31.  Duration Flex is not defined.");
        header("location: ../index.php?code=31&msg=Duration Flex is not defined");
        exit();
    } else {
        werl($_SERVER['PHP_SELF'] . "\t  Duration flex [" . $my_activedurationflex . "] is acceptable.");
    }
  
    // Comments are nice to have.
    if(strlen($my_comment) == 0) {
      werl($_SERVER['PHP_SELF'] . "\t  ERROR 31.  Comment is required.");
      header("location: ../index.php?code=31&msg=A comment is encouraged");
      exit();
    } else {
        werl($_SERVER['PHP_SELF'] . "\t  Comment [" . $my_comment . "].");
    }


    // Log the state of the enable flag
    werl($_SERVER['PHP_SELF'] . "\t  Desired Schedule enable flag [" . $my_desiredscheduleenable . "].");
  
    // Get user details from session
    $my_userid = $_SESSION['useruid'];
    $my_currentdate = date('Y-m-d');
    $my_isdirty = 1;
    
    
    // Prepare and bind
    $sql = "INSERT INTO schedule (device_id, schedule_enable, schedule_type, trigger_weighting, turn_on_time, turn_on_flex, active_duration, active_duration_flex, comment, is_dirty) 
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?);";
    
    $my_scheduleenable = 2;     // Override the user request until the conflict check is completed.  Code 2 = Denied.
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssssssss", $my_deviceid, $my_scheduleenable, $my_scheduletype, $my_triggerweighting, $my_turnontime, $my_turnonflex, $my_activeduration,  $my_activedurationflex, $my_comment, $my_isdirty);
    $fred = $stmt->execute();
    $latest_id =  mysqli_insert_id($conn); 

    
    if ($fred ==1){
      werl($_SERVER['PHP_SELF'] . "\tA new schedule record has been created with ID [" . $latest_id ."].");
      //header("location: ../index.php?code=0&msg=Schedule ID [{$latest_id}]");
    }else{
      werl($_SERVER['PHP_SELF'] . "\tFailed to create the new schedule record. Error: [" . mysqli_error($conn) . "]." ); 
      header("location: ../index.php?code=23");
    }


    /*
      After writing this Schedule record, we need to verify that this new schedule does not create a timing overlap with any existing schedule.
      If a schedule conflict is possible, leave the already written 'schedule_enable' set to 2 (Denied).
      This does not say a conflict will occur, just that one is possible if the various flex values make it work out so.
      The user will never be able to activate this schedule while this condition exists as the same check occurs during Schedule edit.

      This check needs to run against any new Schedule before admitting it.  This way the integrity of the overall Schedule is retained and no 
      many-to-many checks ever need to be done.

      If the new Schedule passes and does not create a timig overlap, just honour the users desired activation status.
    */

    // Now do the above stuff to check for schedule overlaps.
    $overlap_result = check_for_overlaps($conn, $latest_id);
    werl($_SERVER['PHP_SELF'] . "\tNumber of collisions detected is [" . sizeof($overlap_result) . "]." ); 

    if (sizeof($overlap_result) == 0){
      werl($_SERVER['PHP_SELF'] . "\tAll good.  No overlaps detected.");
      // Admit his new schedule by setting the schedule_enable flag to the users desired state (which could be disabled anyway).
      $sql_setenable = "UPDATE schedule SET schedule_enable={$my_desiredscheduleenable} WHERE schedule_id = {$latest_id}";
      if(mysqli_query($conn, $sql_setenable)){
          echo "Records were updated successfully.";
          werl($_SERVER['PHP_SELF'] . "\tSchedule status updated to [" . $my_desiredscheduleenable . "] for schedule_id [" . $latest_id . "].");
      } else {
          echo "ERROR:  SQL Update failed " . mysqli_error($conn);
      }
      header("location: ../index.php?code=0&msg=New Schedule ID [{$latest_id}] created successfully");
      exit();
    } else {
      // Deny this schedule by leaving the schedule_enable flag as it was inserted.
      // Prepare the message text showing which Schedules are conflicting
      foreach ($overlap_result as $value) {
        $conflict_list = $conflict_list . strval($value) . ", ";
      }
      $conflict_list = substr($conflict_list, 0, -2);   // Remove the final comma and space
      header("location: ../index.php?code=41&msg=New Schedule ID [{$latest_id}] conflicts with Schedule ID [{$conflict_list}]");
      exit();
    }
        
  }
  else{
    werl($_SERVER['PHP_SELF'] . "\tERROR.  Device_id was not received.");
    header("location: ../index.php");
    exit();
  }
