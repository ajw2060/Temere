<?php
  if(session_status() !== PHP_SESSION_ACTIVE) session_start();
  require_once './system_config_variables.php';

?>

<!DOCTYPE html>
<html lang="en">


<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
     
  <link rel="stylesheet" href="css/navbar.css">
  <script src="script/script.js" defer></script>

  <link rel="stylesheet" type="text/css" href="css/style.css" />
  <title><?php echo $jobs_systemname; ?></title>
</head>


  <nav class="navbar">
    <div class="brand-title"> <?php echo $jobs_systemname; ?> </div>
    <a href="#" class="toggle-button">
      <span class="bar"></span>
      <span class="bar"></span>
      <span class="bar"></span>
    </a>
    <div class="navbar-links">
      <ul>
        <li><a href="index.php">Home</a>  </li>   
        <li><a href="about.php">About</a> </li>
        
        <li><a href="tools.php">Tools</a> </li>

          <?php
            if (isset($_SESSION['userid'])){
              echo "<li> <a href='includes/logout.inc.php'>Logout</a> </li>";
              if ($_SESSION['usersuper'] ==1){
                echo "<li> <a href='user_admin.php'>User Admin</a> </li>";
              }
            
            }
            else{
              echo "<li> <a class='nav-link' href='register.php'>Register</a>  </li> ";
              echo "<li> <a class='nav-link' href='login.php'>Login</a>        </li> ";
            }

          ?>
      </ul>    
    </div>
  </nav>


