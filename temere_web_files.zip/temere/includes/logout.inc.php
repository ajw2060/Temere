<?php
  require_once 'functions.inc.php';
  werl($_SERVER['PHP_SELF'] . "\tPage load");
  
  session_start();
  session_unset();
  session_destroy();

  header("location: ../login.php");
  exit();
  