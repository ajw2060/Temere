
<?php

    // This is the script to inactivate the selected job.
    
    // Change History
    // 2023-06-14 Initial build


?>


<?php
    error_reporting(E_ALL); 
    ini_set('display_errors', '1');

    require_once 'dbh.inc.php';
    require_once 'functions.inc.php';
    werl($_SERVER['PHP_SELF'] . "\tPage load");
?>
      
    <?php
        // This will update the SQL table with the data in the form.
        if (isset($_POST['jobs_id'])){
            echo "<pre>", var_dump($_POST), "</pre>";

            
            $sql_update = "UPDATE jobs 
            SET jobs_active = 0" .  
              " WHERE jobs_id = " . $_POST['jobs_id'] .
              ";";


            werl($_SERVER['PHP_SELF'] . "\tSQL ==>". $sql_update);     // Log message

            if (mysqli_query($conn, $sql_update)) {
                echo "<br><br>Job Inactivated successfully";
                werl($_SERVER['PHP_SELF'] . "\t" . "Job inactivated for jobs_id [" . $_POST['jobs_id'] ."]");
                header("location: ../index.php?code=2");
                exit();
            } else {
                echo "<br><br>Error updating record: " . mysqli_error($conn);
                werl($_SERVER['PHP_SELF'] . "\t" . "Job inactivation failed for jobs_id [" . $_POST['jobs_id'] ."]" );     // Log message
                header("location: ../index.php?code=22");
                exit();
            }
           
            mysqli_close($conn);
        }


    header('Location: ' . '../index.php');
    ?>

    </body>
</html>

