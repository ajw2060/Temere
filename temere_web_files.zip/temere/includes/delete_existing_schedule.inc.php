
<?php

    // This is the script to delete a schedule
    
    //  Change History
    //  2023-08-15  Initial build


?>


<?php
    error_reporting(E_ALL); 
    ini_set('display_errors', '1');

    require_once 'dbh.inc.php';
    require_once 'functions.inc.php';
    werl($_SERVER['PHP_SELF'] . "\t------ Page load ------");

    echo "Dump follows <br><pre>", var_dump($_POST), "</pre>";
    //exit();
    
?>
      
<?php
    // Now do the SQL updates to the Schedule table given the user input.
    // Some daata validation needs to happen first.
    werl($_SERVER['PHP_SELF'] . "\tPreparing to delete Schedule Schedule ID [" . $_POST["schedule_id"] . "].");
    
    
    $sql_delete = "DELETE FROM schedule WHERE schedule_id={$_POST["schedule_id"]};";

    if (mysqli_query($conn, $sql_delete)) {
        werl($_SERVER['PHP_SELF'] . "\t" . "The Schedule delete succeeded.");
    } else {
        werl($_SERVER['PHP_SELF'] . "\t" . "Error during Schedule delete: " . mysqli_error($conn));     // Log message
        //echo "Error deleting record: " . mysqli_error($conn);
    }

    
    mysqli_close($conn);

    header('Location: ' . '../index.php');
    exit();
?>

    </body>
</html>
 */
