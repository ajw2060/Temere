<?php
  // This is the add new device script.  It does the following
  // - accepts user input via POST
  // - runs the SQL add function
  
  //  Change History
  //  2023-08-30  Initial build
  
?>



<?php
  session_start();
  echo "<pre>", var_dump($_POST), "</pre>";
  //exit();

  require_once 'dbh.inc.php';
  require_once 'functions.inc.php';
  werl($_SERVER['PHP_SELF'] . "\t------ Page load ------");

  if(isset($_POST['device_name'])){
    // Got the variable so proceed
    // Assign local variables to simplify handling
    $my_devicename = $_POST['device_name'];
    $my_devicedescription = $_POST['device_description'];
    $my_devicevendor = $_POST['device_vendor'];
    
    // Validity checks on posted data
    werl($_SERVER['PHP_SELF'] . "\tSanity checking presented inputs for new Device.");
    werl($_SERVER['PHP_SELF'] . "\t  Device Name [" . $my_devicename . "].");
    werl($_SERVER['PHP_SELF'] . "\t  Device Description [" . $my_devicedescription . "].");
    werl($_SERVER['PHP_SELF'] . "\t  Device Vendor [" . $my_devicevendor . "].");

    // Device Name cannot be empty
    if(strlen($my_devicename) == 0) {
        $msg="Device Name must be provided";     
        werl($_SERVER['PHP_SELF'] . "\t  ERROR 31.  {$msg}.");
        header("location: ../add_new_device.php?code=31&msg={$msg}");
        exit();
    } else {
      werl($_SERVER['PHP_SELF'] . "\t  Device Name [{$my_devicename}] is acceptable.");
    }  
    
    // Device Description cannot be empty
    if(strlen($my_devicedescription) == 0) {
        $msg="Device Description must be provided";     
        werl($_SERVER['PHP_SELF'] . "\t  ERROR 31.  {$msg}.");
        header("location: ../add_new_device.php?code=31&msg={$msg}");
        exit();
    } else {
        werl($_SERVER['PHP_SELF'] . "\t  Device Description [{$my_devicedescription}] is acceptable.");
    }
  
    // Device Vendor cannot be empty.
    if(strlen($my_devicevendor) == 0) {
      $msg="Device Vendor must be provided";     
      werl($_SERVER['PHP_SELF'] . "\t  ERROR 31.  {$msg}.");
      header("location: ../add_new_device.php?code=31&msg={$msg}");
      exit();
  } else {
      werl($_SERVER['PHP_SELF'] . "\t  Device Vendor [{$my_devicevendor}] is acceptable.");
  }
  
    // Get user details from session
    $my_userid = $_SESSION['useruid'];
    $my_currentdate = date('Y-m-d');
    $my_isdirty = 1;
    
    
    // Prepare and bind
    $sql = "INSERT INTO devices (device_name, device_description, device_vendor, device_active) 
    VALUES (?, ?, ?, ?);";
    
    $my_deviceactive = 0;
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssss", $my_devicename, $my_devicedescription, $my_devicevendor, $my_deviceactive);
    $fred = $stmt->execute();
    $latest_id =  mysqli_insert_id($conn); 

    
    if ($fred ==1){
      werl($_SERVER['PHP_SELF'] . "\tA new device record has been created with ID [" . $latest_id ."].");
      header("location: ../manage_devices.php?code=0&msg=New Device ID [{$latest_id}].");
      exit();
    }else {
      $response_msg = "Error " . mysqli_error($conn);
      werl($_SERVER['PHP_SELF'] . "\tFailed to create the new device record. Error: [{$response_msg}]." ); 
      header("location: ../manage_devices.php?code=23&msg={$response_msg}");
      exit();
    }

        
  }
  else{
    werl($_SERVER['PHP_SELF'] . "\tERROR.  The 'device_name' was not received.");
    header("location: ../index.php");
    exit();
  }
