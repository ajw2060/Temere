
<?php
require_once 'functions.inc.php';


// Database connection procedural version
//echo "Database about to connect <br>" ;
define('DB_HOST', 'xxx');
define('DB_USER', 'xxx');
define('DB_PASS', 'xxx');
define('DB_NAME', 'temere');

// Create connection
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
//werl($_SERVER['PHP_SELF'] . "\tDatabase connection established to [" . DB_NAME ."]." );

// Check connection
if (!$conn) {
  werl($_SERVER['PHP_SELF'] . "\tDatabase connection failed.");  
  die('Connection failed: ' . mysqli_connect_error());
}

//echo 'Connected successfully<br>';

?>