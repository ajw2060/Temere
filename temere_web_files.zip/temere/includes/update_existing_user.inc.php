
<?php

    // This is the script to update the user record.
    
    
    // Change History
    // 2023-07-02 Initial build


?>


<?php
    error_reporting(E_ALL); 
    ini_set('display_errors', '1');


    // Import the PHPMailer class into the global namespace
    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\Exception;

    require_once 'dbh.inc.php';
    require_once 'functions.inc.php';
    require_once("../vendor/autoload.php");
    require_once '../system_config_variables.php';
    werl($_SERVER['PHP_SELF'] . "\t------ Page load ------");

//dumper($_POST);

//exit();
    
?>
      
    <?php
        // Now update the user status based on the values received in the post.
        werl($_SERVER['PHP_SELF'] . "\tUpdate permissions for ID: [{$_POST['users_id']}], UID: [{$_POST['users_uid']}], NAME: [{$_POST['users_fullname']}].");
      
        // Sanitise the received POST inputs
        if ($_POST['users_active'] == 1){
            $my_usersactive = 1;
        } else {
            $my_usersactive = 0;
        }
        
        if ($_POST['users_readwrite'] == 1){
            $my_usersreadwrite = 1;
        } else {
            $my_usersreadwrite = 0;
        }

        if ($_POST['users_super'] == 1){
            $my_userssuper = 1;
        } else {
            $my_userssuper = 0;
        }

        if ($_POST['users_currentstate'] == 1){
            $my_userscurrentstate = 1;
        } else {
            $my_userscurrentstate = 0;
        }



        // Harvest the useful fields from the submitted data
        $my_userid = $_POST['users_id'];
        $my_useruid = $_POST['users_uid'];
        $my_useremail = $_POST['users_email'];
        $my_userfullname = $_POST['users_fullname'];
        //$my_userdesiredstate = $_POST['desired_state'];




        werl($_SERVER['PHP_SELF'] . "\tSetting permissions:  Current: [{$my_userscurrentstate}], Active [{$my_usersactive}], Readwrite [{$my_usersreadwrite}], Superuser [{$my_userssuper}].");


        // Prepare the SQL statement
        $sql_updateuser = "UPDATE users
            SET 
            users_active = {$my_usersactive}
            , users_role = {$my_usersreadwrite}
            , users_super = {$my_userssuper}
        WHERE users_id = {$my_userid}
        ;";
        
        // Execute the action
        if (mysqli_query($conn, $sql_updateuser)) {
            werl($_SERVER['PHP_SELF'] . "\tUser permissions updated successfully.");
        } else {
            werl($_SERVER['PHP_SELF'] . "\tERROR.  User permissions were not updated " . mysqli_error($conn). ".");
        }
        mysqli_close($conn);

        // Under selected circumstances, send a notification email to the user advising their account has been activated
        // Only send wern account moves from inactive to active
        // Other changes just send a get back to the user admin page

        // Check current state against desired state and act accordingly.
        if ($my_userscurrentstate == 0 && $my_usersactive == 0){
            // User is already inactive so no change needed
            werl($_SERVER['PHP_SELF'] . "\tUser ID [{$my_userid}] [{$my_useruid}] already inactive so no action taken.");
            header("location: ../user_admin.php?code=41");
            exit();

        } elseif ($my_userscurrentstate == "1" && $my_usersactive == "1") {
            // User is already inactive so no change needed
            werl($_SERVER['PHP_SELF'] . "\tUser ID [{$my_userid}] [{$my_useruid}] already active so no action taken.");
            header("location: ../user_admin.php?code=42");
            exit();
  
        } elseif ($my_userscurrentstate == "1" && $my_usersactive == "0") {
            // User is being demoted so no email send needed
            werl($_SERVER['PHP_SELF'] . "\tUser ID [{$my_userid}] [{$my_useruid}] is being demoted so no action taken.");
            header("location: ../user_admin.php?code=44");
            exit();     
        
        } elseif ($my_userscurrentstate == 0 && $my_usersactive == 1){
            // User state has changedfrom inactive to active, so email the user
            werl($_SERVER['PHP_SELF'] . "\tUser promoted from Inactive to Active.  Notification email will be sent.");

            // Send an email to the user to advise them that their account has been activated
            $mail = new PHPMailer(TRUE);
            werl($_SERVER['PHP_SELF'] . "\tPreparing activation email to [{$my_useremail}].");
            try {
              // SMTP parameters.
              $mail->isSMTP();                              // Tells PHPMailer to use an external SMTP server
              $mail->Host = 'mail.kelvinhaugh.com.au';      // SMTP server address.
              $mail->Port = 587;                            // Set the SMTP port number - likely to be 25, 465 or 587
              $mail->SMTPAuth = TRUE;                       // Whether to use SMTP authentication
              $mail->Username = 'ajw@kelvinhaugh.com.au';   // Username to use for SMTP authentication
              $mail->Password = 'bpcm115';                  // Password to use for SMTP authentication
              
              //Set who the message is to be sent from
              $mail->setFrom('ajw@kelvinhaugh.com.au', 'Temere System Administrator');
              $mail->addAddress($my_useremail, $my_userfullname);
              $mail->Subject = $jobs_systemname . ' Account Activation';
    
              
    
              // Build the message body
              $my_messagebody_html = "<html>";
              $my_messagebody_html .= "Your account on <strong>{$jobs_systemname}</strong> has been activated by the administrator.";
              $my_messagebody_html .= "<br> The username you provided at registration was <strong>{$my_useruid}</strong>.";  
              $my_messagebody_html .= "<br> Please use it and your selected password to login to the system.";
              $my_messagebody_html .= "<br><br>";
    
              $my_messagebody_html .= '<a href="http://www.kelvh.com.au/temere/login.php" style="color: #0000ff;">' . $jobs_systemname . '</a>';
              $my_messagebody_html .= "<p>Cheers, <br>Ashley</p>";
    
              $my_messagebody_html .= "</html>";
    
              echo $my_messagebody_html;

              $mail->isHTML(TRUE);
              $mail->Body = $my_messagebody_html;
              
              $mail->AltBody = 'Your account on the system has been activated by the administrator.';
              echo "<br>Enable debug here <br>";
              // Enable SMTP debug output. 
    
              // Before the send
              $smtpLogs = [];
              $mail->SMTPDebug = 0;
              $mail->Debugoutput = function($str, $level) {
                file_put_contents('/var/tmp/aw-smtp.log', gmdate('Y-m-d H:i:s'). "\t$level\t$str\n", FILE_APPEND | LOCK_EX);
              };
              echo "Done <br>";
              
              // Finally send the email.
              $mail->Send();
              werl($_SERVER['PHP_SELF'] . "\tAccount activation email was sent to [{$my_useremail}].");
            }
            catch (Exception $e) {
              echo $e->errorMessage();
              werl($_SERVER['PHP_SELF'] . "\tAccount activation email failed [{$e->errorMessage()}].");
            }
            catch (\Exception $e) {
              echo $e->getMessage();
              werl($_SERVER['PHP_SELF'] . "\tAccount activation email failed [{$e->getMessage()}].");
            }
            // End of email sending
            
            header('Location: ' . '../user_admin.php?code=43');
            exit();
        }



        header('Location: ' . '../user_admin.php?code=41');
    ?>

    </body>
</html>

