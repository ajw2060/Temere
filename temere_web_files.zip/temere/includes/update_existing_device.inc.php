
<?php

    // This is the script to apply the updates to the Device
    
    //  Change History
    //  2023-08-26  Initial build
    


?>


<?php
    error_reporting(E_ALL); 
    ini_set('display_errors', '1');

    require_once 'dbh.inc.php';
    require_once 'functions.inc.php';
    werl($_SERVER['PHP_SELF'] . "\t------ Page load ------");

    echo "Dump follows <br><pre>", var_dump($_POST), "</pre>";
    //exit();
    
?>
      
<?php
    // Now do the SQL updates to the Schedule table given the user input.
    // Some daata validation needs to happen first.
    werl($_SERVER['PHP_SELF'] . "\tPreparing to update Device details for Device ID [" . $_POST["device_id"] . "].");

 

    // Handle pesky apostrophe inside comment text by doubling them up
    $my_devicedescription_safe = str_replace("'", "''", $_POST['device_description']);

    // Deny activation if the Control is not populated
    $permit_deviceactivation = true;       # Assume all is good until found otherwise.
    $desired_activationstate = $_POST['device_enable'];    // Just make the user's desire easier to wrangle later
 


    // If we are updating a new device and the Control ID is still NULL, then handle such
    if ($_POST['device_controlid'] == ""){
        werl($_SERVER['PHP_SELF'] . "\tCompensating for empty device_controlid field.");
        $my_devicecontrolid = 'NULL';
        $permit_deviceactivation = 0;           // Deny activation if no control is defined
    } else {
        $my_devicecontrolid = $_POST['device_controlid'];
    }
    
    // Check if 'device_active' has been requested but no control id has been selected, then override it and alert the user
    if ($desired_activationstate == "1" AND $permit_deviceactivation == 1){
        werl($_SERVER['PHP_SELF'] . "\tActivation is desired [{$desired_activationstate}] and permitted [{$permit_deviceactivation}] so device will be activated.");
        $my_activationstate = 1;
        $ret_msg = "Device activated as requested";
    } elseif ($desired_activationstate == "0" ) {
        werl($_SERVER['PHP_SELF'] . "\tActivation is not desired [{$desired_activationstate}] so device will not be activated.");
        $my_activationstate = 0;
        $ret_msg = "Device activation not requested";
    } elseif ($desired_activationstate == "1" AND $permit_deviceactivation == 0 ) {
        werl($_SERVER['PHP_SELF'] . "\tActivation is desired [{$desired_activationstate}] but not permitted [{$permit_deviceactivation}] so device will not be activated.");
        $my_activationstate = 0;
        $ret_msg = "Device activation denied due to missing Control";
    } else{
        werl($_SERVER['PHP_SELF'] . "\tSomething got confused here.  This should not happen.  Desired [{$desired_activationstate}]. Permitted [{$permit_deviceactivation}].");
        $my_activationstate = 0;
        $ret_msg = "Warning 230902. Something broke.  Contact the administrstor";
    }    
    
    $my_controlid = NULL . $_POST['device_controlid'];
   
    $sql_update = "UPDATE devices  
      SET 
          device_name = '{$_POST['device_name']}'
        , device_description = '{$my_devicedescription_safe}'
        , device_vendor = '{$_POST['device_vendor']}'   
        , device_controlid = $my_devicecontrolid
        , device_active = {$my_activationstate}
        WHERE device_id = {$_POST["device_id"]};";

        werl($_SERVER['PHP_SELF'] . "\t" . $sql_update);


    if (mysqli_query($conn, $sql_update)) {
        werl($_SERVER['PHP_SELF'] . "\tThe Device update succeeded.");
        $result = 0;
    } else {
        werl($_SERVER['PHP_SELF'] . "\tError during Device update. "   . mysqli_error($conn) );     // Log message
        $result = 1;
    }

    mysqli_close($conn);

    if ($result == 0){
        header("location: ../manage_devices.php?code=10&msg=Device ID [{$_POST['device_id']}] updated successfully.  {$ret_msg}");
        exit();
    } else {
        header("location: ../manage_devices.php?code=11&msg=Failure during update of Device ID [{$_POST['device_id']}]");
        exit();


    }
?>

    </body>
</html>
 */
