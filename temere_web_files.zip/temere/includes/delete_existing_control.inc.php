
<?php

    // This is the script to delete a control
    
    //  Change History
    //  2023-09-01  Initial build


?>


<?php
    error_reporting(E_ALL); 
    ini_set('display_errors', '1');

    require_once 'dbh.inc.php';
    require_once 'functions.inc.php';
    werl($_SERVER['PHP_SELF'] . "\t------ Page load ------");

    echo "Dump follows <br><pre>", var_dump($_POST), "</pre>";
    //exit();
    
?>


<?php
    // Now do the SQL updates to the control table given the user input.
    // Some daata validation needs to happen first.
    werl($_SERVER['PHP_SELF'] . "\tPreparing to delete Control ID [" . $_POST["control_id"] . "].");
    
    
    $sql_delete = "DELETE FROM controls WHERE control_id={$_POST["control_id"]};";

    if (mysqli_query($conn, $sql_delete)) {
        werl($_SERVER['PHP_SELF'] . "\t" . "The control delete succeeded.");
    } else {
        werl($_SERVER['PHP_SELF'] . "\t" . "Error during control delete: " . mysqli_error($conn));     // Log message
        //echo "Error deleting record: " . mysqli_error($conn);
    }

    
    mysqli_close($conn);

    header('Location: ' . '../manage_controls.php');
    exit();
?>

    </body>
</html>
 */
