<?php

    // This is the script to send the switch on or switch off message to a device
    // This allows the user to test functionality without waiting for a Sequence event.
    
    //  Change History
    //  2023-08-27  Initial build


?>


<?php
    error_reporting(E_ALL); 
    ini_set('display_errors', '1');

    require_once 'dbh.inc.php';
    require_once 'functions.inc.php';
    werl($_SERVER['PHP_SELF'] . "\t------ Page load ------");

    echo "Dump follows of POST array <br><pre>", var_dump($_POST), "</pre>";
    //exit();
?>

<?php
    // This is where the work happens.  This has to be done.
    // - Use the received device_id to grab the necessary details from the devices and controls table.
    // - Use this detail to construct the script to run
    // - call the script (which is a python script)

    // First, find out if we are doing a turn on or turn off
    if( isset($_POST['test_on']) ) {
        $my_function = "TURN ON";
    } else {
        $my_function = "TURN OFF";
    }


    switch($_POST["function"]){
        case "1":
            werl($_SERVER['PHP_SELF'] . "\tSwitch [ON] test requested for device ID [{$_POST['device_id']}].");
            break;
        
        case "0":
            werl($_SERVER['PHP_SELF'] . "\tSwitch [OFF] test requested for device ID [{$_POST['device_id']}].");
            break;
        }        



    // Get the detail from the devices joined with controls for the given device_id
    // Need a join in the tables to grab all we need in one shot.
    werl($_SERVER['PHP_SELF'] . "\tGetting control details for this device.");
    $sql_test = "SELECT
        devices.device_id               AS device_id,
        devices.device_name             AS device_name,
        controls.control_name           AS control_name,
        controls.control_description,
        devices.device_controlid,
        controls.device_guid            AS device_guid,
        controls.control_script         AS control_script
    FROM devices
    INNER JOIN controls ON devices.device_controlid = controls.control_id
    WHERE devices.device_id = {$_POST['device_id']};";

    $result_test = mysqli_query($conn, $sql_test) or die(mysqli_error($conn));
    $num_rows = mysqli_num_rows($result_test);
    werl($_SERVER['PHP_SELF'] . "\tSQL returned [{$num_rows}] rows from the query.");

    // Normalise the device function
    if ($_POST["function"] == 0){
        $my_devicefunction = "off";
    } elseif ($_POST["function"] == 1){
        $my_devicefunction = "on";
    } else {
        $my_devicefunction = "invalid";
    }

    $row_test = mysqli_fetch_assoc($result_test);
    // Now just simplify the variables and log what we are about to do
    $my_devicename = $row_test['device_name'];
    $my_deviceid = $row_test['device_id'];
    $my_controlname = $row_test['control_name'];
    $my_deviceguid = $row_test['device_guid'];
    $my_controlscript = $row_test['control_script'];
    

    werl($_SERVER['PHP_SELF'] . "\t---- Control information ----------------");
    werl($_SERVER['PHP_SELF'] . "\t Device ID ........ [{$my_deviceid}]");
    werl($_SERVER['PHP_SELF'] . "\t Device Name ...... [{$my_devicename}]");
    werl($_SERVER['PHP_SELF'] . "\t Device GUID ...... [{$my_deviceguid}]");
    werl($_SERVER['PHP_SELF'] . "\t Control Name ..... [{$my_controlname}]");
    werl($_SERVER['PHP_SELF'] . "\t Control Script ... [{$my_controlscript}]");
    werl($_SERVER['PHP_SELF'] . "\t Device Function .. [{$my_devicefunction}]");
    werl($_SERVER['PHP_SELF'] . "\t-------------------------------------");


    // Now prepare the command line ready to run
    $command_line = "../scripts/" . $my_controlscript . " " . $my_deviceguid . " " . $my_devicefunction;
    werl($_SERVER['PHP_SELF'] . "\tCommand line [{$command_line}]");

    $output = shell_exec($command_line);
    werl($_SERVER['PHP_SELF'] . "\tOutput [{$output}]");



    $myArray = explode(PHP_EOL, $output); //break each line

    echo "<pre>";
    var_dump($myArray);

    echo "</pre>";
    //exit();


    echo"<br>----------Test 1 follows<br>";
    $my_result = $myArray[4];
    var_dump($my_result);    


    $fred = explode(",", $my_result);



    echo "<br>--- Fred follows <pre>";
    var_dump($fred);
    echo "</pre>";



    // Now extract the useful bits from the result string
    $start  = strpos($my_result, '{');
    $end    = strpos($my_result, '}', $start + 1);
    $length = $end - $start;
    $return_message = substr($my_result, $start + 1, $length - 1);





    //exit();
    
?>



<?php
    //$return_message = "Sent test command to device";
    werl($_SERVER['PHP_SELF'] . "\tTest sequence [{$my_devicefunction}] complete for Device ID [{$_POST['device_id']}].");
    header("location: ../manage_devices.php?code=3&msg={$return_message}");
    exit();

?>