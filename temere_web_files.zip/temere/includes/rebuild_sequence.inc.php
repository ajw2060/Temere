<?php

    // This is the script to force a rebuild of the sequence table.
    
    //  Change History
    //  2023-08-17  Initial build


?>


<?php
    error_reporting(E_ALL); 
    ini_set('display_errors', '1');

    require_once 'dbh.inc.php';
    require_once 'functions.inc.php';
    werl($_SERVER['PHP_SELF'] . "\t------ Page load ------");

    //echo "Dump follows <br><pre>", var_dump($_POST), "</pre>";
    //exit();
    
?>







<?php
    // Call the rebuild script whivh is a python script
    // $script_name = "/home/awoods/Scripts/Temere/planner.py";
    //echo "<br>Rebuilding sequence using planner script<br>";
    
    

    //echo exec('whoami');

    $command_line = '/var/www/html/temere/scripts/planner.sh 2>&1';
    //$command_line = "/home/awoods/temere/bin/python3.8 /home/awoods/Scripts/Temere/planner.py /home/awoods/Scripts/Temere/planner.yaml /home/awoods/Logs/Temere/planner.log 2>&1";
    //$command_line = "python3.8 /home/awoods/Scripts/Temere/planner.py /home/awoods/Scripts/Temere/planner.yaml /home/awoods/Logs/Temere/planner.log";
    //$command_line = "/home/awoods/temere/bin/python3.8 --version 2>&1";

    werl($_SERVER['PHP_SELF'] . "\tCommand line [{$command_line}]");

    //echo "<pre>Command line follows...<br>$command_line </pre>";
    $output = shell_exec($command_line);
    werl($_SERVER['PHP_SELF'] . "\tOutput [{$output}]");
    //echo "<br>Script output [{$output}] <br>";


    //exit();
    //echo"<br>--- end --- <br>";


    werl($_SERVER['PHP_SELF'] . "\tSequence rebuild completed");
    header("location: ../index.php?code=2&msg=Sequence rebuild completed.");
    exit();

?>