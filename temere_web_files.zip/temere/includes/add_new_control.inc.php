<?php
  // This is the add new control script.  It does the following
  // - accepts user input via POST
  // - runs the SQL add function
  
  //  Change History
  //  2023-08-31  Initial build
  
?>



<?php
  session_start();
  echo "<pre>", var_dump($_POST), "</pre>";
  //exit();

  require_once 'dbh.inc.php';
  require_once 'functions.inc.php';
  werl($_SERVER['PHP_SELF'] . "\t------ Page load ------");

  if(isset($_POST['control_name'])){
    // Got the variable so proceed
    // Assign local variables to simplify handling
    $my_controlname = $_POST['control_name'];
    $my_controldescription = $_POST['control_description'];

    
    // Validity checks on posted data
    werl($_SERVER['PHP_SELF'] . "\tSanity checking presented inputs for new control.");

    werl($_SERVER['PHP_SELF'] . "\t  Control Name [" . $my_controlname . "].");
    werl($_SERVER['PHP_SELF'] . "\t  Control Description [" . $my_controldescription . "].");

    // Control Name cannot be empty
    if(strlen($my_controlname) == 0) {
        $msg="Control Name must be provided.";     
        werl($_SERVER['PHP_SELF'] . "\t  ERROR 31.  {$msg}.");
        header("location: ../add_new_control.php?code=31&msg={$msg}");
        exit();
    } else {
      werl($_SERVER['PHP_SELF'] . "\t  Control Name [{$my_controlname}] is acceptable.");
    }  
    
    // Control Description cannot be empty
    if(strlen($my_controldescription) == 0) {
        $msg="Control Description must be provided.";     
        werl($_SERVER['PHP_SELF'] . "\t  ERROR 31.  {$msg}.");
        header("location: ../add_new_control.php?code=31&msg={$msg}");
        exit();
    } else {
        werl($_SERVER['PHP_SELF'] . "\t  Control Description [{$my_controldescription}] is acceptable.");
    }
  
 
    // Get user details from session
    $my_userid = $_SESSION['useruid'];
    $my_currentdate = date('Y-m-d');
    $my_isdirty = 1;
    
    
    // Prepare and bind
    $sql = "INSERT INTO controls (control_name, control_description, control_active) 
    VALUES (?, ?, ?);";
    
    $my_controlactive = 0;
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sss", $my_controlname, $my_controldescription, $my_controlactive);
    $fred = $stmt->execute();
    $latest_id =  mysqli_insert_id($conn); 

    
    if ($fred ==1){
      werl($_SERVER['PHP_SELF'] . "\tA new control record has been created with ID [" . $latest_id ."].");
      header("location: ../manage_controls.php?code=0&msg=New Control ID [{$latest_id}].");
    }else{
      $response_message = "Error " . mysqli_error($conn) ;
      werl($_SERVER['PHP_SELF'] . "\tFailed to create the new control record. Error: [$response_message]." ); 
      header("location: ../manage_controls.php?code=23&msg={$response_message}");
    }

        
  }
  else{
    werl($_SERVER['PHP_SELF'] . "\tERROR.  The 'control_name' was not received.");
    header("location: ../manage_controls.php");
    exit();
  }
