<?php

  if(isset($_POST["submit"])){
    $username = $_POST["uid"];
    $pwd = $_POST["pwd"];
    //echo $username;
    //echo $pwd;

    require_once 'functions.inc.php';
    require_once 'dbh.inc.php';
    
    werl($_SERVER['PHP_SELF'] . "\t------ Page load ------");
    
    
    if (emptyInputLogin($username, $pwd) !== false){
      header("location: ../login.php?error=emptyinput");
      exit();  
    }

    werl($_SERVER['PHP_SELF'] . "\tUser login attempt for [$username]");   
    
    
    loginUser($conn, $username, $pwd);
    
  }
  else{
    header("location: ../login.php?code=1");
    exit();
  }
