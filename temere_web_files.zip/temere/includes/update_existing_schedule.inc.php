
<?php

    // This is the script to apply the updates to the Schedule
    
    //  Change History
    //  2023-08-10  Initial build
    //  2023-08-17  Added overlap check


?>


<?php
    error_reporting(E_ALL); 
    ini_set('display_errors', '1');

    require_once 'dbh.inc.php';
    require_once 'functions.inc.php';
    werl($_SERVER['PHP_SELF'] . "\t------ Page load ------");

    echo "Dump follows <br><pre>", var_dump($_POST), "</pre>";
    //exit();
    
?>
      
<?php
    // Now do the SQL updates to the Schedule table given the user input.
    // Some daata validation needs to happen first.
    werl($_SERVER['PHP_SELF'] . "\tPreparing to update Schedule details for Schedule ID [" . $_POST["schedule_id"] . "].");

    // Trigger weighting must be 0 - 100 so enforce it.
    $my_trigger_weighting = $_POST['trigger_weighting'];
    if ($my_trigger_weighting < 0 or $my_trigger_weighting > 100){
        $return_message = "Trigger Weighting [" . $my_trigger_weighting . "] is out of bounds.";
        werl($_SERVER['PHP_SELF'] . "\tERROR 31. " . $return_message);
        header("location: ../index.php?code=31&msg=$return_message");
        exit();
    }


    // On duration must be 1 - 600 (to agree with the values in the add function)
    $my_onduration = $_POST['active_duration'];
    if ($my_onduration < 1 or $my_onduration > 600){
        $return_message = "Duration [" . $my_onduration . "] is out of bounds.";
        werl($_SERVER['PHP_SELF'] . "\tERROR 31. " . $return_message);
        header("location: ../index.php?code=31&msg=$return_message");
        exit();
    }



    // Handle pesky apostrophe inside comment text by doubling them up
    $my_comment_safe = str_replace("'", "''", $_POST['comment']);

    // Park the user desired activation status
    $my_desiredscheduleenable = $_POST["schedule_enable"];

   
    $sql_update = "UPDATE schedule  
      SET 
        schedule_type={$_POST["schedule_type"]}" .
        ", trigger_weighting={$my_trigger_weighting}" .
        ", turn_on_time='{$_POST["turn_on_time"]}'" .   
        ", turn_on_flex={$_POST["turn_on_flex"]}" .
        ", active_duration={$_POST["active_duration"]}" .
        ", active_duration_flex={$_POST["active_duration_flex"]}" .
        ", comment='{$my_comment_safe}'" .
        ", schedule_enable=2" .
        ", is_dirty=1" .
        " WHERE schedule_id={$_POST["schedule_id"]};";

    if (mysqli_query($conn, $sql_update)) {
        werl($_SERVER['PHP_SELF'] . "\t" . "The Schedule update succeeded.");
    } else {
        werl($_SERVER['PHP_SELF'] . "\t" . "Error during Schedule update.");     // Log message
    }


    // Now do the overlap check before allowing the Schedule status to be set as user desired.
    // The check has to be done after the SQL update so we get the most up to date time settings.
    $overlap_result = check_for_overlaps($conn, $_POST["schedule_id"]);
    werl($_SERVER['PHP_SELF'] . "\tNumber of collisions detected is [" . sizeof($overlap_result) . "]." ); 
    

    if (sizeof($overlap_result) == 0){
        werl($_SERVER['PHP_SELF'] . "\tNo overlap detected.  User desired activation state [{$my_desiredscheduleenable}] will be honoured.");
        // Allow the user activation state to be applied
        // Admit his new schedule by setting the schedule_enable flag to the users desired state (which could be disabled anyway).
        $sql_setenable = "UPDATE schedule SET schedule_enable={$my_desiredscheduleenable} WHERE schedule_id = {$_POST["schedule_id"]}";
        if(mysqli_query($conn, $sql_setenable)){
            echo "Records were updated successfully.";
            werl($_SERVER['PHP_SELF'] . "\tSchedule status updated to [" . $my_desiredscheduleenable . "] for schedule_id [" . $_POST["schedule_id"] . "].");
        } else {
            echo "ERROR:  SQL Update failed " . mysqli_error($conn);
        }
    } else {
        // Do nothing further as the activation state has already been set to Denied
        // Prepare the message text showing which Schedules are conflicting
        foreach ($overlap_result as $value) {
            $conflict_list = $conflict_list . strval($value) . ", ";
        }
        $conflict_list = substr($conflict_list, 0, -2);   // Remove the final comma and space
        $return_message = "Timing overlap detected with Schedule [" . $conflict_list . "].  Activation denied.";
        werl($_SERVER['PHP_SELF'] . "\tERROR."  . $return_message);
    }

    mysqli_close($conn);

    if (sizeof($overlap_result) == 0){
        header("location: ../index.php?code=1&msg=Schedule ID [{$_POST["schedule_id"]}] updated successfully");
        exit();
    } else {
        header("location: ../index.php?code=42&msg={$return_message}");
        exit();


    }
?>

    </body>
</html>
 */
