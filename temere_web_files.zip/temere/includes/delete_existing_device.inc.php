
<?php

    // This is the script to delete a device
    
    //  Change History
    //  2023-09-01  Initial build


?>


<?php
    error_reporting(E_ALL); 
    ini_set('display_errors', '1');

    require_once 'dbh.inc.php';
    require_once 'functions.inc.php';
    werl($_SERVER['PHP_SELF'] . "\t------ Page load ------");

    echo "Dump follows <br><pre>", var_dump($_POST), "</pre>";
    //exit();
    
?>


<?php
    // Now do the SQL updates to the Device table given the user input.
    // Some daata validation needs to happen first.
    // This needs to delete the device and all related Controls.
    
    werl($_SERVER['PHP_SELF'] . "\tPreparing to delete Device ID [" . $_POST["device_id"] . "].");
    
    
    $sql_delete = "DELETE FROM devices WHERE device_id={$_POST["device_id"]};";

    if (mysqli_query($conn, $sql_delete)) {
        werl($_SERVER['PHP_SELF'] . "\t" . "The device delete succeeded.");
    } else {
        werl($_SERVER['PHP_SELF'] . "\t" . "Error during device delete: " . mysqli_error($conn));     // Log message
        //echo "Error deleting record: " . mysqli_error($conn);
    }

    
    mysqli_close($conn);

    header('Location: ' . '../manage_devices.php');
    exit();
?>

    </body>
</html>
 */
