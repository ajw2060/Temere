
<?php

    // This is the script to apply the updates to the Control
    
    //  Change History
    //  2023-09-01  Initial build
    


?>


<?php
    error_reporting(E_ALL); 
    ini_set('display_errors', '1');
    require_once 'dbh.inc.php';
    require_once 'functions.inc.php';
    werl($_SERVER['PHP_SELF'] . "\t------ Page load ------");

    echo "Dump follows <br><pre>", var_dump($_POST), "</pre>";
    //exit();
    
?>
      
<?php
    // Now do the SQL updates to the Controls table given the user input.
    // Some daata validation needs to happen first.
    werl($_SERVER['PHP_SELF'] . "\tPreparing to update Control details for Control ID [" . $_POST["control_id"] . "].");

     

    // Before a Control can be set as active, it must have all the required fields defined.
    // This includes several pieces of data; 
    // - the device_id 
    // - the device_guid
    // - the control name (which was defined at creation, but which can be edited))
    // - the control description (also defined at creation, but which can also be edited) 
    // - the control script
    // The following code validates these requirements.
    $permit_controlactivation = true;       # Assume all is good until found otherwise.
    $desired_activationstate = $_POST['control_enable'];    // Just make the user's desire easier to wrangle later
    
    // Check 1.  Do we (still) have a control name.
    if ($_POST['control_name'] == ""){
        werl($_SERVER['PHP_SELF'] . "\tError.  No control_name was received.");
        $my_controlname = NULL;
        $permit_controlactivation = false;
        $missing_input = "Control Name";
    } else {
        $my_controlname = $_POST['control_name'];
    }

    // Check 2.  Do we (still) have a control description.
    if ($_POST['control_description'] == ""){
        werl($_SERVER['PHP_SELF'] . "\tWarning.  No control_description was received.");
        $my_controldescription_safe = NULL;
        $permit_controlactivation = false;
        $missing_input = "Control Description";
    } else {
        // Handle pesky apostrophe inside description text by doubling them up
        $my_controldescription_safe = str_replace("'", "''", $_POST['control_description']);
    }

    // Check 3.  Do we have a device_id.  Probably will have as it was a dropdown from the previous page, but check anyway.
    if ($_POST['device_id'] == ""){
        werl($_SERVER['PHP_SELF'] . "\tWarning.  No device_id was received.");
        $my_deviceid = NULL . $_POST['device_id'];
        $permit_controlactivation = false;
        $missing_input = "Device ID";
    } else {
        $my_deviceid = $_POST['device_id'];
    }
    
    // Check 4.  Do we have a device_guid.
    if ($_POST['device_guid'] == ""){
        werl($_SERVER['PHP_SELF'] . "\tWarning.  No device_guid was received.");
        $my_deviceguid = NULL . $_POST['device_guid'];
        $permit_controlactivation = false;
        $missing_input = "Device GUID";
    } else {
        $my_deviceguid = $_POST['device_guid'];
    }
       
    // Check 4.  Do we have a control script.
    if ($_POST['control_script'] == ""){
        werl($_SERVER['PHP_SELF'] . "\tWarning.  No control_script was received.");
        $my_deviceguid = NULL . $_POST['control_script'];
        $permit_controlactivation = false;
        $missing_input = "Device Control Script";
    } else {
        $my_controlscript = $_POST['control_script'];
    }


    // Determine the actual activation setting 
    werl($_SERVER['PHP_SELF'] . "\tDetermining Control Activation state.");
    if ($desired_activationstate == "1" AND $permit_controlactivation == true){
        $my_activationstate = 1;
        $user_message = "Control activated.";
        werl($_SERVER['PHP_SELF'] . "\tControl activation was requested and permitted.");
    } else if ($desired_activationstate == "0"){
        $my_activationstate = 0;
        $user_message = "Control activation not requested.";
        werl($_SERVER['PHP_SELF'] . "\tControl activation not requested by user.");
    } else if ($desired_activationstate == "1" AND $permit_controlactivation == false){
        $my_activationstate = 0;
        $user_message = "Control activation was not permitted due to missing data.";
        werl($_SERVER['PHP_SELF'] . "\tControl activation not permitted due to missing data.");
    } else {
        $my_activationstate = 0;
        $user_message = "Control activation denied due to system confusion";
        werl($_SERVER['PHP_SELF'] . "\tControl activation is confused.  This should not happen.");
    }

    
    // Now do the actual update of the control.
    $sql_update = "UPDATE controls  
      SET 
          control_name = '{$my_controlname}'
        , control_description = '{$my_controldescription_safe}'
        , device_id = '{$my_deviceid}'
        , device_guid = '{$my_deviceguid}' 
        , control_script = '{$my_controlscript}'  
        , control_active = {$my_activationstate}
        WHERE control_id = {$_POST['control_id']};";

        //werl($_SERVER['PHP_SELF'] . "\t" . $sql_update);


    if (mysqli_query($conn, $sql_update)) {
        werl($_SERVER['PHP_SELF'] . "\tThe Control update succeeded.");
        werl($_SERVER['PHP_SELF'] . "\tThis Control [{$_POST['control_id']}] now supports Device ID [{$my_deviceid}].");
        $result = 0;
    } else {
        werl($_SERVER['PHP_SELF'] . "\tError during Control update. "   . mysqli_error($conn));     // Log message
        $result = 1;
    }

    // Tidy up 1
    // If the control ends up disabled for any reason, then we need to disable the device(s) which depend on this control.
    if ($my_activationstate == 0){
        werl($_SERVER['PHP_SELF'] . "\tDisabling all devices which depend on this disabled control [{$_POST['control_id']}].");
        $sql_disabledependentdevices = "UPDATE devices
            SET device_active = 0
            WHERE device_controlid = {$_POST['control_id']};";

        //werl($_SERVER['PHP_SELF'] . "\t" . $sql_disabledependentdevices);

        if (mysqli_query($conn, $sql_disabledependentdevices)) {
            werl($_SERVER['PHP_SELF'] . "\t.The Dependent device(s) were successfully disabled.");
            //$result = 0;
        } else {
            werl($_SERVER['PHP_SELF'] . "\t.Failed to disable the Dependent device. "   . mysqli_error($conn));
            //$result = 1;
        }
    }

    // Tidy up 2
    // If we have just assigned this control to a different device, that legacy device will be left 
    // with an old Control assigned to it.
    // That old Control may no longer work for it, so the legacy device must be disabled pending a new control being 
    // (possibly created) and then assigned to it.  
    // However if some other attribute of the control is edited and it continues to support the same device
    // then no subsequent tidy up is needed.
    // So find the device that could be already using this control (if any)
    // If any different legacy device is found, it needs to be disabled.
    werl($_SERVER['PHP_SELF'] . "\tChecking if any devices rely on this Control.");
    $sql_legacydevices = "SELECT device_id 
        , device_name
        FROM devices
        WHERE device_controlid = {$_POST["control_id"]};";
    $result_legacydevices = mysqli_query($conn, $sql_legacydevices) or die(mysqli_error($conn));
    $legacy_devicecount = mysqli_num_rows($result_legacydevices);
    werl($_SERVER['PHP_SELF'] . "\tFound [{$legacy_devicecount}] device depending on Control ID [{$_POST["control_id"]}].");
    if ($legacy_devicecount > 0){
        // Some legacy device was depending on this control and this control has now been assigned to a different device
        // so we need to flag the legacy device as disabled so the user is forced to find a new control for the legacy device.
        // While there may be more than one control available to that legacy device, it was depending on this very one, so the 
        // fix may be as easy as selecting another control for the legacy device.
        $legacy_device = mysqli_fetch_assoc($result_legacydevices);
        $legacy_deviceid = $legacy_device['device_id'];
        $legacy_devicename = $legacy_device['device_name'];
        werl($_SERVER['PHP_SELF'] . "\tDevice ID [{$legacy_deviceid}] [$legacy_devicename] depends on Control ID [{$_POST['control_id']}].");

        // Now check if the legacy device is the current device, and if so no action is needed.
        if ($legacy_deviceid == $my_deviceid){
            werl($_SERVER['PHP_SELF'] . "\tThe legacy device [{$legacy_deviceid}] is the same as the current device [{$my_deviceid}] so no action needed.");
        } else {
            werl($_SERVER['PHP_SELF'] . "\tDevice ID [{$legacy_deviceid}] will be disabled as it can no longer use this Control. ");

            $sql_disableorphandevices = "UPDATE devices
            SET device_active = 0
            WHERE device_id = {$legacy_deviceid};";
            if (mysqli_query($conn, $sql_disableorphandevices)) {
                werl($_SERVER['PHP_SELF'] . "\t.The Orphaned device was successfully disabled.");
                //$result = 0;
            } else {
                werl($_SERVER['PHP_SELF'] . "\t.Failed to disable the Orphaned device. "   . mysqli_error($conn));
                //$result = 1;
            }
            


        }

    
    } else {
        werl($_SERVER['PHP_SELF'] . "\t.No legacy devices were dependent on Control ID [{$_POST['control_id']}] so no device to disable.");
    }












    mysqli_close($conn);

    if ($result == 0){
        header("location: ../manage_controls.php?code=10&msg=Control ID [{$_POST['control_id']}] updated. {$user_message}");
        exit();
    } else {
        header("location: ../manage_controls.php?code=11&msg=Failure during update of Control ID [{$_POST['control_id']}]");
        exit();
    }
?>

    </body>
</html>

