
<?php
  // This is the documentation page for the Temere System.  
  
  // Change History
  // 2023-08-05 Initial build

  
  
?>

<?php
  error_reporting(E_ALL); 
  ini_set('display_errors', '1');
  //ini_set('display_errors',0);

  include_once 'includes/header.inc.php';
  require_once 'includes/functions.inc.php';
  require_once 'includes/dbh.inc.php';
  
  werl($_SERVER['PHP_SELF'] . "\t------ Page load ------");     // Log message
?>


<link rel="stylesheet" href="css/documentation_css.css">


  <body>
  
    <h1><?php echo $jobs_systemname; ?> - Documentation</h1>
     <h2> This is the Documentation for the Temere Scheduler </h2>

<br>
      <h3>Creating a Control </h3>
<p>
    A 'Control' is the entity which actually contains all the detail needed to actually control a device.  
Each Device must have at least one Control defined for it, but it may have multiple Controls.  A Control is specific to the channel used to control a device.  

<p>
For example a light may be controlled by a smart outlet, which is controlled by Tuya.  This smart outlet may also be configured in Home Assistant, which can control the outlet.  
So in this example, we could define the following Controls

<ul>
    <li> one for controlling the smart socket via Tuya Cloud   </li>
    <li> one for controlling the same smart socket via Home Asssistant  </li>
    <li> one for controlling the same smart socket via Tuya Local  </li>
</ul>
Each control will have its own set of parameters, but all will be able to control the same outlet.  

<p>
Although a Device can be controlled in numerous different ways, each Device can only ever be associated with <strong> one </strong> of these Controls at a time.  A Device must be associated with a Control 
before the Device can be built into a Schedule.  It is possible to create Devices with slightly different names, but have them
all be the same smart socket.  Each of these 'slightly different' names will use a copy of the same Control (with a different Control ID.)  These 'slightly different' Devices can then all be Scheduled.  
While this will work, it is dangerous because there is no overlap detection performed across different devices.  This could cause unpredictable results, so the recommended approach is to define each Device once and select the desired Control for the device. 

<p>
The ability to define multiple Controls for a device simply allows flexibility to control devices via different channels, with the ability to switch between Control methods if desired.
<p>



</body>

