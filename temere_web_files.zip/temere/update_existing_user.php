
<?php

  // This is the actual edit script.  It does the following
  // - allows edit of the selected user

  // Change History
  // 2023-07-02 Initial build
  
?>

<?php
  include 'includes/header.inc.php';
  require_once 'includes/dbh.inc.php';
  require_once 'includes/functions.inc.php';
  werl($_SERVER['PHP_SELF'] . "\t------ Page load ------");
?>

<link rel="stylesheet" href="css/index_css.css">

<?php
  if (isset($_SESSION["useruid"])){
    echo "Welcome " . $_SESSION["userfullname"] ;
  }
  else {
    header("location: login.php");
  }
?>


<style>

  #myDIV {
    width: 100%;
    padding-left: 0px;
    text-align: xcenter;
    background-color: xlightblue;
    margin-top: 5px;
  }

  .switch {
    position: relative;
    display: inline-block;
    width: 60px;
    height: 34px;
  }

  .switch input { 
    opacity: 0;
    width: 0;
    height: 0;
  }

  .slider {
    position: absolute;
    cursor: pointer;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background-color: #ccc;
    -webkit-transition: .4s;
    transition: .4s;
  }

  .slider:before {
    position: absolute;
    content: "";
    height: 26px;
    width: 26px;
    left: 4px;
    bottom: 4px;
    background-color: white;
    -webkit-transition: .4s;
    transition: .4s;
  }

  input:checked + .slider {
    background-color: #2196F3;
  }

  input:focus + .slider {
    box-shadow: 0 0 1px #2196F3;
  }

  input:checked + .slider:before {
    -webkit-transform: translateX(26px);
    -ms-transform: translateX(26px);
    transform: translateX(26px);
  }

  /* Rounded sliders */
  .slider.round {
    border-radius: 34px;
  }

  .slider.round:before {
    border-radius: 50%;
  }


  /* Tooltip container */
  .tooltip {
    position: relative;
    display: block;
    border-bottom: 0px dotted black; /* If you want dots under the hoverable text */
  }

  /* Tooltip text */
  .tooltip .tooltiptext {
    visibility: hidden;
    width: 150px;
    background-color: black;
    color: #fff;
    text-align: center;
    padding: 5px 0;
    border-radius: 5px;
    left: 105%;
    top: -5px;
  
    /* Position the tooltip text - see examples below! */
    position: absolute;
    z-index: 1;
  }

  /* Show the tooltip text when you mouse over the tooltip container */
  .tooltip:hover .tooltiptext {
    visibility: visible;
  }




/* The container */
.container {
  display: inline;

}






</style>


<body >
  <div >
    <h1><?php echo $jobs_systemname; ?> - Manage User Account</h1>
    This page allows editing of the selected user account.

<?php

  error_reporting(E_ALL); 
  ini_set('display_errors', '1');
  //dumper($_POST);


  if (isset($_POST['users_id'])){
    require_once 'includes/dbh.inc.php';
    $sql = "SELECT users_id
      , users_fullname
      , users_uid
      , users_email
      , users_role
      , users_active
      , users_added
      , users_super
    FROM users 
    WHERE users_id = {$_POST['users_id']}
    ; ";


    $result = mysqli_query($conn, $sql) or die(mysqli_error($conn));
    $num_rows = mysqli_num_rows($result);
    //echo "<p>There were {$num_rows} records returned from the SQL query.</p>";
  
      
    if (mysqli_num_rows($result) > 0) {
      // Output the single result
      $row_user = mysqli_fetch_assoc($result);

      // Get the values for checkboxes - user active
      if ($row_user['users_active'] == 1){
        $my_checkbox_useractive = "checked";
        $my_user_currentstate = "1";
      } else {
        $my_checkbox_useractive = "";
        $my_user_currentstate = "0";
      }
 
       // Get the values for checkboxes - user has read write permission
       if ($row_user['users_role'] == 1){
        $my_checkbox_userrole = "checked";
      } else {
        $my_checkbox_userrole = "";
      }
 
      // Get the values for checkboxes - user has superuser privilige
      if ($row_user['users_super'] == 1){
        $my_checkbox_usersuper = "checked";
      } else {
        $my_checkbox_usersuper = "";
      }
 
 ?> 
      
  
  <form method="POST" >
    <label class="label_1" >
      User ID 
      <input  class="input_1_readonly" type="text" readonly name="users_id" size="4" 
      value="<?php echo $row_user['users_id']; ?>"> 
    </label>

    <label class="label_1">
      User Fullname 
      <input class="input_1_readonly" type="text" readonly name="users_fullname" 
      value="<?php echo $row_user['users_fullname']; ?>">
    </label>

    <label class="label_1">
      User UID 
      <input class="input_1_readonly" type="text" readonly name="users_uid" 
      value="<?php echo $row_user['users_uid']; ?>">
    </label>

    <label class="label_1">
      User Email 
      <input class="input_1_readonly" type="text" size="30" readonly name="users_email" 
      value="<?php echo $row_user['users_email']; ?>">
    </label>

    <br>


    <label style=display:inline >
      <input type="hidden" name="users_active" value="0" />
      <input type="hidden" name="users_currentstate" value=<?php echo $my_user_currentstate;?> >
      <input style=display:inline type="checkbox" name="users_active" value="1" <?php echo $my_checkbox_useractive ; ?> >
      User is Active  
    </label>
    <br>

    <label style=display:inline >
      <input type="hidden" name="users_readwrite" value="0" />
      <input style=display:inline type="checkbox" name="users_readwrite" value="1" <?php echo $my_checkbox_userrole ; ?> >
      User has Update Permission
    </label>
      <br>
    <label style=display:inline >
      <input type="hidden" name="users_super" value="0" />
      <input style=display:inline type="checkbox" name="users_super" value="1" <?php echo $my_checkbox_usersuper ?> >
      User has Superuser Privilige 
    </label>

    <br>
   
    <button class="link_button" type="submit" formaction="user_admin.php"> 
      Cancel
    </button>

    <button class="link_button" type="submit" <?php if ($_SESSION["userrights"] != 1){ echo "disabled" ;}?> formaction="includes/update_existing_user.inc.php"> 
     Update User Permissions
    </button>

  </form>

    

<?php
      } else {
        echo "No results returned from database query.";
      }

} else{
    echo "Something broke passing the users_id to this page.";
}


?>
</div>
<?php include_once 'includes/footer.inc.php'; ?>

</body>

</html>