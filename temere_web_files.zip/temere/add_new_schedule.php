
<?php
  // This is the add new schedule page for the Temere System.  It does the following
  // - validates user input
  // - runs the SQL add function
  
  //  Change History
  //  2023-08-12  Initial build
  
?>

<?php
  error_reporting(E_ALL); 
  //ini_set('display_errors', '1');
  ini_set('display_errors',0);
  session_start();
  include_once 'includes/header.inc.php';
  require_once 'includes/functions.inc.php';
  require_once 'includes/dbh.inc.php';
  
  werl($_SERVER['PHP_SELF'] . "\t----- Page load ------");     // Log message

  # Get the list of devices from the database, ready to use as options in the dropdown below.
  $sql_devicelist = "SELECT
      device_id
    , device_name
    , device_description
    , device_vendor
    , device_controlid
    , device_active
    FROM devices
    WHERE device_active=1
    ;";
    
    $result_devicelist = mysqli_query($conn, $sql_devicelist) or die(mysqli_error($conn));



?>

<link rel="stylesheet" href="css/index_css.css">


  <h1>Add New Schedule </h1>
  Please complete the following details for the new Schedule.


<body>
  <div>



  <form method="POST" >
    

    
<br>



<style>
zzform   { display: table;      }
zzp      { display: table-row;  }
zzlabel  { display: table-cell; }
zzinput  { display: table-cell; }
zzselect { display: table-cell; }
zzcheckbox { display: table-cell; }
zzhidden  { display: table-cell; }

input[type='number']{
    width: 50px;
} 
</style>






  
    <label class="label_1" >
      Select Device <br>
      <select id="devices"   name="device_id">
      <?php 
        # Iterate through the result set and set the option values and option text
        while($row = mysqli_fetch_assoc($result_devicelist)){
          echo "<option value={$row['device_id']}>{$row['device_name']}</option>";
        }
      ?>  
      </select>
    </label>
  

    <label class="label_1">  
      Schedule Type <br>
      <select  name="schedule_type">
      <option value="5">Weekday</option>
      <option value="2">Weekend</option>
      </select>
    </label>

    <label class="label_1">
        Trigger Weighting
        <input type = "number" min="1" max="100" name="trigger_weighting">
    </label>

    <label class="label_1">
        Switch On Time
        <input  type="time" name="turn_on_time" >      
    </label>

    <label class="label_1"> 
        Switch On Flex       
        <input type="number" min="0" max="<?php echo $limit_switchonflex; ?>"  name="turn_on_flex" >
    </label>

    <label class="label_1">  
        Active Duration       
        <input type="number" min="1" max="<?php echo $limit_duration; ?>" name="active_duration" >
    </label>

    <label class="label_1"> 
        Active Duration Flex         
        <input type="number" min="0" max="<?php echo $limit_durationflex; ?>" name="active_duration_flex" >
    </label>

    <label class="label_1">
        Comment   
        <input type="text" size="30" name="comment" >
    </label>

    <label class="label_1"> 
        Activate Shedule 
        <input type="hidden" name="schedule_enable" value="0" >
        <input type="checkbox" name="schedule_enable" value="1" >
    </label>


  <button class="link_button" type="submit" formaction="index.php"> 
    Cancel
  </button>

  <button class="link_button" type="submit" <?php if ($_SESSION["userrights"] != 1){ echo "disabled" ;}?> formaction="includes/add_new_schedule.inc.php"> 
    Submit
  </button>

</form>


</div>  
</body>

  
<?php 
  include_once 'includes/footer.inc.php'; 
?>
  
</html>
