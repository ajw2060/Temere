
<?php

  // This is the actual edit script.  It does the following
  // - allows edit of the selected schedule

  //  Change History
  //  2023-08-10  Initial build
  
?>

<?php
  include 'includes/header.inc.php';
  require_once 'includes/dbh.inc.php';
  require_once 'includes/functions.inc.php';
  werl($_SERVER['PHP_SELF'] . "\t------ Page load ------");
?>

<link rel="stylesheet" href="css/index_css.css">

<?php
  if (isset($_SESSION["useruid"])){
    echo "Welcome " . $_SESSION["userfullname"] ;
  }
  else {
    header("location: login.php");
  }
?>


<style>
  input[type='number']{
    width: 50px;
} 

  #myDIV {
    width: 100%;
    padding-left: 0px;
    text-align: xcenter;
    background-color: xlightblue;
    margin-top: 5px;
  }

  .switch {
    position: relative;
    display: inline-block;
    width: 60px;
    height: 34px;
  }

  .switch input { 
    opacity: 0;
    width: 0;
    height: 0;
  }



  /* Tooltip container */
  .tooltip {
    position: relative;
    display: block;
    border-bottom: 0px dotted black; /* If you want dots under the hoverable text */
  }

  /* Tooltip text */
  .tooltip .tooltiptext {
    visibility: hidden;
    width: 150px;
    background-color: black;
    color: #fff;
    text-align: center;
    padding: 5px 0;
    border-radius: 5px;
    left: 105%;
    top: -5px;
  
    /* Position the tooltip text - see examples below! */
    position: absolute;
    z-index: 1;
  }

  /* Show the tooltip text when you mouse over the tooltip container */
  .tooltip:hover .tooltiptext {
    visibility: visible;
  }


</style>

<body >
  <div >
    <h1><?php echo $jobs_systemname; ?> - Update Schedule Details</h1>
    This page allows the selected schedule to be edited.

<?php

  error_reporting(E_ALL); 
  ini_set('display_errors', '1');
  //var_dump ($_POST);

  if (isset($_POST['schedule_id'])){
    $sql_schedule = "SELECT 
        schedule_id
      , schedule.device_id
      , schedule_enable
      , schedule_type
      , trigger_weighting
      , turn_on_time
      , turn_on_flex
      , active_duration
      , active_duration_flex
      , comment
      , devices.device_name     AS device_name
    FROM schedule
    INNER JOIN devices ON schedule.device_id = devices.device_id
    WHERE schedule_id = {$_POST['schedule_id']}
    ;";

  
    $result = mysqli_query($conn, $sql_schedule) or die(mysqli_error($conn));
    //var_dump($result);
    
    if (mysqli_num_rows($result) > 0) {
      // Output the single result
      $row_schedule = mysqli_fetch_assoc($result);
  ?> 
      
  <?php
    // Modify the required fields before display
    $my_turn_on_time = date_create($row_schedule['turn_on_time'])->format('H:i');
    if ($row_schedule['schedule_enable'] == 1 ){
      $my_checkbox_enable_state = "checked";
    } else {
      $my_checkbox_enable_state = "unchecked";
    }
    
    
  
  ?>

  
  <form method="POST" >
    <label class="label_1" >
      Schedule ID 
      <input  class="input_1_readonly" type="text" readonly size="4" name="schedule_id"
      value="<?php echo $row_schedule['schedule_id']; ?>"> 
    </label>

    <label class="label_1">
      Device Name 
      <input class="input_1_readonly" type="text" readonly size="20"
      value="<?php echo $row_schedule['device_name']; ?>">
    </label>

    <label class="label_1">
      Schedule Type       
      <input class="input_1" type="text" name="schedule_type" 
      value="<?php echo $row_schedule['schedule_type']; ?>">
    </label>

    <label class="label_1">
      Trigger Weighting       
      <input type = "number" min="1" max="100" name="trigger_weighting"
      value="<?php echo $row_schedule['trigger_weighting']; ?>">
    </label>

    <label class="label_1">
      Switch On Time 
      <input type="time" name="turn_on_time" 
      value="<?php echo $my_turn_on_time ; ?>" />      
    </label>

    <label class="label_1">
      Switch On Flex       
      <input type="number" min="0" max="<?php echo $limit_switchonflex; ?>"  name="turn_on_flex" 
      value="<?php echo $row_schedule['turn_on_flex']; ?>">
    </label>

    <label class="label_1">
      Active Duration       
      <input type="number" min="1" max="<?php echo $limit_duration; ?>" name="active_duration" 
      value="<?php echo $row_schedule['active_duration']; ?>">
    </label>

    <label class="label_1">
      Active Duration Flex       
      <input type="number" min="0" max="<?php echo $limit_durationflex; ?>" name="active_duration_flex" 
      value="<?php echo $row_schedule['active_duration_flex']; ?>">
    </label>

    <label class="label_1">
      Comment       
      <input type="text" size="30" name="comment" 
      value="<?php echo $row_schedule['comment']; ?>">
    </label>

    <span > 
    <label class="label_1">
      Activate Shedule
      <input type='hidden' name='schedule_enable' value='0' />
      <input type="checkbox" name="schedule_enable"  value="1"
        <?php echo $my_checkbox_enable_state ?>>
      
    </label>
    </span> 
    <br>

    <button class="link_button" type="submit" formaction="index.php"> 
      Cancel
    </button>

    <button class="link_button" type="submit" <?php if ($_SESSION["userrights"] != 1){ echo "disabled" ;}?> formaction="includes/update_existing_schedule.inc.php"> 
      Update This Schedule
    </button>

    <button class="link_button" type="submit" <?php if ($_SESSION["userrights"] != 1){ echo "disabled" ;}?> formaction="includes/delete_existing_schedule.inc.php"> 
      Delete This Schedule
    </button>

    

  


<?php
      } else {
        echo "No results returned from database query.";
      }

} else{
    echo "Something broke passing the schedule_id to this page.";
}


?>
</div>
<?php include_once 'includes/footer.inc.php'; ?>

</body>



</html>