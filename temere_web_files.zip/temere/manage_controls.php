

<?php
  // This is the page to manage all controls.
  // It does the following
  // - allows edit, addition or deletion of controls
  
  //  Change History
  //  2023-08-31 Initial build
  
  
  
?>


<?php
  error_reporting(E_ALL); 
  ini_set('display_errors', '1');
  include_once 'includes/header.inc.php';
  require_once 'includes/functions.inc.php';
  require_once 'includes/dbh.inc.php';
  werl($_SERVER['PHP_SELF'] . "\t------ Page load ------");
?>





<link rel="stylesheet" href="css/index_css.css">

<?php
//var_dump($_SESSION);
  // This bit is magic - it ensures users cannot get to the page without being logged in.
  if (isset($_SESSION["useruid"])){
    //echo "here";
    echo "<p style='color:purple; text-align:left'> Welcome {$_SESSION['userfullname']} </p>";
  }
  else {
    //echo "xxx";
    header("location: login.php");
    exit();
  }
  //var_dump($_SESSION);
  ?>

<?php     // Handle all the conditions returned via the URL from some referring page
  if(isset($_GET["code"])){
    switch($_GET["code"]){
      case "0":
        echo"<p class='goodnews'> Success. <br> {$_GET["msg"]} <p>";
        break;

      case "3":
        echo"<p class='goodnews'> Test complete. <br> {$_GET["msg"]} <p>";
        break;

      case "10":
        echo"<p class='goodnews'> Success. <br> {$_GET["msg"]} <p>";
        break;
        

      case "11":
        echo"<p class='errorbox'> ERROR {$_GET["code"]}. <br>Update failed. <br> {$_GET["msg"]} <p>";
        break;
    }
  }
?>



  <body>

      <div class="container">
      <h1><?php echo $jobs_systemname; ?> - Manage Controls </h1>
        This page allows Add Change Delete of Controls. 


      <form  method='POST'>
        <button class="link_button" type='submit' formaction='add_new_control.php' <?php if ($_SESSION["userrights"] != 1){ echo "disabled" ;}?> name='add_control'> 
          Add New Control
        </button>
        <br><br>
      </form>





      <?php
        $sql = "SELECT control_id
          , controls.device_id
          , controls.device_guid
          , controls.control_name
          , controls.control_description
          , controls.control_script
          , controls.control_active
          , devices.device_name
        FROM controls 
        LEFT JOIN devices ON controls.device_id = devices.device_id
        ORDER BY control_name ASC; ";

        $result = mysqli_query($conn, $sql) or die(mysqli_error($conn));
        $num_rows = mysqli_num_rows($result);
        echo "<p>There were {$num_rows} records returned from the SQL query.</p>";

      ?>
  <br>Controls are sorted by Control Name.

      <br>
      
      <table class="box-1" width="98%" style="text-align:left" >
      <caption>List of all controls</caption>
        <tr >
          <th> Control ID                   </th>  
          <th> Control Name         </th>  
          <th> Control Description  </th>  
          <th> Supports Device      </th>  
          <th> Device GUID          </th>  
          <th> Script               </th>  
          <th> Control State        </th>
        </tr>

        <?php
          while($row = mysqli_fetch_assoc($result)){
            # Build the test for the Active column
            if ($row['control_active'] == 1) {
              $state_text = "Active";
            } else {
              $state_text = "Inactive";
            }
              

        ?>
          <tr>
            <td width=auto  class="table-cell-1">
              <form method="POST">  
                <button class="link_button-1" type='submit' name='control_id' formaction="update_existing_control.php" value = <?php echo $row['control_id'];?>>  
                  <?php echo $row['control_id']; ?>
                </button>
              </form>
            </td>
           
            <td class="table-cell-1" > <?php echo $row["control_name"]; ?>         </td>
            <td class="table-cell-1" > <?php echo $row["control_description"]; ?>  </td>
            <td class="table-cell-1" >     
            
              <form method="POST">  
                <button class="link_button-1" type='submit' name='device_id' formaction="update_existing_device.php" value = <?php echo $row['device_id'];?>>  
                <?php echo $row['device_id']; ?>
                
              
                </button>
                <?php echo "<br>" . $row["device_name"] ;  ?>   
              </form>

            
            
            </td>
            <td class="table-cell-1" > <?php echo $row["device_guid"];  ?>   </td>
            <td class="table-cell-1" > <?php echo $row["control_script"];  ?>   </td>
            <td class="table-cell-1" > <?php echo $state_text;  ?>               </td>

          </tr>
        <?php 
          }
        ?>
      </table>
      <br>



  <form method="POST">
    <button class="link_button"   type="submit" formaction= "index.php" > 
    Home
    </button>

    
  </form>
  </div>  
</body>
  <?php include_once 'includes/footer.inc.php'; ?>
</html>


<style>
  tr:nth-of-type(even) {
  background-color:#ccc;
}


.goodnews{
  color:green;
  font-size: 1.5em;
  }

</style>
