

<?php
    // This is a common variables file, used typically to tweak global system configuration.

    $jobs_systemname = "Temere Scheduler";

    $limit_switchonflex = 60;               // Maximum value of turn on flex
    $limit_duration = 10 * 60;        // Maximum on duration 
    $limit_durationflex = 60;         // Maximum value of duration flex

    
    


?>