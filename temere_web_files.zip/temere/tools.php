
<?php
    // This is the diagnostics page.
    // It is really just a launcher to other reporting type pages.
  
    // Change History
    // 2023-08-19   Initial build
  
  
?>

<?php
  error_reporting(E_ALL); 
  ini_set('display_errors', '1');
  //ini_set('display_errors',0);

  include_once 'includes/header.inc.php';
  require_once 'includes/functions.inc.php';
  require_once 'includes/dbh.inc.php';
  
  werl($_SERVER['PHP_SELF'] . "\t------ Page load ------");     // Log message
?>









<?php
  // This bit is magic - it ensures users cannot get to the home page without logging in!
  if (isset($_SESSION["useruid"])){
    //echo "here";
    echo "<p style='color:purple; text-align:left'>Welcome " . $_SESSION["userfullname"] .  "</p>";
  }
  else {
    //echo "xxx";
    header("location:  login.php");
    exit();
  }
  //var_dump($_POST);



  ?>





  <body>
  

    <h1><?php echo $jobs_systemname; ?> - Tools</h1>
    


    <h3> Click on the following links to view the desired report </h3>

    <br>
    <ul>
      <li><a href="view_sequence.php">View Raw Sequence</a> </li>
      <li><a href="view_cycles.php">View Cycles</a> </li>
    </ul>

    <br><br>

    <h3> Click on the following links to access the desired tool </h3>

    <br>
    <ul>
      <li><a href="includes/rebuild_sequence.inc.php">Rebuild the Sequence</a> </li>
      <li><a href="manage_devices.php">Manage Devices</a> </li>
      <li><a href="manage_controls.php">Manage Controls</a> </li>
    
    </ul>



    <br>


    Click here for the <a href="doc1.php">System Documentation</a>.

    <br><br>

  </body>
  <?php include_once 'includes/footer.inc.php'; ?>
  
</html>

