

<?php
  error_reporting(E_ALL); 
  ini_set('display_errors', '1');
  ini_set('display_errors',0);

  include_once 'includes/header.inc.php';
  require_once 'includes/functions.inc.php';
  require_once 'includes/dbh.inc.php';
  
  werl($_SERVER['PHP_SELF'] . "\t------ Page load ------");     // Log message
?>


<style>
.boxed {
  border: 1px solid green;
  padding-left:20px;
  margin-left: 20px;
  padding-top: 20px;
  padding-bottom: 30px;
  width: 0300px;
} 


</style>

<link rel="stylesheet" href="css/index_css.css">

<section class="css/signup-form">

  <h1><?php echo $jobs_systemname; ?> - User Registration</h1>
    <div class="boxed">
    <form action="includes/register.inc.php" method="post">

    <p style="text-align:left; font-size:1.2em; color:brown">Please use the following form to register.</p> <br>
      <input type="text" name="name" placeholder="Enter full name ...">
      <input type="text" name="username" placeholder="Enter username ...">
      <input type="text" name="email" placeholder="Enter email ...">
      <input type="password" name="pwd" placeholder="Enter password ...">
      <input type="password" name="pwd_repeat" placeholder="Enter password again ...">
      <button class="link_button" type="submit" name="submit">Register</button>
    </form>
    </div>

    <?php
    // Handle all the error conditions returned via the URL 
    if(isset($_GET["error"])){
      switch($_GET["error"]){
        case "emptyinput":
          echo"<p style='color:red; font-size:1.5em; line-height:150%'> Please complete all the required fields on your registration form. <p>";
          break;
        case "invaliduid":
          echo"<p style='color:red; font-size:1.5em; line-height:150%'> Please choose a proper username. <p>";
          break;
        case "invalidemail":
          echo"<p style='color:red; font-size:1.5em; line-height:150%'> Please enter a proper email address. <p>";
          break;
        case "passwordmismatch":
          echo"<p style='color:red; font-size:1.5em; line-height:150%'> The provided passwords did not match - please try again. <p>";
          break;
        case "stmtfailed":
          echo"<p style='color:red; font-size:1.5em; line-height:150%'> Something bad happened during the database access. Please contact the administrator.<p>";
          break;
        case "usernametaken":
          echo"<p style='color:red; font-size:1.5em; line-height:150%'> That username (or email) has already been used.  Please choose something unique.<p>";
          break;
        case "none":
          echo"<p style='color:green; font-size:1.5em; line-height:150%'> <br>Thank you for registering. <br>Your registration has completed successfully. <br>Your account must now be activated by the Administrator.<br>
          You will receive an email once this is completed.<p>";
          break;
      }
    }
    ?>
</section>

  
<?php 
  include_once 'includes/footer.inc.php'; 
?>
  
</html>
