<?php 
  session_start();
  include 'includes/header.inc.php'; 
  require_once 'includes/functions.inc.php';
  werl($_SERVER['PHP_SELF'] . "\tAbout ------ Page load ------");     // Log message



?>


<link rel="stylesheet" href="css/documentation_css.css">
  
  <?php
  // This bit is magic - it ensures users cannot get to the home page without logging in!
  if (isset($_SESSION["useruid"])){
    //echo "here";
    //echo "UserUID " . $_SESSION["useruid"];

    echo "<p style='color:purple; text-align:left'>Welcome " . $_SESSION["userfullname"] .  "</p>";
  }
  else {
    //echo "xxx";
    header("location:  login.php");
    exit();
  }
  //var_dump($_POST);
?>




  <h1><?php echo $jobs_systemname; ?> - About </h1>

    <h3>This is the Temere Random Event Scheduler System.  </h3>
    <br>


<p>    The Temere system may be used to set up switch-on and switch-off schedules for smart devices such as lights and power sockets. 
It supports different schedules for weekdays and weekends, with multiple switch-on and switch-off windows configurable for each device.
</p>
<p>

Rather than smart devices simply switching on and off at the same time every day, an element of randomness can be introduced so the switch-on 
time and the switch-off time will vary every day.  A weighting can also be configured so a device will likely not operate every day.  
Set a low weighting and a device may just come on once or twice a week or even just once a month.
Set a high weighting and the device will operate every day.
This is intended to make your house look more 'lived in' by varying which lights or lamps come on each day, thus deterring potential intruders. 
</p>
<p>

Temere is designed to be a control centre for devices.  It does not directly control a device; rather it leverages the existing cloud control API to turn devices on or off.  
As long as the controlled device has an API, the user can develop their own control script which gets called by Temere to control the device.
</p>

<br>





    <?php include 'includes/footer.inc.php'; ?>