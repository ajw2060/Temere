

<?php
  // This is the index page for the Temere System.  It does the following
  // - displays a list of all Schedules with the option to edit selected schedule.
  
  // Change History
  // 2023-08-05 Initial build - copied mostly from jobs
  
  
?>

<?php
  error_reporting(E_ALL); 
  ini_set('display_errors', '1');
  //ini_set('display_errors',0);

  include_once 'includes/header.inc.php';
  require_once 'includes/functions.inc.php';
  require_once 'includes/dbh.inc.php';
  
  werl($_SERVER['PHP_SELF'] . "\t------ Page load ------");     // Log message
?>





<link rel="stylesheet" href="css/index_css.css">

<?php
  // This bit is magic - it ensures users cannot get to the home page without logging in!
  if (isset($_SESSION["useruid"])){
    //echo "here";
    echo "<p style='color:purple; text-align:left'> Welcome {$_SESSION['userfullname']} </p>";
  }
  else {
    //echo "xxx";
    header("location:  login.php");
    exit();
  }
  ?>

<?php     // Handle all the conditions returned via the URL from some referring page
  if(isset($_GET["code"])){
    switch($_GET["code"]){
      case "0":
        echo"<p class='goodnews'> Success. <br> {$_GET["msg"]} <p>";
        break;

      case "1":
        echo"<p class='goodnews'> Success. <br> {$_GET["msg"]} <p>";
        break;
  
      case "2":
        echo"<p class='goodnews'> Success. <br> {$_GET["msg"]} <p>";
        break;
      

      case "31":
        echo"<p class='errorbox'> ERROR {$_GET["code"]}. <br>Schedule not created. <br> {$_GET["msg"]} <p>";
        break;

      case "41":
        echo"<p class='errorbox'> ERROR {$_GET["code"]}. <br>Timing overlap detected with existing Schedule. <br> {$_GET["msg"]} <p>";
        break;
  
      case "42":
        echo"<p class='errorbox'> ERROR {$_GET["code"]}. <br>Schedule will remain Denied until overlap is resolved. <br> {$_GET["msg"]} <p>";
        break;
  

    }
  }
?>




  <body>
  
    <div class="xxcontainer">
    <h1><?php echo $jobs_systemname; ?> - Schedules</h1>
      This page shows the list of all Schedules. 

      <form  method='POST'>
        <button class="link_button" type='submit' formaction='add_new_schedule.php' <?php if ($_SESSION["userrights"] != 1){ echo "disabled" ;}?> name='add_schedule'> 
          Add New Schedule
        </button>
        <br><br>
      </form>


      <?php
        // Quickly run through all the Schedule records to check if any of them are dirty.
        // If at least one record is dirty, then display the message recommending a 
        // Sequence rebuild.
        $sql_dirtycheck = "SELECT 
        schedule_id
        , is_dirty                AS is_dirty
        FROM schedule
        WHERE schedule_enable = 1
        ;";
  
        $result_dirtycheck = mysqli_query($conn, $sql_dirtycheck) or die(mysqli_error($conn));
        $dirty_counter = 0;
        while($row_dirtycheck = mysqli_fetch_assoc($result_dirtycheck)){
          if ($row_dirtycheck['is_dirty'] == 1){
            $dirty_counter += 1;
          }
        }
      ?>


      <?php
      $sql_schedules = "SELECT 
            schedule_id
          , schedule.device_id
          , schedule_enable
          , schedule_type
          , trigger_weighting
          , turn_on_time
          , turn_on_flex
          , active_duration
          , active_duration_flex
          , comment
          , is_dirty                AS is_dirty
          , devices.device_name     AS device_name
          , devices.device_active
      FROM schedule
      INNER JOIN devices ON schedule.device_id = devices.device_id
      WHERE device_active = 1
      ORDER BY device_name, schedule_type DESC, schedule_id
      ;";
      

      $result_schedule = mysqli_query($conn, $sql_schedules) or die(mysqli_error($conn));
      $num_rows = mysqli_num_rows($result_schedule);
      if ($num_rows == 0){
        echo "<p>There are no schedules currently available.</p>";  
      } elseif ($num_rows ==1){
        echo "<p>There is {$num_rows} schedule available.</p>";  
      } else {
        echo "<p>There are {$num_rows} schedules available.</p>";
        echo "<br> Schedules are sorted by <strong>Device Name</strong> with Weekday schedules shown before Weekend schedules.";
      }
    ?>
      
      
    <?php
      if ($dirty_counter > 0){
        echo"<br><br>The Schedule has been updated since the last Sequence Rebuild.  Click to <a href='includes/rebuild_sequence.inc.php'>Rebuild the Sequence</a>.  This is recommended. ";
      }
    ?>
      
      
      
      <?php
        while($row_schedule = mysqli_fetch_assoc($result_schedule)){
          // Modify some of the dispalyed fields
          // Put a name to the schedule type
          if ($row_schedule['schedule_type'] ==2 ){
            $schedule_type_name = "Weekend";
          } elseif ($row_schedule['schedule_type'] ==5 ){
            $schedule_type_name = "Weekday";
          } else { 
            $schedule_type_name = "undefined (probably an error)";
          }

          // Prepare the text for the Status field.  This shows Active, Inactive or Declined.
          // If the value is Declined, then show the ID of the conflicting Schedule.
          if ($row_schedule['schedule_enable'] == 0 ){
            $schedule_enable_name = "Inactive";
          } elseif ($row_schedule['schedule_enable'] == 1 ){
            $schedule_enable_name = "Active";
          } elseif ($row_schedule['schedule_enable'] == 2 ){
            $schedule_enable_name = "<span  style='color:red';> Denied </span>" ;
          } else { 
            $schedule_enable_name = "undefined";
          }

          // Prpare the 'is_dirty' message
          if ($row_schedule['is_dirty'] == 1){
            $isdirty_message = "Updated";
          } 
          else {
            $isdirty_message = "";
          }



      ?>
      <table width="100%" class = "row-1">
        <tr >
          <td colspan=2 rowspan=4  width=30% class="table-cell-1">
            <form method="POST">  
              <button class="link_button-1" type='submit' name='schedule_id' formaction="update_existing_schedule.php" value = <?php echo $row_schedule['schedule_id'];?>>  
                <?php echo $row_schedule['device_name']; ?>
                
              </button>
            </form>
          <td colspan=2 width=35% class="table-cell-1">
          <span class="small">Schedule Type </span>  
            <?php echo $schedule_type_name; ?>
          </td>

          <td colspan=2 width=35% class="table-cell-1">
            <span class="small">Trigger Weighting </span> 
            <?php echo $row_schedule['trigger_weighting']; ?>
          </td>
        </tr>
        
        <tr>
          <td colspan=2 class="table-cell-1"> 
            <span class="small">Switch On Time </span> 
            <?php echo date_create($row_schedule['turn_on_time'])->format('H:i'); ?> 
          </td>
          
          <td colspan=2 class="table-cell-1"> 
            <span class="small">Duration </span> 
            <?php echo $row_schedule['active_duration']; ?>
          </td>
        </tr>  

        <tr>
          <td colspan=2 class="table-cell-1"> 
            <span class="small">Switch On Flex </span> 
            <?php echo $row_schedule['turn_on_flex']; ?> 
          </td>
          
          <td colspan=2 class="table-cell-1"> 
            <span class="small">Duration Flex </span>
            <?php echo $row_schedule['active_duration_flex']; ?>
          </td>
        </tr>

        <tr>
          <td colspan=2 class="table-cell-1">
            <span class="small">Schedule ID </span>
            <?php echo $row_schedule['schedule_id']; ?>
          </td>

          <td colspan=2 class="table-cell-1">
            <span class="small">Status </span>
            <?php echo $schedule_enable_name; ?>
          </td>
        </tr>
 
        <tr>
          <td colspan=5 width=90% class="table-cell-1B">  <?php echo $row_schedule['comment']; ?> </td>
          <td colspan=1 width=10% class="table-cell-1B">  <?php echo $isdirty_message; ?> </td>
          
        </tr>

        
        <?php
        }
        ?>

      </table>

</div>
  </body>
  <?php include_once 'includes/footer.inc.php'; ?>
  
</html>

