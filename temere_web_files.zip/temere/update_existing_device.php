
<?php

  // This is the page to update an exiting device.  It does the following
  // - allows edit of the selected device

  //  Change History
  //  2023-08-26  Initial build
  
?>

<?php
  include 'includes/header.inc.php';
  require_once 'includes/dbh.inc.php';
  require_once 'includes/functions.inc.php';
  werl($_SERVER['PHP_SELF'] . "\t------ Page load ------");
?>



<link rel="stylesheet" href="css/index_css.css">

<?php
  if (isset($_SESSION["useruid"])){
    echo "Welcome " . $_SESSION["userfullname"] ;
  }
  else {
    header("location: login.php");
  }
?>


<?php
  // Get the name of the referring page in case we want to return there
  $my_referrer = basename($_SERVER['HTTP_REFERER']);
?>


<body >
  <div >
    <h1><?php echo $jobs_systemname; ?> - Update Device Details</h1>
    This page allows the selected device to be edited.
    <br><br>



<?php
  error_reporting(E_ALL); 
  ini_set('display_errors', '1');
  //var_dump ($_POST);

  if (isset($_POST['device_id'])){
    $sql_device = "SELECT 
        device_id
      , device_name
      , device_description
      , device_vendor
      , device_controlid
      , device_active
    FROM devices
    WHERE device_id = {$_POST['device_id']}
    ;";

  
    $result = mysqli_query($conn, $sql_device) or die(mysqli_error($conn));
    //var_dump($result);
    
    if (mysqli_num_rows($result) > 0) {
      // Output the single result
      $row_device = mysqli_fetch_assoc($result);





  // Get the list of Controls already built for this device.  
  // This is used to use as options in the dropdown below.
  $sql_devicecontrollist = "SELECT
      control_id
    , control_name
    , control_description
    , device_id
    , device_guid
    , control_script
    , control_active
    FROM controls
    WHERE device_id = {$_POST['device_id']} 
    AND control_active = 1
    ;";
    
    $result_devicecontrollist = mysqli_query($conn, $sql_devicecontrollist) or die(mysqli_error($conn));
    $num_rows = mysqli_num_rows($result_devicecontrollist);
    werl($_SERVER['PHP_SELF'] . "\tFound [{$num_rows}] defined Control Options for Device ID [{$_POST['device_id']}]");


  ?> 
      
  <?php
    // Modify the required fields before display
    if ($row_device['device_active'] == 1 ){
      $my_checkbox_enable_state = "checked";
    } else {
      $my_checkbox_enable_state = "unchecked";
    }

    
  
  ?>

  
  <form method="POST" >
    <label class="label_1" >
      Device ID 
      <input  class="input_1_readonly" type="text" readonly size="4" name="device_id"
      value="<?php echo $row_device['device_id']; ?>"> 
    </label>

    <label class="label_1">
      Device Name 
      <input class="input_1" type="text" size="20" name="device_name"
      value="<?php echo $row_device['device_name']; ?>">
    </label>

    <label class="label_1">
      Device Description       
      <input class="input_1" type="text" name="device_description" size="50"
      value="<?php echo $row_device['device_description']; ?>">
    </label>

    <label class="label_1">
      Device Vendor      
      <input class="input_1" type="text" name="device_vendor" 
      value="<?php echo $row_device['device_vendor']; ?>">
    </label>

    

    <p>
    <label for="controls" class="label_1" xxstyle="display: inline; width: 10em;">Select Control Method (from the available [<?php echo $num_rows ?>])</label>
    <select id="controls" xxstyle="margin-top:5px; color:blue"  name="device_controlid">
      <?php 
      
        # Iterate through the result set and set the option values and option text
        $my_default="";
        werl($_SERVER['PHP_SELF'] . "\tCurrently selected Control Method is [{$row_device['device_controlid']}]");
        while($row_dcl = mysqli_fetch_assoc($result_devicecontrollist)){
          # While iterating here, check each option to see if it is the currently selected Control Method, and if so flag it as the default.
          werl($_SERVER['PHP_SELF'] . "\tFound ID [{$row_dcl['control_id']}]");
          if ($row_dcl['control_id'] == $row_device['device_controlid']){
            $my_default = 'selected';
          } else {
            $my_default = "";
          }
          # Assign a more friendly variable to the 'value' so it is easier to use lwter when updating the SQL
          $my_selectedcontrolmethod = $row_dcl['control_id'];
          echo "<option {$my_default} value={$my_selectedcontrolmethod}> Option {$row_dcl['control_id']}. {$row_dcl['control_name']} ({$row_dcl['control_description']}) </option>";
        }
      ?>  
    </select>
    </P>







    <span > 
    <label class="label_1">
      <input type='hidden' name='device_enable' value='0' />
      <input style="display:inline; margin-top:5px"  type="checkbox" name="device_enable"  value="1"
        <?php echo $my_checkbox_enable_state ?>>
      Enable this Device
    </label>
    </span> 
    <br>

    <button class="link_button" type="submit" formaction=<?php echo $my_referrer; ?>> 
      Cancel
    </button>

    <button class="link_button" type="submit" formaction="index.php"> 
      Home
    </button>

    <button class="link_button" type="submit" <?php if ($_SESSION["userrights"] != 1){ echo "disabled" ;}?> formaction="includes/update_existing_device.inc.php"> 
      Update Device
    </button>

    <button class="link_button" type="submit" <?php if ($_SESSION["userrights"] != 1){ echo "disabled" ;}?> formaction="includes/delete_existing_device.inc.php"   onclick="return confirm('This action will delete the Device and all associated Controls.  Please confirm')"   > 
      Delete This Device
    </button>

    

  


<?php
      } else {
        echo "No results returned from database query.";
      }

} else{
    echo "Something broke passing the device_id to this page.";
}


?>
</div>
<?php include_once 'includes/footer.inc.php'; ?>

</body>



</html>