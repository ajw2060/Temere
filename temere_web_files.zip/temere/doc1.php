<!DOCTYPE html>
<html lang="en">
<head>
	
</head>



<?php
  error_reporting(E_ALL); 
  ini_set('display_errors', '1');
  //ini_set('display_errors',0);

  include_once './includes/header.inc.php';
  require_once './includes/functions.inc.php';
 
  
  werl($_SERVER['PHP_SELF'] . "\t------ Page load ------");     // Log message
?>
<link rel="stylesheet" href="./css/documentation.css">

<body>
	<div class="main-body">
		<nav id="navbar">
			<header>   Temere Documentation  </header>
			<a href="#introduction" class="nav-link">
				Introduction
            </a>

            <a href="#elements" class="nav-link">
				Elements of Temere
            </a>
			
            <a href="#howitworks" class="nav-link">
				How Temere Works
            </a>
			
            <a href="#setup" class="nav-link">
				Setup and Operation
            </a>
                
            <a href="#creatingadevice" class="nav-link">
                Creating a New Device
            </a>
                
            <a href="#creatingaschedule" class="nav-link">
                Creating a New Schedule
            </a>
                
            <a href="#creatingacontrol" class="nav-link">
                Creating a New Control
            </a>

            <a href="#toolsmenu" class="nav-link">
                The Tools Menu
            </a>
        
	
		</nav>

		<main id="main-doc">
			<section class="main-section" id="introduction">
				<header>
					Introduction 
				</header>
				<p>
                    Temere is a scheduling tool designed to interface with smart home devices to turn them on and off at 
                    seleted times of the day.  Unlike other scheduling tools, Temere introduces some randomness into the 
                    turn on and turn off actions.  
                    Tools such as Home Assistant, the Tuya platform, LIFX and the like all offer schedules where we can control 
                    smart lights and smart sockets right down to the minute.  
                    
                </p>
                
                <p>
                    Such home automation may be a simple convenience 
                    to have the lights on when we arrive home in the evening, or it may be designed to make the house appear 
                    occupied to deter potential intruders.  While these scheduling tools can control events down to the minute, 
                    sometimes we want a more random sequence with lights turning on and off at slightly different times of the 
                    day or possibly not even operating on some days.  Existing scheduling tools may not offer this degree of 
                    randomisation and this desire for randomisation became the inspiration for Temere. 

                </p>
				
			</section>

			<section class="main-section" id="elements">
				<header>  Elements of Temere  </header>
				<p>
					Temere is made up of a number of software components including the following:
                <ul>

                    <li>
                        A MySQL database containing tables which define controlled devices and their schedules.
                    </li> 

                    <li>
                        A web front end which provides the user interface to Temere.
                    </li>

                    <li>
                        A python script (called the Planner) which process the data in the Schedule table to generate the Sequence.
                    </li>

                    <li>
                        A python script (called the Conductor) which reads from the Sequence to control all the turning on and turning off for devices.
                    </li>

                    <li>
                        Specific python scripts which are called by the Conductor to connect to Home Assistant or the Cloud provider and actually send the “switch on” or “switch off” commands to the desired device.
                    </li>
                    
                    <li>
                        Home Assistant is not necessary, but if it exists, it simplifies the scripting needed to control
                        devices.
                    </li>

                </ul>
                    </p>                    
                    </p>
                        Temere may be run locally or as a hosted cloud service.  
                        The latter is suggested if Home Assistant uses an hosted MQTT broker as this simplifies the 
                        communications between Temere and the MQTT broker.
                        
                        
                    The following diagram shows the relationship between the various components.
                    
                 
              


                    
			</section>

			<section class="main-section" id="howitworks">
				<header>
					How Temere Works
				</header>
				<p>
                   
                    The real essence of Temere is the randomisation element introduced within the system.  
                    This randomisation is configured in the Schedule, which is the main user interface page. 
                    This home page for the scheduler is shown below.
                </p>

                <img src="temere home page.png" alt="Screenshot of Index page" class="image-1">


                
                <p>
                    

                    Two different Schedules are available: one for weekdays and one for weekends.  
                    Randomisation is introduced in the following three places.
                   
                    The Trigger Weighting controls how many days within the week or within the weekend, the device will be controlled.  This is set as a percentage from zero to 100.  The higher the setting, the more likely a device will be controlled on a particular day.  The actual day of the week or day of the weekend cannot be specified, however setting a Trigger Weighting of 60 on a weekday schedule means the device will be controlled about three days out of five.  As with any randomness, this will vary, but over the full month it is likely to average out.  Setting a Trigger Weighting of 100 means the device will be controlled every day of the week or weekend.  In the example below, the Hall Light is scheduled at 50% which means it will come on two or three days in the week.
                    
                    The Switch On Flex is configured in minutes.  It defines the random delay added to the configured Switch On Time.  In the example below, the Hall Light Switch On Time is set for 18:00 and the Switch On Flex is set to 30 minutes.  Therefore the actual switch on time will be somewhere between 6PM and 6:30PM.  This random delay will vary each day.
                    
                    The Duration Flex is also configured in minutes.  It defines the random amount of time added to the Duration (which is also configured in minutes).  In the example below, the Hall Light is configured with a duration of 240 minutes, with a Duration Flex of 60 minutes, so once this light switches on, it will remain on for somewhere between four and five hours.
                    Multiple Schedules can be prepared for the same device, but an overlapping schedule cannot be set to active until the conflict is resolved.

                    
                    Once the Schedule is setup, the Planner script is run.  
                    This can be run manually but is automatically run each month when the month is detected as changed.  
                    The Planner does the following:
<ul>                   
                    <li>
                    It reads each Schedule record and generates the corresponding Sequence records for each device.  
                    </li>
                    
                    <li>
                        The Sequence is prepared for the current month.  It will contain all the turn on and turn off events for every device for the complete month.  The randomisation discussed above is introduced in this process.  This results in a detailed Sequence with the very specific turn on and turn off times defined to the minute.
                    </li>
                    
                    <li>
                        Once the Sequence is generated, the exact timing for every device is known.  Events are always created in pairs, with a turn off event matching every turn on event.  These two events are associated in the database by a Cycle ID so the matching event pairs can easily be tracked.
                    </li>
                    

                    The following image shows a partial dump of the Sequence table based on Schedule ID 101 from the above Hall Light example.
                    
                    This shows the result of the various pieces of controlled randomness.  Note the following in this Sequence.
                    <li>
                        Events for all days prior to the current date are purged from the table as soon as they are created so they are not shown here.
                    </li>
                    
                    <li>                    
                        The Trigger Weighting of 50 has created eight cycles, which is close enough to 50% of the weekdays between 10 September and 30 September. 
                    </li>
                    
                    <li>
                        The turn on time varies between 18:06 and 18:30, as dictated by the turn on flex value of 30.
                    </li>
                    
                    <li>
                        The turn off time varies from 22:29 to 23:10, as dictated by the duration plus the duration flex.  
                    </li>
                    
                    <li>
                        A batch number is assigned every time the Sequence gets rebuilt.  This is used to identify any Cycles held over from the previous Sequence.  A Cycle will be held over during any Sequence rebuild, rather than purged, if the Cycle is in progress.  This avoids the possibility of leaving a light turned on because the turn on event has triggered, but the corresponding turn off event gets deleted during a Sequence rebuild.
                    </li>
                    
                    <li>
                        As the Conductor processes due events, it will update the Sequence to show the actual time of the event.  As the Conductor is launched by cron, we may choose to run the Conductor on a more granular timing.  If cron runs the Conductor every five minutes, then some short duration Cycles may be turned on and turned off in the same Conductor session.  While this is not an issue, such a setup can introduce extra delay (up to four minutes) between the Sequence On or Off time and the Actual On or Off time.  This can be avoided by running the Conductor via cron every one minute.
                    </li>
</ul>                
                    
                    The database also holds the Devices table and the Controls table.  These two tables define the controlled devices and how each device is controlled.  These aspects of the overall configuration have been separated because each device may have several means of control.  For example, the Hall Light in the above Schedule is a Grid Connect device which is configured in the Tuya Cloud as well as in Home Assistant.  It can be controlled by both systems.  By defining two separate “Controls” for the same device, we can easily select an alternate control for a device.  The Control defines what control script gets called by the Conductor and what parameters get passed to this control script.  For example the Hall Light can be controlled by Home Assistant by publishing a MQTT message containing the topic and the payload, whereas the same light can be controlled via the Tuya API by sending a device ID and the desired state.  The configuration to define which control method to use is set in the Devices table.  Several iterations of this design were tested, and while this approach is a little more complicated it offers the best flexibility.

                        
                    </p>
           
			</section>

			<section class="main-section" id="setup">
				<header>
					Setup and Operation
				</header>
				<p>
					more blah
				</p>
			</section>

			<section class="main-section" id="creatingadevice">
				<header>
					Creating a New Device
				</header>
                  
                
				<p>
                    Devices include smart lights, smart sockets and other smart devices which need to be turned on and off by Temere.
                    Craeting a device requires two stages, due to the interrelationship between Devices and Controls.  A Device is created as follows.

                    Click the "Add New Device".  This brings up a form where a subset of the device properties may be entered.  
                    Properties such as the Control cannot be selected at this stage as the Control does not yet exist.
                </p>

			</section>	


			<section class="main-section" id="creatingaschedule">
				<header>
					Creating a New Schedule
				</header>
                  
                
				<p>
                    Once a Deices is fully defined and set as Active, it may be scheduled.
                    
                </p>

			</section>	



			<section class="main-section" id="creatingacontrol">
				<header>
					Creating a New Control
				</header>
				<p>
				
                
                    A 'Control' is the entity which actually contains all the detail needed to actually control a device 
                    such as a smart light or smart socket.  
                    Each Device must have at least one Control defined for it, but it may have multiple Controls.  
                    A Control is specific to the tecnnology used to control a device.  
                </p>
                <p>
                    For example a device called 'Lounge Lamp' may be controlled by a smart socket, which is controlled by Tuya.  
                    This smart socket may also be configured in Home Assistant, which can also control the socket.  
                    So in this example, we could define the following Controls to actually control the Lounge Lamp.
                
                <ul>
                    <li> One "control' for controlling the smart socket via Tuya Cloud   </li>
                    <li> A second 'control' for controlling the same smart socket via Home Asssistant  </li>
                    <li> A third 'control' for controlling the same smart socket via Tuya Local  </li>
                </ul>
                    Each control will have its own set of parameters, but all will be able to control the same outlet.  
                
                <p>
                    Although a Device can be controlled in numerous different ways, each Device can only ever be associated with <strong> one </strong> of these Controls at a time.  A Device must be associated with a Control 
                    before the Device can be built into a Schedule.  It is possible to create Devices with slightly different names, but have them
                    all be the same smart socket.  Each of these 'slightly different' names will use a copy of the same Control (with a different Control ID.)  These 'slightly different' Devices can then all be Scheduled.  
                    While this will work, it is dangerous because there is no overlap detection performed across different devices.  This could cause unpredictable results, so the recommended approach is to define each Device once and select the desired Control for the device. 
                </p>
                <p>
                    The ability to define multiple Controls for a device simply allows flexibility to control devices via different channels, with the ability to switch between Control methods if desired.
        
				</p>

				
			</section>


            <section class="main-section" id="toolsmenu">
				<header>
					The Tools Menu
				</header>
                  
                
				<p>
                    The Tools Menu is where system status and other control can be found.


                    
                </p>

			</section>	

		</main>
	</div>
</body>
</html>
